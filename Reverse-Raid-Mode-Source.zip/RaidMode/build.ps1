[CmdletBinding()]
param([string]$Destination=(Join-Path $PSScriptRoot 'bin'),[switch]$Tests,[switch]$Personal,[switch]$Raiders)
$ErrorActionPreference='Stop'
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'The 64-bit .NET Framework C# compiler is required.' }
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$refs=@('/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Core.dll','/r:System.Xml.dll','/r:System.Web.Extensions.dll','/r:Microsoft.CSharp.dll')
$files=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Filter '*.cs' | ForEach-Object FullName)
$flags=@('/nologo','/optimize+','/platform:x64','/warnaserror+')
$exe=Join-Path $Destination "Reverse's Raid Mode.exe"
$icon=Join-Path $PSScriptRoot 'raid.ico'
if ($Personal -or $Raiders) {
    if ($Raiders) {
        $flags+='/define:PERSONAL,RAIDERS'
        $exe=Join-Path $Destination "Reverse's Raid Mode Raiders.exe"
    } else {
        $flags+='/define:PERSONAL'
        $exe=Join-Path $Destination "Reverse's Raid Mode Personal.exe"
    }
    $icon=Join-Path $PSScriptRoot 'raid-personal.ico'
}
& $compiler @flags @refs /target:winexe "/win32manifest:$PSScriptRoot\app.manifest" "/win32icon:$icon" "/out:$exe" @files
if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }
Write-Output "Built $exe"
if ($Tests) {
    $testExe=Join-Path $Destination 'RaidMode.Tests.exe'
    & $compiler @flags @refs /target:exe /main:RaidMode.Checks "/out:$testExe" @files "$PSScriptRoot\tests\Checks.cs"
    if ($LASTEXITCODE -ne 0) { throw 'Test build failed.' }
    Write-Output "Built $testExe"
}
