[CmdletBinding()]
param([Parameter(Mandatory)][string]$Exe,[string]$Screenshot,[switch]$FirstLaunch)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RaidWindow {
    delegate bool EnumWindow(IntPtr h,IntPtr context);
    [DllImport("user32")] static extern bool EnumWindows(EnumWindow cb,IntPtr context);
    [DllImport("user32")] static extern bool EnumChildWindows(IntPtr parent,EnumWindow cb,IntPtr context);
    [DllImport("user32",CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr h,uint msg,IntPtr capacity,System.Text.StringBuilder text,uint flags,uint ms,out IntPtr result);
    public static string[] Labels(IntPtr parent){
        var result=new System.Collections.Generic.List<string>();
        EnumChildWindows(parent,delegate(IntPtr h,IntPtr c){
            var text=new System.Text.StringBuilder(1024);IntPtr ignored;
            SendMessageTimeout(h,13,(IntPtr)text.Capacity,text,2,100,out ignored);
            if(text.Length>0)result.Add(text.ToString());return true;
        },IntPtr.Zero);return result.ToArray();
    }
    [DllImport("user32")] static extern uint GetWindowThreadProcessId(IntPtr h,out int pid);
    [DllImport("user32",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,System.Text.StringBuilder s,int length);
    [DllImport("user32")] static extern bool SetWindowPos(IntPtr h,IntPtr order,int x,int y,int w,int size,uint flags);
    [DllImport("user32")] public static extern bool PostMessage(IntPtr h,uint msg,IntPtr w,IntPtr l);
    [DllImport("user32")] static extern IntPtr GetParent(IntPtr h);
    [DllImport("user32")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,System.Text.StringBuilder name,int capacity);
    [DllImport("user32")] static extern IntPtr SendMessage(IntPtr h,uint msg,IntPtr w,IntPtr l);
    public static IntPtr ListHeader(IntPtr preview,int columns) {
        IntPtr header=IntPtr.Zero;
        EnumChildWindows(preview,delegate(IntPtr h,IntPtr c){
            var name=new System.Text.StringBuilder(128);GetClassName(h,name,name.Capacity);
            if(name.ToString()!="SysHeader32" || !IsWindowVisible(h) || SendMessage(h,0x1200,IntPtr.Zero,IntPtr.Zero).ToInt32()!=columns)return true;
            header=h;return false;
        },IntPtr.Zero);
        return header;
    }
    public static void ClickWhitelistHeader(IntPtr header) {
        var list=GetParent(header);
        int first=SendMessage(list,0x101D,IntPtr.Zero,IntPtr.Zero).ToInt32();
        int second=SendMessage(list,0x101D,(IntPtr)1,IntPtr.Zero).ToInt32();
        var point=(IntPtr)((8<<16) | (first+second/2));
        SendMessage(header,0x201,(IntPtr)1,point);SendMessage(header,0x202,IntPtr.Zero,point);
    }
    public static int CheckExpansion(IntPtr header) {
        var list=GetParent(header);
        int collapsed=SendMessage(list,0x1004,IntPtr.Zero,IntPtr.Zero).ToInt32();
        SendMessage(list,0x100,(IntPtr)0x24,IntPtr.Zero); // Home
        for(int i=0;i<collapsed;i++) {
            SendMessage(list,0x100,(IntPtr)0x27,IntPtr.Zero); // Right
            int added=SendMessage(list,0x1004,IntPtr.Zero,IntPtr.Zero).ToInt32()-collapsed;
            if(added>0) {
                SendMessage(list,0x100,(IntPtr)0x25,IntPtr.Zero); // Left
                if(SendMessage(list,0x1004,IntPtr.Zero,IntPtr.Zero).ToInt32()!=collapsed)
                    throw new InvalidOperationException("Collapsing the app did not restore the row count.");
                return added;
            }
            SendMessage(list,0x100,(IntPtr)0x28,IntPtr.Zero); // Down
        }
        return 0;
    }
    public static IntPtr TestWindow(int pid) {
        IntPtr found=IntPtr.Zero;
        EnumWindows(delegate(IntPtr h,IntPtr c){
            int owner;GetWindowThreadProcessId(h,out owner);if(owner!=pid)return true;
            var title=new System.Text.StringBuilder(256);GetWindowText(h,title,title.Capacity);
            if(title.ToString()!="Reverse's Raid Mode")return true;
            found=h;return false;
        },IntPtr.Zero);
        if(found!=IntPtr.Zero)SetWindowPos(found,IntPtr.Zero,-6000,-6000,0,0,0x55);
        return found;
    }
    [DllImport("user32")] public static extern bool PrintWindow(IntPtr window, IntPtr dc, uint flags);
    [DllImport("user32")] public static extern bool GetWindowRect(IntPtr window, out Rect rect);
    [StructLayout(LayoutKind.Sequential)] public struct Rect {public int Left, Top, Right, Bottom;}
}
'@
function Find-Control($root,[string]$name) {
    $condition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,$name)
    $root.FindFirst([Windows.Automation.TreeScope]::Descendants,$condition)
}
function Wait-Control($root,[string]$name) {
    $deadline=[DateTime]::UtcNow.AddSeconds(35)
    do {$element=Find-Control $root $name;if($element){return $element};Start-Sleep -Milliseconds 150}while([DateTime]::UtcNow -lt $deadline)
    throw "Timed out waiting for $name."
}
function Invoke-Control($element) {
    if(!$element.Current.IsEnabled -or $element.Current.Name -notin @('Scan & preview','Whitelist','Scan software')){throw 'Unexpected preview control.'}
    $handle=[IntPtr]$element.Current.NativeWindowHandle
    if($handle -eq 0){throw 'Preview control has no native window.'}
    [void][RaidWindow]::PostMessage($handle,0xF5,[IntPtr]::Zero,[IntPtr]::Zero)
}
function Save-WindowImage($window,$path) {
    $rect=New-Object 'RaidWindow+Rect'
    [void][RaidWindow]::GetWindowRect($window,[ref]$rect)
    $bmp=[Drawing.Bitmap]::new(($rect.Right-$rect.Left),($rect.Bottom-$rect.Top))
    try {
        $graphics=[Drawing.Graphics]::FromImage($bmp)
        try {$dc=$graphics.GetHdc();try {$rendered=[RaidWindow]::PrintWindow($window,$dc,2)}finally{$graphics.ReleaseHdc($dc)}}finally{$graphics.Dispose()}
        if(!$rendered){throw 'Window capture failed.'}
        $bmp.Save([IO.Path]::GetFullPath($path),[Drawing.Imaging.ImageFormat]::Png)
    } finally {$bmp.Dispose()}
}
function Get-ProfileStamp($path) {
    if(Test-Path -LiteralPath $path){return ((Get-FileHash -LiteralPath $path).Hash + '/' + (Get-Item -LiteralPath $path).LastWriteTimeUtc.Ticks)}
    return 'absent'
}
$mode=if($FirstLaunch){'--first-launch-preview'}else{'--preview'}
if($FirstLaunch){
    $profileFile=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RaidModeDesktop\whitelist.json'
    $before=Get-ProfileStamp $profileFile
}
$process=Start-Process -FilePath (Resolve-Path -LiteralPath $Exe).Path -ArgumentList $mode -WindowStyle Hidden -PassThru
try {
    $deadline=[DateTime]::UtcNow.AddSeconds(25)
    do {$process.Refresh();if ($process.HasExited){throw "Preview exited with $($process.ExitCode)"};$window=[RaidWindow]::TestWindow($process.Id);Start-Sleep -Milliseconds 100}
    while ($window -eq 0 -and [DateTime]::UtcNow -lt $deadline)
    if($window -eq 0){throw 'Preview has no accessible desktop window.'}
    $root=[Windows.Automation.AutomationElement]::FromHandle($window)
    if($root.Current.Name -ne "Reverse's Raid Mode"){throw $root.Current.Name}
    if($FirstLaunch){
        $null=Wait-Control $root 'FIRST-LAUNCH PREVIEW'
        $deadline=[DateTime]::UtcNow.AddSeconds(35)
        do {
            $fresh=[RaidWindow]::Labels($window) | Where-Object {$_ -match '^0 whitelist rules\s+/\s+\d+ software entries discovered'}
            if(!$fresh){Start-Sleep -Milliseconds 100}
        }while(!$fresh -and [DateTime]::UtcNow -lt $deadline)
        if(!$fresh){throw 'Empty first-launch inventory did not load.'}
        if($Screenshot){Save-WindowImage $window $Screenshot}
        $label=[RaidWindow]::Labels($window) | Where-Object {$_ -match '^Apply suggestions \(\d+\)$'} | Select-Object -First 1
        if($label -match '\((\d+)\)'){
            $count=[int]$Matches[1]
            $apply=Find-Control $root 'Apply suggestions'
            if(!$apply){$apply=Wait-Control $root $label}
            if(!$apply.Current.IsEnabled){throw 'Detected suggestions could not be applied.'}
            [void][RaidWindow]::PostMessage([IntPtr]$apply.Current.NativeWindowHandle,0xF5,[IntPtr]::Zero,[IntPtr]::Zero)
            $deadline=[DateTime]::UtcNow.AddSeconds(5)
            do {
                $added=[RaidWindow]::Labels($window) | Where-Object {$_ -match "^$count whitelist rules?\s+/"}
                if(!$added){Start-Sleep -Milliseconds 100}
            }while(!$added -and [DateTime]::UtcNow -lt $deadline)
            if(!$added -or $apply.Current.IsEnabled){throw 'Bulk suggestions did not complete.'}
            Write-Output "Applied $count detected executable paths in a disposable preview."
        }else{Write-Output 'Fresh preview loaded. No selectable suggestions found on this PC.'}
        return
    }
    $idleBytes=$process.WorkingSet64
    $scan=Wait-Control $root 'Scan & preview';Invoke-Control $scan
    $null=Wait-Control $root 'Preview ready'
    $start=Wait-Control $root 'Start raid...'
    if($start.Current.IsEnabled){throw 'Read-only preview exposed activation.'}
    foreach($name in @('Add to whitelist','Remove from whitelist')){
        if((Wait-Control $root $name).Current.IsEnabled){throw "Read-only preview exposed editing through $name."}
    }
    $summary=[RaidWindow]::Labels($window) | Where-Object {$_ -match '\d+ to close'} | Select-Object -First 1
    Write-Output "Release preview: $summary"
    $header=[RaidWindow]::ListHeader($window,7)
    if($header -eq [IntPtr]::Zero){throw 'Process list header missing.'}
    [RaidWindow]::ClickWhitelistHeader($header)
    Write-Output 'Clicked the release process list Whitelist header.'
    if($Screenshot){Save-WindowImage $window $Screenshot}
    if (!$summary){throw 'Process count label missing.'}
    $groupCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::ListItem)
    $group=$root.FindAll([Windows.Automation.TreeScope]::Descendants,$groupCondition) | Where-Object {$_.Current.Name.StartsWith([string][char]0x25B8)} | Select-Object -First 1
    $label=if ($group) {$group.Current.Name}
    $members=[RaidWindow]::CheckExpansion($header)
    if ($label) {
        if ($label -notmatch '\((\d+)\)$' -or $members -ne [int]$Matches[1]){throw "Group count mismatch for $label after expanding ($members)."}
        Write-Output "Expanded and collapsed $label with $members process rows."
    } elseif ($members -gt 0) {
        Write-Output "Expanded and collapsed a group with $members process rows."
    }
    Invoke-Control (Wait-Control $root 'Whitelist')
    $discover=Wait-Control $root 'Scan software';Invoke-Control $discover
    $deadline=[DateTime]::UtcNow.AddSeconds(35)
    do {
        Start-Sleep -Milliseconds 150
        $rules=[RaidWindow]::Labels($window) | Where-Object {$_ -match 'software entries discovered'} | Select-Object -First 1
    }while(!$rules -and [DateTime]::UtcNow -lt $deadline)
    if(!$rules){throw 'Software catalog did not populate.'}
    $process.Refresh()
    Write-Output "Release catalog: $rules"
    Write-Output ("Working set at open {0:n1} MiB; after both scans {1:n1} MiB" -f ($idleBytes/1MB),($process.WorkingSet64/1MB))
}finally {
    if(!$process.HasExited){[void]$process.CloseMainWindow();if(!$process.WaitForExit(5000)){$process.Kill();$process.WaitForExit()}}
    $process.Dispose()
    if($FirstLaunch){
        if((Get-ProfileStamp $profileFile) -ne $before){throw 'The saved profile changed during the first-launch test.'}
        Write-Output 'Verified the live profile fingerprint and timestamp after closing the preview.'
    }
}
