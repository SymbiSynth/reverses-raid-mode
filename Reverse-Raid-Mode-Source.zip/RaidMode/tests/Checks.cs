using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RaidMode
{
    internal static class Checks
    {
        static int passed, failed;
        static string scratch,fixture,launcher;
        static void Is(bool condition,string message) {if(!condition)throw new Exception(message);}
        static void Reject(Action action)
        {
            try {action();} catch(Exception) {return;}
            throw new Exception("Expected rejection.");
        }
        static void Test(string name,Action body)
        {
            try {body();Console.WriteLine("PASS  "+name);passed++;}catch(Exception ex){Console.WriteLine("FAIL  "+name+"  "+ex);failed++;}
        }
        static string Temp()
        {
            string path=Path.Combine(scratch,Guid.NewGuid().ToString("N"));Directory.CreateDirectory(path);return path;
        }
        static ProcessRow Row(int id,string path)
        {
            return new ProcessRow {Id=id,Image=path,Name=Path.GetFileNameWithoutExtension(path),Birth=1234+id,Session=Native.Session,Sid=Native.User};
        }
        static string BuildProduct(string folder,string filename,string company,string product,int major)
        {
            Directory.CreateDirectory(folder);
            string path=Path.Combine(folder,filename);
            using(var compiler=new Microsoft.CSharp.CSharpCodeProvider()) {
                var options=new System.CodeDom.Compiler.CompilerParameters{GenerateExecutable=true,OutputAssembly=path};
                var result=compiler.CompileAssemblyFromSource(options,"using System.Reflection;\n[assembly:AssemblyCompany(\""+company+
                    "\")]\n[assembly:AssemblyProduct(\""+product+"\")]\n[assembly:AssemblyVersion(\""+major+
                    ".0.0.0\")]\nclass Sample { static void Main() {} }");
                Is(!result.Errors.HasErrors,"could not compile product fixture");
            }
            return path;
        }
        sealed class FakeSources : Sources
        {
            public List<SourceItem> Items=new List<SourceItem>();
            public Func<SourceItem,bool> OnPause=i=>true;
            public Action<SourceItem> OnRestore=i=>{};
            internal FakeSources(string dir):base(dir,@"Software\RaidModeFixture"){}
            internal override List<SourceItem> Inspect(Settings s,HashSet<string> p,List<string> n){return Items;}
            internal override bool Pause(SourceItem i){return OnPause(i);}
            internal override void Restore(SourceItem i){OnRestore(i);}
            internal SourceItem Add()
            {
                var s=new SourceItem{Kind="Run value",Location=RunKeys[0],Name="Fixture",Original="original",Format="String",Target=fixture};
                Items.Add(s);return s;
            }
        }
        sealed class Rig : IDisposable
        {
            internal readonly string Root=Temp(), Mutex="Local\\RaidModeFixture"+Guid.NewGuid().ToString("N");
            internal Settings Settings=new Settings{UseRaidDefaults=false};
            internal List<ProcessRow> Live=new List<ProcessRow>();
            internal List<int> Actions=new List<int>();
            internal FakeSources Sources;
            internal bool Admin;
            internal Session Engine;
            internal Action<string> Report=delegate {};
            internal Rig(){Sources=new FakeSources(Root);Engine=Make();}
            internal Session Make(){return new Session(Settings,Root,Root,Mutex,Sources,()=>Live,
                (rows,g,stop,log)=>{stop.ThrowIfCancellationRequested();Actions.AddRange(rows.Select(p=>p.Id));},()=>Admin,Report);}
            internal void Start(){var p=Engine.Scan();Engine.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed);}
            public void Dispose(){Engine.Dispose();}
        }
        [STAThread] static int Main(string[] args)
        {
            string filename=Path.GetFileNameWithoutExtension(Application.ExecutablePath);
            if(filename=="RaidReturnFixture")return ReturnFixture(args);
            if(filename=="RaidFixture") {
                if(args.Contains("window")){using(var f=new Form {Text="Disposable Raid Mode test",ShowInTaskbar=false,StartPosition=FormStartPosition.Manual,Location=new Point(-3000,-3000)}) {
                    var timer=new System.Windows.Forms.Timer{Interval=40000};timer.Tick+=(o,e)=>f.Close();timer.Start();Application.Run(f);timer.Dispose();}return 0;}
                Thread.Sleep(40000);return 0;
            }
            if(filename=="RaidFixtureLauncher"){using(var child=Spawn(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath),"RaidFixture.exe"),"")){} return 0;}
            scratch=Path.Combine(args.Length>0?Path.GetFullPath(args[0]):Path.GetTempPath(),"RaidModeTests-"+Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(scratch);fixture=Path.Combine(scratch,"RaidFixture.exe");launcher=Path.Combine(scratch,"RaidFixtureLauncher.exe");
            File.Copy(Application.ExecutablePath,fixture);File.Copy(Application.ExecutablePath,launcher);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            PolicyTests();SessionTests();SourceTests();ProcessTests();
            using(var loop=new ApplicationContext()) {
                EventHandler first=null;
                first=(o,e)=>{Application.Idle-=first;SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());
                    try{if(Program.Personal)PersonalGuiTests();else GuiTests();}finally{loop.ExitThread();}};
                Application.Idle+=first;Application.Run(loop);
            }
            Console.WriteLine("RESULT  "+passed+" passed, "+failed+" failed");
            if(failed==0 && Path.GetFileName(scratch).StartsWith("RaidModeTests-"))Directory.Delete(scratch,true);
            return failed==0?0:1;
        }
        static void PolicyTests()
        {
            Test("System paths, critical identities, shell, security, input, anti-cheat and GPU rules",()=>{
                foreach(var path in new[]{Path.Combine(Paths.Win,@"System32\foo.exe"),@"D:\Elsewhere\explorer.exe",@"D:\Apps\EasyAntiCheat_EOS\svc.exe",@"D:\Apps\BattlEye\svc.exe",@"D:\Apps\Bitdefender\agent.exe",@"D:\Drivers\NVIDIA Corporation\NvContainer\svc.exe",@"D:\Programs\Microsoft GameInput\input.exe"})
                    Is(Policy.SystemImage(Path.GetFileNameWithoutExtension(path),path),path);
                Is(!Policy.SystemImage("notes",Path.Combine(Paths.PF,@"WindowsApps\Notes_v1\notes.exe")),"WindowsApps blanket");
                Is(!Policy.SystemImage("share",@"D:\Apps\NVIDIA Corporation\Share\share.exe"),"NVIDIA blanket");
                var p=Row(7890,fixture);p.Critical=true;
                Is(!Policy.Classify(new List<ProcessRow>{p},new Settings(),new List<ProcessRow>())[0].Close,"critical process");
            });
            Test("Unknown, foreign owner/session, controller and ancestors survive",()=>{
                var a=Row(245001,fixture);var b=Row(245002,fixture);var c=Row(245003,fixture);
                a.Sid="S-1-5-18";b.Session++;c.Birth=0;
                var self=Row(Native.Self,fixture);var parent=Row(245004,fixture);self.Parent=parent.Id;parent.Birth=1;
                var rows=new List<ProcessRow>{a,b,c,self,parent};
                Is(!Policy.Classify(rows,new Settings(),new List<ProcessRow>()).Any(p=>p.Close),"protected process selected");
            });
            Test("Exact paths, rooted folder boundaries and narrowly versioned packages",()=>{
                string folder=@"D:\Games\Raid";
                Is(Paths.Matches(Paths.Rule(folder+@"\*"),folder+@"\bin\wow.exe"),"valid folder");
                Is(!Paths.Matches(folder+@"\*",folder+@"Tools\wow.exe"),"sibling");
                Is(!Paths.Matches(fixture,Path.Combine("D:\\Elsewhere",Path.GetFileName(fixture))),"same basename");
                Is(Paths.Matches(Paths.Wave,Path.Combine(Paths.PF,@"WindowsApps\Elgato.WaveLink_v3\app.exe")),"package");
                Reject(()=>Paths.Rule(@"*\App\*"));Reject(()=>Paths.Rule(Paths.PF+@"\*"));Reject(()=>Paths.Rule(@"C:\Users\*"));
            });
            Test("Allowed and manual descendants are transitive and birth-time checked",()=>{
                var a=Row(12001,fixture);var b=Row(12002,@"D:\Tools\helper.exe");var c=Row(12003,@"D:\Tools\child.exe");var reused=Row(12004,fixture+"new.exe");
                b.Parent=a.Id;c.Parent=b.Id;reused.Parent=a.Id;reused.Birth=42;
                var rows=new List<ProcessRow>{a,b,c,reused};Policy.Classify(rows,new Settings{UseRaidDefaults=false},new List<ProcessRow>{a});
                Is(!c.Close && reused.Close,"descendant classification");
            });
            Test("An updated bench rule stays within its installation, helper, package publisher and release channel",()=>{
                var s=new Settings{UseRaidDefaults=false};
                string old=@"D:\Games\Battle.net\Agent\Agent.9123\Agent.exe";
                s.BlockExecutable(old);
                Is(s.IsBlacklisted(old.Replace("9123","9320")),"versioned agent");
                Is(!s.IsBlacklisted(old.Replace("Battle.net","Other")) && !s.IsBlacklisted(old.Replace("Agent.exe","Other.exe")),"unrelated helper");
                string discord=@"D:\Apps\Discord\app-1.0.18\Discord.exe";
                s.BlockExecutable(discord);
                Is(s.IsBlacklisted(discord.Replace("1.0.18","1.0.19")) && !s.IsBlacklisted(discord.Replace("1.0.18","1.0.19-beta.2")),"release channel");
                var portable=new Settings();portable.BlockExecutable(@"D:\Discord\app-1.0\Discord.exe");
                Is(portable.IsBlacklisted(@"D:\Discord\app-2.0\Discord.exe"),"portable install under drive root");
                string store=@"D:\Program Files\WindowsApps\Vendor.Mixer_1.2.3.4_x64__abcde12345678\bin\Mixer.exe";
                s.BlockExecutable(store);
                Is(s.IsBlacklisted(store.Replace("1.2.3.4","2.0.0.1")) && !s.IsBlacklisted(store.Replace("abcde","vwxyz")),"store package");
                s.Allow.Add(old.Replace("9123","9320"));
                Is(!s.IsBlacklisted(old.Replace("9123","9320")),"explicit roster decision");
            });
            Test("An existing bench rule learns the installed product and follows a distinct new build across directories",()=>{
                string dir=Temp(),file=Path.Combine(dir,"whitelist.json");
                string old=BuildProduct(Path.Combine(dir,"original"),"RaidMusic.exe","Test Audio Co","Raid Music",1);
                string moved=BuildProduct(Path.Combine(dir,"new"),"RaidMusic.exe","Test Audio Co","Raid Music",2);
                string other=BuildProduct(Path.Combine(dir,"other"),"RaidMusic.exe","Different Co","Raid Music",2);
                Store.Write(file,new {Version=1,Block=new[]{old},CloseUnlisted=false,UseRaidDefaults=false});
                string legacy=File.ReadAllText(file);Settings.Open(file);
                Is(File.ReadAllText(file)==legacy,"preview wrote metadata");
                var settings=Settings.Open(file,true);
                Is(!settings.IsBlacklisted(moved),"separate installation captured while original still exists");
                File.Delete(old);
                settings=Settings.Open(file);
                Is(settings.IsBlacklisted(moved) && !settings.IsBlacklisted(other),"lost product identity or matched different publisher");
                var rostered=settings.Copy();rostered.AllowExecutable(moved);rostered.Validate();
                Is(!rostered.Block.Any() && !rostered.BenchProducts.Any() && rostered.MatchingRule(moved)==moved,"roster did not remove inherited bench");
                settings.RemoveExecutable(moved);settings.Validate();Store.Write(file,settings);
                Is(!Settings.Open(file).IsBlacklisted(moved) && !Settings.Open(file).IsBlacklisted(old),"cleared bench returned after reload");
            });
            Test("Fresh profiles start empty and older profiles retain rules, exceptions and preferences",()=>{
                string file=Path.Combine(Temp(),"whitelist.json");
                var s=Settings.Open(file);
                Is(s.Allow.Count==0 && s.FolderExceptions.Count==0 && s.FullGuard && !File.Exists(file),"fresh profile was seeded");
                string folder=Path.GetDirectoryName(fixture)+@"\*";
                s.Allow.Add(folder);s.FolderExceptions.Add(fixture);s.Minutes=45;s.Origin="Imported Hermes whitelist";Store.Write(file,s);
                var loaded=Settings.Open(file);
                Is(loaded.Minutes==45 && loaded.MatchingRule(launcher)==folder && loaded.MatchingRule(fixture)==null,"old profile changed");
                Store.Write(file,new Settings());
                Is(Settings.Open(file).Allow.Count==0,"saved empty profile was repopulated");
            });
            Test("A saved roster follows the updated product across installs and can be benched at its new location",()=>{
                string dir=Temp(),file=Path.Combine(dir,"whitelist.json");
                string old=BuildProduct(Path.Combine(dir,"original"),"RaidVoice.exe","Voice Co","Raid Voice",1);
                string moved=BuildProduct(Path.Combine(dir,"updated"),"RaidVoice.exe","Voice Co","Raid Voice",2);
                string other=BuildProduct(Path.Combine(dir,"different"),"RaidVoice.exe","Other Co","Raid Voice",2);
                Store.Write(file,new {Version=1,Allow=new[]{old},Block=new[]{fixture},FolderExceptions=new[]{launcher},CloseUnlisted=false});
                var s=Settings.Open(file,true);
                Is(s.UseRaidDefaults==Program.Raiders && s.MatchingRule(moved)==null && s.Resolve(fixture).Origin==RuleOrigin.SavedBench &&
                    s.Resolve(launcher).Origin==RuleOrigin.FlexOverride,"upgrade changed existing manual decisions");
                File.Delete(old);s=Settings.Open(file);
                Is(s.MatchingRule(moved)==old && s.MatchingRule(other)==null,"product match after restart");
                s.BlockExecutable(moved);s.Validate();Store.Write(file,s);s=Settings.Open(file);
                Is(!s.Allow.Contains(old) && !s.RosterProducts.ContainsKey(old) && s.Resolve(moved).Origin==RuleOrigin.SavedBench,"removed roster returned");
            });
            Test("Raid defaults are editable and browser suggestions identify the default and running browsers",()=>{
                var s=new Settings{UseRaidDefaults=true,CloseUnlisted=false};
                string wow=Path.Combine(Temp(),"WowClassic.exe"),discord=Path.Combine(Temp(),@"Discord\app-1.0\Discord.exe");
                string agent=Path.Combine(Temp(),"Agent.exe"),archon=Path.Combine(Temp(),"Archon App.exe");
                File.Copy(fixture,archon);
                Is(s.Resolve(discord).Origin==RuleOrigin.DefaultRoster && s.Resolve(wow).Origin==RuleOrigin.DefaultRoster &&
                    s.Resolve(Path.Combine(Temp(),@"Discord\Update.exe")).Origin==RuleOrigin.DefaultRoster && s.IsBlacklisted(agent),"default identities");
                Is(s.Resolve(archon).Suggestible && s.IsBlacklisted(archon),"default bench unavailable to suggestions");
                s.BlockExecutable(archon);Is(!s.Resolve(archon).Suggestible,"explicit bench still suggested");
                s.RemoveExecutable(archon);s.Validate();Is(!s.IsBlacklisted(archon) && !s.Resolve(archon).Suggestible,"Flex still benched or suggested");
                s.AllowExecutable(archon);Is(s.Resolve(archon).Origin==RuleOrigin.SavedRoster,"failed to roster Flex");
                s.BlockExecutable(wow);Is(s.IsBlacklisted(wow),"explicit WoW bench lost");
                var browsers=new HashSet<string>(Paths.Comparer){@"D:\Custom\Browse.exe"};
                string def=@"D:\Browser\Other.exe";
                Is(BrowserInventory.InUse(def,false,def,browsers) && BrowserInventory.InUse(@"D:\Custom\Browse.exe",true,def,browsers) &&
                    BrowserInventory.InUse(@"D:\Portable\firefox.exe",true,def,browsers) && !BrowserInventory.InUse(@"D:\Custom\Browse.exe",false,def,browsers) &&
                    !BrowserInventory.InUse(@"D:\App\msedgewebview2.exe",true,def,browsers),"browser detection");
            });
            Test("Suggestions match raid apps and the user's browsers, with a folder check for generic agent names",()=>{
                var agent=RaidSuggestion.Products.Single(p=>p.Name=="Battle.net Update Agent");
                Is(agent.Matches(new AppEntry{Image=@"E:\Games\Battle.net\Agent\Agent.123\AGENT.EXE"}),"missed local agent");
                Is(!agent.Matches(new AppEntry{Name="Battle.net",Image=@"E:\Other\Agent.exe"}),"unrelated agent suggested");
                var wow=RaidSuggestion.Products.Single(p=>p.Name=="World of Warcraft");
                Is(wow.Matches(new AppEntry{Image=@"F:\Games\_retail_\wow.exe"}) && !wow.Matches(new AppEntry{Image=@"F:\Games\WowSetup.exe"}),"WoW match");
                Is(RaidSuggestion.Products.Single(p=>p.Name=="Archon").Matches(new AppEntry{Image=@"D:\Raid\Archon App.exe"}),"Archon not suggested");
                Is(RaidSuggestion.Products.Single(p=>p.Name=="Your browser").Matches(new AppEntry{Image=@"D:\Web\Custom.exe",BrowserInUse=true}),"browser not suggested");
                foreach(string filename in new[]{"FanControl.exe","FanControl.Service.exe","Warcraft Logs Uploader.exe","Elgato.WaveLink.exe","MOTIV Mix.exe","wooting-bg-service.exe"})
                    Is(!RaidSuggestion.Products.Any(p=>p.Matches(new AppEntry{Image=Path.Combine(@"D:\Apps",filename)})),"suggested optional app "+filename);
            });
            Test("Task definition comparison ignores only enabled flag; checks owner",()=>{
                string a="<Task><Settings><Enabled>true</Enabled></Settings><Actions><Exec>A</Exec></Actions></Task>";
                Is(TaskSources.Fingerprint(a)==TaskSources.Fingerprint(a.Replace("true","false")),"enabled");
                Is(TaskSources.Fingerprint(a)!=TaskSources.Fingerprint(a.Replace(">A<",">B<")),"different action");
                Is(TaskSources.Owned(Native.User)&&!TaskSources.Owned("")&&!TaskSources.Owned("S-1-5-18"),"ownership");
            });
        }
        static void SessionTests()
        {
            Test("Older per-app restart choices survive upgrades without becoming a session default or changing rules",()=>{
                string root=Temp(),path=Path.Combine(root,@"Player\app-1.2\Player.exe"),file=Path.Combine(root,"whitelist.json");
                Store.Write(file,new {Version=1,Block=new[]{path},AfterRaid=new Dictionary<string,int>{{path,2}}});
                var s=Settings.Open(file);Is(s.Block.Contains(path),"opening the old profile lost its rule");
                Is(s.AfterMode(path.Replace("1.2","1.3"))==AfterRaidMode.Resume,"lost per-app choice after an update");
                Store.Write(file,s.Copy());
                string profile=File.ReadAllText(file);
                Is(profile.Contains("AfterRaid") && !profile.Contains("AfterSession") && Settings.Open(file).Block.Contains(path),"per-app and session settings mixed");
                Is(AppReopen.Arguments(@"D:\Apps\msedge.exe",AfterRaidMode.Resume,null)=="--restore-last-session" &&
                    AppReopen.Arguments(@"D:\Apps\Other.exe",AfterRaidMode.Resume,"--saved")=="--saved" &&
                    AppReopen.Arguments(@"D:\Apps\Other.exe",AfterRaidMode.Resume,null)=="","resume arguments");
            });
            Test("End and recovery reopen confirmed pre-raid apps once and skip missing, already running and guard-only apps",()=>{using(var r=new Rig()){
                string open=Path.Combine(r.Root,"Player.exe"),running=Path.Combine(r.Root,"Already.exe"),late=Path.Combine(r.Root,"Late.exe");
                foreach(string path in new[]{open,running,late})File.Copy(fixture,path);
                foreach(var p in new[]{Row(830101,open),Row(830102,open),Row(830103,running)}){p.Window=(IntPtr)1;r.Live.Add(p);}
                var launched=new List<string>();
                Action<IEnumerable<ProcessRow>,int,CancellationToken,Action<string>> close=(rows,g,t,log)=>{
                    foreach(var p in rows)if(p.ConfirmClosed!=null)p.ConfirmClosed(p);
                };
                Func<Session> make=()=>new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,()=>r.Live,close,()=>false,r.Report,(path,args)=>launched.Add(path));
                using(var engine=make()) {
                    var plan=engine.Scan();engine.Start(plan,plan.Id,CancellationToken.None,SessionReturn.Resume);
                    r.Live.Clear();var newApp=Row(830104,late);newApp.Birth=DateTime.UtcNow.AddSeconds(1).ToFileTimeUtc();
                    r.Live.Add(newApp);engine.Guard(CancellationToken.None);
                    r.Live.Add(Row(830105,running));
                    var journal=Store.Load<Journal>(Path.Combine(r.Root,"session.json"));
                    Is(journal.Reopen.Count==2 && !journal.Reopen.Any(i=>i.Image==late),"recorded a duplicate or guard-only launch");
                }
                using(var recovery=make()){recovery.End();recovery.End();}
                Is(launched.SequenceEqual(new[]{open}),"recovery duplicated or reopened the wrong app");
            }});
            Test("Recovery respects per-app receipts and leave-closed, legacy choices and Windows shutdown",()=>{using(var r=new Rig()){
                string image=Path.Combine(r.Root,"msedge.exe"),file=Path.Combine(r.Root,"session.json");
                File.Copy(fixture,image);r.Settings.SetAfterMode(image,AfterRaidMode.Fresh);
                var launches=new List<string>();
                Action<int,SessionReturn,AfterRaidMode,bool> recover=(version,choice,receipt,allow)=>{
                    var journal=new Journal{Version=version,Run=Guid.NewGuid().ToString("N"),AfterSession=choice,State="Active"};
                    journal.Reopen.Add(new ReopenItem{Image=image,Mode=receipt});Store.Write(file,journal);
                    using(var recovery=new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,()=>r.Live,
                        (rows,g,t,log)=>{},()=>false,r.Report,(path,args)=>launches.Add(args))) {
                        recovery.End(allow);recovery.End();
                    }
                };
                recover(2,SessionReturn.LeaveClosed,AfterRaidMode.Resume,true);
                recover(2,SessionReturn.Resume,AfterRaidMode.Resume,false);
                recover(1,SessionReturn.LeaveClosed,AfterRaidMode.Resume,true);
                Is(launches.Count==0,"manual, shutdown or unapproved legacy receipt relaunched");
                recover(2,SessionReturn.PerApp,AfterRaidMode.Resume,true);
                recover(1,SessionReturn.LeaveClosed,AfterRaidMode.Fresh,true);
                Is(launches.SequenceEqual(new[]{"--restore-last-session","--new-window about:blank"}),"captured or legacy choice was lost");
            }});
            Test("Default bench, protected processes and updated Battle.net roster agree in preview and guard",()=>{using(var r=new Rig()){
                string old=Path.Combine(r.Root,@"Battle.net\Battle.net.15400\Battle.net.exe"),next=old.Replace("15400","15500");
                Directory.CreateDirectory(Path.GetDirectoryName(old));File.Copy(fixture,old);
                r.Settings.UseRaidDefaults=true;r.Settings.CloseUnlisted=false;r.Settings.AllowExecutable(old);
                var wow=Row(705100,@"D:\Games\World of Warcraft\_retail_\Wow.exe");
                var bnet=Row(705101,next);var discord=Row(705102,@"D:\Chat\Discord\app-1.0\Discord.exe");
                var browser=Row(705103,@"D:\Browser\firefox.exe");browser.Parent=discord.Id;
                var win=Row(705104,Path.Combine(Paths.Win,@"System32\svchost.exe"));
                var helper=Row(705105,Path.Combine(Path.GetDirectoryName(discord.Image),"VoiceHelper.exe"));helper.Parent=discord.Id;
                var blocked=Row(705106,Path.Combine(Path.GetDirectoryName(discord.Image),"Telemetry.exe"));blocked.Parent=discord.Id;
                r.Settings.BlockExecutable(blocked.Image);
                r.Live.AddRange(new[]{wow,bnet,discord,browser,win,helper,blocked});
                var plan=r.Engine.Scan();
                Is(plan.Targets.Select(p=>p.Id).SequenceEqual(new[]{browser.Id,blocked.Id}) && plan.Rows.First(p=>p.Id==bnet.Id).WhitelistRule==old &&
                    plan.Rows.First(p=>p.Id==helper.Id).AllowTree && !r.Actions.Any(),"incorrect preview");
                r.Engine.Start(plan,plan.Id,CancellationToken.None,SessionReturn.LeaveClosed);r.Live.Clear();
                var later=Row(705110,next.Replace("15500","15600"));var unknown=Row(705111,@"D:\Apps\Music.exe");
                later.Birth=unknown.Birth=DateTime.UtcNow.AddSeconds(1).ToFileTimeUtc();r.Live.AddRange(new[]{later,unknown});
                r.Engine.Guard(CancellationToken.None);Is(r.Actions.SequenceEqual(new[]{browser.Id,blocked.Id,unknown.Id}),"guard disagreed with roster");r.Engine.End();
            }});
            Test("Preview and the active guard follow a moved executable from a legacy path-only profile",()=>{using(var r=new Rig()){
                string old=Path.Combine(r.Root,@"Chat\app-1.2.0\helper.exe");
                string next=old.Replace("1.2.0","1.3.0"),latest=old.Replace("1.2.0","2.0.0");
                string file=Path.Combine(r.Root,"whitelist.json");
                Store.Write(file,new {Block=new[]{old},CloseUnlisted=false,FullGuard=false,UseRaidDefaults=false});
                r.Settings=Settings.Open(file);r.Engine.Dispose();r.Engine=r.Make();
                r.Live.Add(Row(707001,next));r.Live.Add(Row(707002,next.Replace("Chat","Other")));
                var plan=r.Engine.Scan();
                Is(plan.Targets.Select(p=>p.Image).SequenceEqual(new[]{next}) && r.Actions.Count==0,"previewed a different program");
                r.Engine.Start(plan,plan.Id,CancellationToken.None,SessionReturn.LeaveClosed);
                r.Live.Clear();var late=Row(707003,latest);late.Birth=DateTime.UtcNow.AddSeconds(1).ToFileTimeUtc();
                r.Live.Add(late);r.Engine.Guard(CancellationToken.None);
                Is(r.Actions.SequenceEqual(new[]{707001,707003}),"missed the updated launch during raid");r.Engine.End();
            }});
            Test("Explicit blacklist beats folder rules and helper permits, while protected identities and neutral apps stay running",()=>{using(var r=new Rig()){
                r.Settings.CloseUnlisted=false;
                r.Settings.Allow.Add(Path.GetDirectoryName(fixture)+@"\*");r.Settings.BlockExecutable(fixture);
                var parent=Row(705001,launcher);var blocked=Row(705002,fixture);blocked.Parent=parent.Id;
                var neutral=Row(705003,Path.Combine(Temp(),"Other.exe"));
                var unknown=Row(705004,fixture);unknown.Birth=0;
                var foreign=Row(705005,fixture);foreign.Sid="S-1-5-18";
                var critical=Row(705006,fixture);critical.Critical=true;
                r.Live.AddRange(new[]{parent,blocked,neutral,unknown,foreign,critical});
                var classified=Policy.Classify(r.Live,r.Settings,new List<ProcessRow>{blocked});
                Is(classified.Where(p=>p.Close).Select(p=>p.Id).SequenceEqual(new[]{blocked.Id}),"blacklist priority or protections failed");
                Reject(()=>r.Settings.BlockExecutable(Path.Combine(Paths.Win,@"System32\svchost.exe")));
                r.Live.Remove(blocked);r.Start();Is(r.Actions.Count==0,"empty close plan acted");
                var late=Row(705020,fixture);late.Birth=DateTime.UtcNow.AddSeconds(1).ToFileTimeUtc();r.Live.Add(late);
                r.Engine.Guard(CancellationToken.None);Is(r.Actions.SequenceEqual(new[]{late.Id}),"new blacklist launch not caught");
                Reject(()=>r.Engine.Launch(fixture));r.Engine.End();
            }});
            Test("A memory-only preview can scan but cannot activate a guard",()=>{using(var r=new Rig()){
                r.Live.Add(Row(101,fixture));
                using(var preview=new Session(r.Settings,null,r.Root,r.Mutex,r.Sources,()=>r.Live,
                    (rows,grace,stop,log)=>r.Actions.Add(101),()=>false,r.Report)){
                    var p=preview.Scan();
                    Is(p.Targets.Count()==1,"fixture plan");
                    try {preview.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed);throw new Exception("preview activated");}
                    catch(InvalidOperationException ex){Is(ex.Message.Contains("first-launch preview"),"unexpected activation error");}
                    Is(!preview.Active && !preview.NeedsRecovery && r.Actions.Count==0,"preview started a session");
                }
            }});
            Test("Preview, cancelled confirmation and wrong plan ID produce zero actions",()=>{using(var r=new Rig()){
                r.Live.Add(Row(101,fixture));var p=r.Engine.Scan();Is(r.Actions.Count==0&&!r.Engine.NeedsRecovery,"scan wrote a journal");
                Reject(()=>r.Engine.Start(p,Guid.NewGuid(),CancellationToken.None,SessionReturn.LeaveClosed));Reject(()=>r.Engine.Start(p,p.Id,new CancellationToken(true),SessionReturn.LeaveClosed));
                Is(r.Actions.Count==0&&!r.Engine.NeedsRecovery,"cancel changed state");
            }});
            Test("Expired plan and whitelist edits invalidate approval",()=>{using(var r=new Rig()){
                var p=r.Engine.Scan();p.Created=p.Created.AddMinutes(-6);Reject(()=>r.Engine.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed));
                p=r.Engine.Scan();r.Settings.Allow.Add(fixture);Reject(()=>r.Engine.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed));
            }});
            Test("New unreviewed process or reused PID requires fresh approval",()=>{using(var r=new Rig()){
                r.Live.Add(Row(101,fixture));var p=r.Engine.Scan();r.Live[0]=Row(101,fixture);r.Live[0].Birth++;
                Reject(()=>r.Engine.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed));p=r.Engine.Scan();r.Live.Add(Row(102,fixture));
                Reject(()=>r.Engine.Start(p,p.Id,CancellationToken.None,SessionReturn.LeaveClosed));Is(!r.Actions.Any(),"acted on stale plan");
            }});
            Test("Elevated activation, large plans and the original controller lock are rejected",()=>{using(var r=new Rig()){
                r.Admin=true;Reject(r.Start);r.Admin=false;r.Settings.Limit=1;r.Live.Add(Row(99,fixture));r.Live.Add(Row(100,fixture));Reject(r.Start);
                r.Live.Clear();using(var m=new Mutex(false,r.Mutex))Reject(r.Start);Is(!r.Engine.NeedsRecovery,"unexpected journal");
            }});
            Test("Second controller and recovery cannot enter a running session",()=>{using(var r=new Rig()){
                r.Start();using(var other=r.Make()){Reject(()=>other.Scan());Reject(other.End);}Is(r.Engine.Active,"lost session");r.Engine.End();
            }});
            foreach(bool full in new[]{false,true}){bool mode=full;
                Test(mode?"Full guard closes a new path":"Hermes guard limits closures to reviewed paths",()=>{using(var r=new Rig()){
                    r.Settings.FullGuard=mode;r.Live.Add(Row(100,fixture));r.Start();r.Actions.Clear();r.Live.Clear();
                    r.Live.Add(Row(200,fixture));r.Live.Add(Row(201,@"D:\Other\Other.exe"));
                    foreach(var p in r.Live)p.Birth=DateTime.UtcNow.ToFileTimeUtc();
                    r.Engine.Guard(CancellationToken.None);
                    Is(r.Actions.Contains(200)&&r.Actions.Contains(201)==mode,"guard scope");
                    r.Engine.End();int count=r.Actions.Count;Reject(()=>r.Engine.Guard(CancellationToken.None));
                    Reject(()=>r.Engine.Launch(fixture));Is(r.Actions.Count==count,"inactive action");
                }});
            }
            Test("Timeout and rolling guard circuit breaker stop additional actions",()=>{using(var r=new Rig()){
                r.Settings.Limit=1;r.Start();r.Live.Add(Row(102,fixture));r.Live[0].Birth=DateTime.UtcNow.ToFileTimeUtc();r.Engine.Guard(CancellationToken.None);Reject(()=>r.Engine.Guard(CancellationToken.None));
                r.Engine.Started=DateTime.UtcNow.AddHours(-8);Is(r.Engine.Expired,"deadline");Reject(()=>r.Engine.Guard(CancellationToken.None));r.Engine.End();
            }});
            Test("A preexisting unreadable process stays outside the guard after identity resolves",()=>{using(var r=new Rig()){
                var p=Row(704,fixture);p.Sid=null;r.Live.Add(p);r.Start();p.Sid=Native.User;r.Engine.Guard(CancellationToken.None);
                Is(!r.Actions.Any(),"unreviewed existing instance targeted");r.Engine.End();
            }});
            Test("Write-ahead recovery survives failure between mutation and acknowledgment",()=>{using(var r=new Rig()){
                r.Sources.Add();bool paused=false,restored=false;
                r.Sources.OnPause=item=>{Is(Store.Load<Journal>(Path.Combine(r.Root,"session.json")).Sources[0].Stage=="Intent","no write-ahead");
                    paused=true;throw new IOException("fixture interrupted after mutation");};
                r.Sources.OnRestore=item=>{restored=true;};r.Start();Is(paused,"mutation missing");
                r.Engine.Dispose();using(var recovery=r.Make()){Is(recovery.NeedsRecovery,"lost journal");recovery.End();Is(restored&&!recovery.NeedsRecovery,"failed recovery");}
            }});
            Test("Changed-source skip and reverse-order conflicting recovery are retryable",()=>{using(var r=new Rig()){
                r.Sources.Add().Name="A";r.Sources.Add().Name="B";r.Sources.Add().Name="C";r.Sources.OnPause=i=>i.Name!="C";
                var order=new List<string>();r.Sources.OnRestore=i=>{order.Add(i.Name);if(i.Name=="B")throw new IOException("conflict");};
                r.Start();Reject(r.Engine.End);Is(String.Join("",order)=="BA"&&r.Engine.NeedsRecovery,"partial restore order");
                r.Sources.OnRestore=i=>order.Add(i.Name);r.Engine.End();Is(String.Join("",order)=="BAB"&&!r.Engine.NeedsRecovery,"retry");
            }});
        }
        static void SourceTests()
        {
            Test("Disposable HKCU REG_EXPAND_SZ conflict and exact restoration",()=>{
                string sub=@"Software\RaidModeDesktopFixtures\"+Guid.NewGuid().ToString("N");
                const string command="\"%TEMP%\\RaidFixture.exe\" --start";
                var repo=new Sources(Temp(),sub);var item=new SourceItem {Kind="Run value",Location=sub,Name="Fixture",Original=command,Format="ExpandString"};
                using(var key=Registry.CurrentUser.CreateSubKey(sub)) {
                    try {
                        key.SetValue("Fixture",command,RegistryValueKind.ExpandString);
                        Is(repo.Pause(item)&&key.GetValue("Fixture")==null,"pause");
                        key.SetValue("Fixture","replacement");Reject(()=>repo.Restore(item));Is((string)key.GetValue("Fixture")=="replacement","overwrote conflict");
                        key.DeleteValue("Fixture");repo.Restore(item);repo.Restore(item);
                        Is((string)key.GetValue("Fixture",null,RegistryValueOptions.DoNotExpandEnvironmentNames)==command && key.GetValueKind("Fixture")==RegistryValueKind.ExpandString,"lost original type or bytes");
                    } finally {Registry.CurrentUser.DeleteSubKeyTree(sub,false);}
                }
            });
            Test("Startup file bytes and collision recovery preserve saved copy",()=>{
                string dir=Temp(),backup=Temp(),file=Path.Combine(dir,"fixture.lnk");File.WriteAllText(file,"original");
                var repo=new Sources(dir);var item=new SourceItem{Kind="Startup file",Location=file,Fingerprint=Sources.HashFile(file),Backup=Path.Combine(backup,"saved")};
                repo.Validate(item,backup);Is(repo.Pause(item),"pause file");File.WriteAllText(file,"replacement");
                Reject(()=>repo.Restore(item));Is(File.ReadAllText(file)=="replacement"&&File.Exists(item.Backup),"collision");
                File.Delete(file);repo.Restore(item);Is(Sources.HashFile(file)==item.Fingerprint&&!File.Exists(item.Backup),"restore");
                item.Backup=Path.Combine(dir,"wrong");Reject(()=>repo.Validate(item,backup));
            });
            Test("Startup command matching does not select another tool's argument",()=>{
                var paths=new[]{fixture};Is(Sources.Match("\""+fixture+"\" --start",paths)==fixture,"quoted path");
                Is(Sources.Match(fixture+" /silent",paths)==fixture,"unquoted path");
                Is(Sources.Match("another.exe \""+fixture+"\"",paths)==null,"argument false positive");
            });
        }
        static Process Spawn(string image,string args)
        {
            return Process.Start(new ProcessStartInfo(image,args){UseShellExecute=false,CreateNoWindow=true});
        }
        static void Cleanup(Process p){try{if(!p.HasExited){p.Kill();p.WaitForExit(3000);}}finally{p.Dispose();}}
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]
        static extern int RegisterApplicationRestart(string command,uint flags);
        static int ReturnFixture(string[] args)
        {
            string dir=Path.GetDirectoryName(Application.ExecutablePath);
            if(!args.Contains("before")) {
                File.AppendAllText(Path.Combine(dir,"reopened.txt"),(args.Contains("--saved-workspace")?"workspace":"fresh")+"\n");
                return 0;
            }
            if(RegisterApplicationRestart("--saved-workspace",0)!=0)return 1;
            if(args.Contains("tray")) {
                File.WriteAllText(Path.Combine(dir,"ready"),"ready");Thread.Sleep(40000);return 0;
            }
            using(var form=new Form{Text="Reopen fixture",ShowInTaskbar=false,StartPosition=FormStartPosition.Manual,Location=new Point(-3000,-3000)}) {
                if(args.Contains("unsaved"))form.FormClosing+=(s,e)=>e.Cancel=true;
                using(var timer=new System.Windows.Forms.Timer{Interval=100}) {
                    if(args.Contains("delayed")) {
                        string accepted=Path.Combine(dir,"continue-close");
                        form.FormClosing+=(s,e)=>e.Cancel=!File.Exists(accepted);
                        timer.Tick+=(s,e)=>{if(File.Exists(accepted))form.Close();};timer.Start();
                    }
                    form.Shown+=(s,e)=>File.WriteAllText(Path.Combine(dir,"ready"),"ready");
                    Application.Run(form);
                }
            }
            return 0;
        }
        static void ProcessTests()
        {
            Test("Resume restores saved work, leave closed does not relaunch, and an outstanding save prompt survives the guard",()=>{
                foreach(string scenario in new[]{"manual","resume","unsaved","delayed","tray","perAppFresh"})using(var r=new Rig()) {
                    string image=Path.Combine(r.Root,"RaidReturnFixture.exe"),receipt=Path.Combine(r.Root,"reopened.txt");
                    File.Copy(Application.ExecutablePath,image);
                    r.Settings.Grace=1;
                    if(scenario=="perAppFresh")r.Settings.SetAfterMode(image,AfterRaidMode.Fresh);
                    var p=Spawn(image,"before "+scenario);
                    try {
                        Wait(()=>File.Exists(Path.Combine(r.Root,"ready")));
                        using(var engine=new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,
                            ()=>Native.Snapshot().Where(row=>Paths.Equal(row.Image,image)).ToList(),Native.CloseSelected,()=>false,r.Report)) {
                            var plan=engine.Scan();
                            engine.Start(plan,plan.Id,CancellationToken.None,scenario=="manual"?SessionReturn.LeaveClosed:scenario=="perAppFresh"?SessionReturn.PerApp:SessionReturn.Resume);engine.Guard(CancellationToken.None);
                            if(scenario=="delayed"){
                                Is(!p.HasExited,"pending window was forced closed");File.WriteAllText(Path.Combine(r.Root,"continue-close"),"saved");
                            }
                            if(scenario=="unsaved")Is(!p.HasExited,"save prompt force-closed");
                            else Is(p.WaitForExit(2000),"graceful exit failed");
                            engine.End();engine.End();
                        }
                        if(scenario=="unsaved" || scenario=="manual")Is(!File.Exists(receipt),"unexpected relaunch");
                        else {Wait(()=>File.Exists(receipt) && new FileInfo(receipt).Length>0);
                            Is(File.ReadAllText(receipt).Trim()==(scenario=="perAppFresh"?"fresh":"workspace"),"lost requested reopen mode");}
                    } finally {Cleanup(p);}
                }
            });
            Test("Real Windows inventory includes controller, readable identity, and installed software",()=>{
                var sw=Stopwatch.StartNew();var rows=Native.Snapshot();long elapsed=sw.ElapsedMilliseconds;
                var me=rows.Single(p=>p.Id==Native.Self);Is(me.Verified&&me.Sid==Native.User,"own identity unreadable");
                var notes=new List<string>();var list=Software.Find(rows,notes);Is(list.Count>0,"empty catalog");
                Console.WriteLine("      "+rows.Count+" session processes, "+list.Count+" software paths, "+notes.Count+" inventory notes, process snapshot "+elapsed+" ms");
            });
            foreach(bool window in new[]{true,false}){bool graceful=window;
                Test(graceful?"Disposable window responds to graceful close":"Pinned handle force-closes disposable background process",()=>{
                    var p=Spawn(fixture,graceful?"window":"");try {
                        ProcessRow row=null;
                        for(int i=0;i<50;i++){row=Native.Snapshot().FirstOrDefault(x=>x.Id==p.Id);if(row!=null&&row.Verified&&(!graceful||row.Window!=IntPtr.Zero))break;Thread.Sleep(50);}
                        Is(row!=null&&row.Verified,"missing fixture");row.Close=true;row.Birth++;var notes=new List<string>();
                        Native.CloseSelected(new[]{row},0,CancellationToken.None,notes.Add);Is(!p.HasExited,"stale identity was killed");
                        row.Birth--;Native.CloseSelected(new[]{row},graceful?800:0,CancellationToken.None,notes.Add);
                        Is(p.WaitForExit(3000)&&notes.Any(s=>s.StartsWith(graceful?"Closed normally":"Force-closed")),String.Join(" | ",notes));
                    }finally{Cleanup(p);}
                });
            }
            Test("Launch once binds instance; a later copy of that executable is closed",()=>{
                using(var r=new Rig()){
                    // Narrow all inventory AND all real close operations to the unique fixture path.
                    var notes=new List<string>();
                    using(var engine=new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,
                        ()=>Native.Snapshot().Where(p=>Paths.Equal(p.Image,fixture)).ToList(),
                        (rows,g,stop,output)=>Native.CloseSelected(rows.Where(p=>Paths.Equal(p.Image,fixture)),g,stop,output),()=>false,notes.Add)) {
                        var plan=engine.Scan();engine.Start(plan,plan.Id,CancellationToken.None,SessionReturn.LeaveClosed);engine.Launch(fixture);
                        var allowed=Native.Snapshot().Single(p=>Paths.Equal(p.Image,fixture));var approvedProcess=Process.GetProcessById(allowed.Id);var copy=Spawn(fixture,"");
                        try {engine.Guard(CancellationToken.None);Is(!approvedProcess.HasExited&&copy.WaitForExit(3000),"identity leaked");engine.End();}
                        finally {Cleanup(copy);Cleanup(approvedProcess);}
                    }
                }
            });
            Test("Short-lived manual launcher preserves its child after parent exit",()=>{using(var r=new Rig()){
                using(var engine=new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,
                    ()=>Native.Snapshot().Where(p=>Paths.Equal(p.Image,fixture)||Paths.Equal(p.Image,launcher)).ToList(),
                    (rows,g,stop,output)=>r.Actions.AddRange(rows.Select(p=>p.Id)),()=>false,delegate{})){
                    var plan=engine.Scan();engine.Start(plan,plan.Id,CancellationToken.None,SessionReturn.LeaveClosed);engine.Launch(launcher);Thread.Sleep(700);
                    var child=Native.Snapshot().Single(p=>Paths.Equal(p.Image,fixture));var approvedProcess=Process.GetProcessById(child.Id);
                    try {engine.Guard(CancellationToken.None);engine.Guard(CancellationToken.None);Is(!r.Actions.Contains(approvedProcess.Id),"orphaned child targeted");engine.End();}
                    finally {Cleanup(approvedProcess);}
                }
            }});
        }
        static T Get<T>(MainWindow w,string name){return (T)typeof(MainWindow).GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(w);}
        static void Wait(Func<bool> ready)
        {
            var deadline=DateTime.UtcNow.AddSeconds(20);
            while(!ready()&&DateTime.UtcNow<deadline){Application.DoEvents();Thread.Sleep(15);}
            Is(ready(),"UI timed out");
        }
        [DllImport("user32",CharSet=CharSet.Unicode)] static extern IntPtr FindWindow(string type,string title);
        [DllImport("user32",CharSet=CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr parent,IntPtr after,string type,string title);
        [DllImport("user32",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,System.Text.StringBuilder text,int size);
        [DllImport("user32")] static extern IntPtr GetDlgItem(IntPtr h,int id);
        [DllImport("user32")] static extern uint GetWindowThreadProcessId(IntPtr h,out int pid);
        [DllImport("user32")] static extern bool PostMessage(IntPtr h,int msg,IntPtr a,IntPtr b);
        [StructLayout(LayoutKind.Sequential)]
        struct HeaderRect {public int Left,Top,Right,Bottom;}
        [DllImport("user32")] static extern IntPtr SendMessage(IntPtr h,int msg,IntPtr a,IntPtr b);
        [DllImport("user32")] static extern bool GetKeyboardState([Out] byte[] state);
        [DllImport("user32")] static extern bool SetKeyboardState(byte[] state);
        static void ClickRuleRow(ListView grid,ListViewItem row,MouseButtons button,Keys modifier=Keys.None)
        {
            row.EnsureVisible();
            grid.Focus();
            var bounds=row.GetBounds(ItemBoundsPortion.Label);
            var point=(IntPtr)(((bounds.Top+bounds.Height/2)<<16)|(bounds.Left+(Program.Personal?110:12)));
            bool right=button==MouseButtons.Right;
            int flags=modifier==Keys.Shift?4:modifier==Keys.Control?8:0;
            var original=new byte[256];
            Is(GetKeyboardState(original),"unable to read fixture keyboard state");
            var keys=(byte[])original.Clone();
            keys[(int)Keys.ShiftKey]=(byte)(modifier==Keys.Shift?128:0);
            keys[(int)Keys.ControlKey]=(byte)(modifier==Keys.Control?128:0);
            try {
                Is(SetKeyboardState(keys),"unable to set fixture keyboard state");
                PostMessage(grid.Handle,right?0x204:0x201,(IntPtr)(flags|(right?2:1)),point);
                PostMessage(grid.Handle,right?0x205:0x202,(IntPtr)flags,point);
                Application.DoEvents();
            } finally {SetKeyboardState(original);}
        }
        [DllImport("user32",EntryPoint="SendMessageW")] static extern IntPtr ReadHeaderRect(IntPtr h,int msg,IntPtr a,out HeaderRect rect);
        static void ClickHeader(ListView list,int index)
        {
            var header=SendMessage(list.Handle,0x101F,IntPtr.Zero,IntPtr.Zero);
            HeaderRect rect;
            Is(header!=IntPtr.Zero,"missing native header");
            Is(ReadHeaderRect(header,0x1207,(IntPtr)index,out rect)!=IntPtr.Zero,"missing header bounds");
            int x=(rect.Left+rect.Right)/2, y=(rect.Top+rect.Bottom)/2;
            var point=(IntPtr)((y<<16)|x);
            SendMessage(header,0x201,(IntPtr)1,point);
            SendMessage(header,0x202,IntPtr.Zero,point);
            Application.DoEvents();
        }
        static void ClickDisclosure(ListView list,ListViewItem app)
        {
            app.EnsureVisible();Application.DoEvents();
            var bounds=app.GetBounds(ItemBoundsPortion.Label);
            if(Program.Personal)bounds=((GroupedProcessView)list).DisclosureRect(app);
            var click=new MouseEventArgs(MouseButtons.Left,1,bounds.Left+7,bounds.Top+bounds.Height/2,0);
            typeof(GroupedProcessView).GetMethod("OnMouseClick",BindingFlags.Instance|BindingFlags.NonPublic)
                .Invoke(list,new object[]{click});
            Application.DoEvents();
        }
        static void CheckRowDetails(MainWindow window,ListViewItem row,string expectedText)
        {
            var grid=Get<GroupedProcessView>(window,"processes");
            row.EnsureVisible();row.Selected=true;row.Focused=true;Application.DoEvents();
            var top=grid.TopItem;var count=grid.Items.Count;var bounds=row.SubItems[GroupedProcessView.DetailsColumn].Bounds;
            var click=new MouseEventArgs(MouseButtons.Left,1,bounds.Left+5,bounds.Top+bounds.Height/2,0);
            Is(grid.HitTest(click.Location).Item==row,"wrong detail target");
            typeof(GroupedProcessView).GetMethod("OnMouseClick",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(grid,new object[]{click});
            Application.DoEvents();
            var panel=Get<Panel>(window,"rowDetails");var back=Get<Button>(window,"backToRow");
            Is(grid.Visible && row.Selected && panel.Visible && back.Visible && Get<TextBox>(window,"rowDetailsText").Text.Contains(expectedText),"row detail was absent or showed another app");
            Is(grid.Parent.ClientRectangle.Contains(panel.Bounds),"details panel escaped table");
            var button=grid.PointToClient(back.PointToScreen(Point.Empty));
            Is(Math.Abs(button.Y-click.Y)<=back.Height && Math.Abs(button.X-click.X)<=back.Width,"Back too far from clicked row");
            back.PerformClick();
            Is(!panel.Visible && grid.TopItem==top && grid.Items.Count==count && row.Selected && row.Focused,"Back changed the table");
            var flags=BindingFlags.Instance|BindingFlags.NonPublic;
            var message=Message.Create(grid.Handle,0x100,IntPtr.Zero,IntPtr.Zero);
            typeof(GroupedProcessView).GetMethod("ProcessCmdKey",flags).Invoke(grid,new object[]{message,Keys.Alt|Keys.Enter});
            Is(panel.Visible,"Alt+Enter did not open details");
            typeof(MainWindow).GetMethod("ProcessCmdKey",flags).Invoke(window,new object[]{message,Keys.Escape});
            Is(!panel.Visible && row.Focused && grid.TopItem==top,"Escape did not return to the same row");
        }
        static void Confirm(MainWindow w,bool yes,string button="start",string title="Start raid session?",string question="Are you sure you want to start raid mode?",SessionReturn choice=SessionReturn.Resume)
        {
            if(Program.Raiders && button=="start") {
                bool required=false,correctButtons=false;
                using(var click=new System.Windows.Forms.Timer{Interval=60}) {
                    click.Tick+=(o,e)=>{
                        var dialog=Application.OpenForms.OfType<StartRaidDialog>().SingleOrDefault();
                        if(dialog==null)return;
                        var primary=(Button)dialog.Controls.Find("resumeApps",true).Single();
                        var manual=(Button)dialog.Controls.Find("leaveClosed",true).Single();
                        var perApp=(Button)dialog.Controls.Find("usePerApp",true).Single();
                        var cancel=(Button)dialog.CancelButton;
                        required=!dialog.Choice.HasValue && dialog.ActiveControl==primary && primary.BackColor!=manual.BackColor;
                        correctButtons=dialog.Owner==w && primary.Visible && manual.Visible && perApp.Visible && cancel.Visible &&
                            primary.Text.Contains("resume my apps") && manual.Text.Contains("leave my apps closed") &&
                            perApp.Text.Contains("per-app choices") && perApp.Parent.ClientRectangle.Contains(perApp.Bounds) && manual.Parent.ClientRectangle.Contains(manual.Bounds) && cancel.Parent.ClientRectangle.Contains(cancel.Bounds);
                        var names=((ListBox)dialog.Controls.Find("closeList",true).Single()).Items.Cast<string>().ToList();
                        foreach(var target in Get<Plan>(w,"plan").Targets) {
                            var family=AppFamily.Known(target.Image);
                            correctButtons&=names.Any(text=>text.StartsWith(family==null?target.Name:family.Name,StringComparison.OrdinalIgnoreCase));
                        }
                        click.Stop();(yes?(choice==SessionReturn.PerApp?perApp:choice==SessionReturn.Resume?primary:manual):cancel).PerformClick();
                    };
                    click.Start();Get<Button>(w,button).PerformClick();
                }
                Is(required && correctButtons,"missing per-session choices, default, close list or visible buttons");
                return;
            }
            bool asked=false,defaultNo=false;
            using(var click=new System.Windows.Forms.Timer{Interval=60}){
                click.Tick+=(o,e)=>{var h=FindWindow("#32770",title);int pid;
                    if(h==IntPtr.Zero || GetWindowThreadProcessId(h,out pid)==0 || pid!=Native.Self)return;
                    defaultNo=(SendMessage(h,0x400,IntPtr.Zero,IntPtr.Zero).ToInt64()&0xffff)==7;
                    var child=IntPtr.Zero;
                    while((child=FindWindowEx(h,child,"Static",null))!=IntPtr.Zero){
                        var body=new System.Text.StringBuilder(1024);GetWindowText(child,body,body.Capacity);
                        if(body.ToString().Contains(question))asked=true;
                    }
                    PostMessage(GetDlgItem(h,yes?6:7),0xF5,IntPtr.Zero,IntPtr.Zero);};
                click.Start();
                if(button=="clearAll") {
                    Get<Button>(w,"manageRules").PerformClick();
                    var item=Get<ToolStripMenuItem>(w,"clearAll");var menu=item.Owner as ContextMenuStrip;
                    Is(menu!=null && menu.Visible,"global rules menu unavailable");
                    item.PerformClick();menu.Close();
                } else Get<Button>(w,button).PerformClick();
            }
            Is(asked && defaultNo,"missing confirmation question or No default");
        }
        static void PersonalGuiTests()
        {
            if(Program.Raiders)Test("Right-click preferences persist, both global choices override them, and each new raid asks again",()=>{using(var r=new Rig()){
                string image=Path.Combine(r.Root,"Music.exe"),other=Path.Combine(r.Root,"Chat.exe"),third=Path.Combine(r.Root,"Notes.exe"),file=Path.Combine(r.Root,"whitelist.json");
                foreach(string path in new[]{image,other,third}){File.Copy(fixture,path);r.Settings.BlockExecutable(path);}
                Store.Write(file,r.Settings);
                var starts=new List<SessionReturn>();var reopened=new List<string>();
                Func<Action<string>,Session> make=log=>new Session(r.Settings,r.Root,r.Root,r.Mutex,r.Sources,()=>r.Live,
                    (rows,g,t,report)=>{
                        foreach(var row in rows)if(row.ConfirmClosed!=null)row.ConfirmClosed(row);
                        starts.Add(Store.Load<Journal>(Path.Combine(r.Root,"session.json")).AfterSession);
                        r.Live.Clear();
                    },()=>false,log,(path,args)=>reopened.Add(path));
                using(var w=new MainWindow(r.Settings,r.Root,make)) {
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var engine=Get<Session>(w,"session");var grid=Get<GroupedProcessView>(w,"processes");
                    var submenu=Get<ToolStripMenuItem>(w,"afterRaidMenu");
                    Action<string[],AfterRaidMode> choose=(images,mode)=>{
                        grid.SelectedItems.Clear();
                        foreach(ListViewItem row in grid.Items)row.Selected=images.Contains(row.SubItems[6].Text,Paths.Comparer);
                        var first=grid.SelectedItems[0];
                        ClickRuleRow(grid,first,MouseButtons.Right);
                        Is(grid.ContextMenuStrip.Visible && submenu.Enabled && grid.SelectedItems.Count==images.Length,"right-click lost the selection");
                        submenu.ShowDropDown();
                        var popup=submenu.DropDown;
                        var expectedText=SystemInformation.HighContrast?grid.ContextMenuStrip.ForeColor:Color.White;
                        Is(popup.Visible && popup.BackColor==grid.ContextMenuStrip.BackColor &&
                            popup.Items.Cast<ToolStripMenuItem>().All(item=>item.ForeColor==expectedText),"After raid submenu text contrast");
                        if(!SystemInformation.HighContrast) {
                            var painted=new Dictionary<ToolStripItem,Color>();
                            ToolStripItemTextRenderEventHandler record=(sender,e)=>painted[e.Item]=e.TextColor;
                            popup.Renderer.RenderItemText+=record;
                            try {
                                foreach(ToolStripMenuItem hover in popup.Items) {
                                    hover.Select();painted.Clear();popup.Refresh();
                                    Is(popup.Items.Cast<ToolStripMenuItem>().All(item=>painted.ContainsKey(item) && painted[item].ToArgb()==Color.White.ToArgb()),
                                        "After raid text changed color while selecting "+hover.Text);
                                }
                            } finally {popup.Renderer.RenderItemText-=record;}
                        }
                        submenu.DropDownItems[(int)mode].PerformClick();grid.ContextMenuStrip.Close();
                    };
                    choose(new[]{image,other},AfterRaidMode.Resume);choose(new[]{other},AfterRaidMode.Fresh);
                    var saved=Settings.Open(file);
                    Is(saved.AfterMode(image)==AfterRaidMode.Resume && saved.AfterMode(other)==AfterRaidMode.Fresh && saved.AfterMode(third)==AfterRaidMode.StayClosed && saved.Block.Count==3,"lost per-app choices or raid rules");
                    string profile=File.ReadAllText(file);
                    foreach(var choice in new[]{SessionReturn.LeaveClosed,SessionReturn.PerApp,SessionReturn.Resume,SessionReturn.LeaveClosed}) {
                        int pid=839000;
                        foreach(string path in new[]{image,other,third}){var row=Row(++pid,path);row.Window=(IntPtr)1;r.Live.Add(row);}
                        Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                        var preview=Get<Plan>(w,"plan");int count=starts.Count;
                        Confirm(w,false);
                        Is(!engine.Active && !engine.NeedsRecovery && starts.Count==count && Get<Plan>(w,"plan")==preview,"Cancel changed the plan or acted");
                        Confirm(w,true,choice:choice);Wait(()=>!Get<bool>(w,"busy"));
                        Is(engine.Active && starts.Count==count+1 && starts.Last()==choice,"wrong session choice");
                        var journal=Store.Load<Journal>(Path.Combine(r.Root,"session.json"));
                        if(choice==SessionReturn.Resume)Is(journal.Reopen.Count==3 && journal.Reopen.All(i=>i.Mode==AfterRaidMode.Resume),"global resume did not override fresh or stay closed");
                        if(choice==SessionReturn.PerApp)Is(journal.Reopen.Count==2 && journal.Reopen.Any(i=>i.Image==image && i.Mode==AfterRaidMode.Resume) && journal.Reopen.Any(i=>i.Image==other && i.Mode==AfterRaidMode.Fresh),"per-app effective modes");
                        reopened.Clear();Get<Button>(w,"end").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                        var expected=choice==SessionReturn.Resume?new[]{image,other,third}:choice==SessionReturn.PerApp?new[]{image,other}:new string[0];
                        Is(reopened.Count==expected.Length && expected.All(reopened.Contains) && !engine.Active && !engine.NeedsRecovery,"wrong end behavior");
                        Is(File.ReadAllText(file)==profile,"a session choice changed the saved per-app choices");
                    }
                    w.Close();
                }
            }});
            Test("Roster checkbox selection, select-all scope and search shortcut match the displayed rows",()=>{using(var r=new Rig()){
                string first=Path.Combine(r.Root,"First.exe"),second=Path.Combine(r.Root,"Second.exe"),third=Path.Combine(r.Root,"Third.exe");
                r.Settings.Allow.AddRange(new[]{first,second});r.Settings.Block.Add(third);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var grid=Get<GroupedProcessView>(w,"processes");var views=Get<List<Button>>(w,"viewButtons");var search=Get<TextBox>(w,"search");
                    Action<IntPtr,int,int> click=(handle,x,y)=>{
                        var at=(IntPtr)((y<<16)|x);SendMessage(handle,0x201,(IntPtr)1,at);SendMessage(handle,0x202,IntPtr.Zero,at);Application.DoEvents();
                    };
                    Action<int> toggle=i=>{
                        var rect=grid.Items[i].GetBounds(ItemBoundsPortion.Label);click(grid.Handle,rect.Left+grid.Font.Height,rect.Top+rect.Height/2);
                    };
                    toggle(0);toggle(1);Is(grid.SelectedItems.Count==2 && Get<Label>(w,"selectionLabel").Text=="2 selected","checkboxes did not add selections");
                    toggle(0);Is(grid.SelectedItems.Count==1,"checkbox failed to remove one row");
                    views[1].PerformClick();Is(grid.Items.Count==2,"Rostered filter");var header=SendMessage(grid.Handle,0x101f,IntPtr.Zero,IntPtr.Zero);
                    click(header,grid.Font.Height,6);Is(grid.SelectedItems.Count==2 && !grid.Columns[0].Text.Contains("\u2191"),"select-all sorted instead of selecting");
                    click(header,grid.Font.Height,6);Is(grid.SelectedItems.Count==0,"header could not clear selection");
                    click(header,grid.Font.Height,6);Get<Button>(w,"flexProcess").PerformClick();
                    Is(!r.Settings.Allow.Any() && r.Settings.IsBlacklisted(third),"filtered edit affected hidden rule");
                    views[0].PerformClick();grid.Focus();var msg=Message.Create(w.Handle,0x100,IntPtr.Zero,IntPtr.Zero);
                    typeof(MainWindow).GetMethod("ProcessCmdKey",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,new object[]{msg,Keys.OemQuestion});
                    Is(search.Focused,"slash did not focus search");search.Text="Third";Is(grid.Items.Count==1 && Get<Label>(w,"rosterCount").Text=="Showing 1 of 3 roster entries","filtered total");
                    w.Close();
                }
            }});
            Test("Hover and click in trailing list space, empty rows and reports never open Details",()=>{using(var r=new Rig()){
                r.Settings.AllowExecutable(fixture);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var grid=Get<GroupedProcessView>(w,"processes");var panel=Get<Panel>(w,"rowDetails");
                    var flags=BindingFlags.Instance|BindingFlags.NonPublic;
                    var move=typeof(GroupedProcessView).GetMethod("OnMouseMove",flags);
                    var click=typeof(GroupedProcessView).GetMethod("OnMouseClick",flags);
                    Action<Point,bool> hover=(p,link)=>{
                        move.Invoke(grid,new object[]{new MouseEventArgs(MouseButtons.None,0,p.X,p.Y,0)});
                        Is(grid.Cursor==(link?Cursors.Hand:Cursors.Default),"unexpected cursor at "+p);
                        if(!link){click.Invoke(grid,new object[]{new MouseEventArgs(MouseButtons.Left,1,p.X,p.Y,0)});Is(!panel.Visible,"blank click opened Details");}
                    };
                    foreach(ColumnHeader col in grid.Columns)col.Width=80;
                    var row=grid.Items[0];var cell=row.SubItems[GroupedProcessView.DetailsColumn].Bounds;
                    int y=cell.Top+cell.Height/2;
                    hover(new Point(cell.Left+4,y),true);
                    hover(new Point(grid.Columns.Cast<ColumnHeader>().Sum(c=>c.Width)+6,y),false);
                    hover(new Point(cell.Left+4,row.Bounds.Bottom+8),false);hover(new Point(-1,y),false);
                    grid.Columns[GroupedProcessView.DetailsColumn].DisplayIndex=2;
                    cell=row.SubItems[GroupedProcessView.DetailsColumn].Bounds;hover(new Point(cell.Left+4,y),true);
                    Get<ComboBox>(w,"filter").SelectedIndex=4;
                    grid.Items.Add(new ListViewItem("Report without a link"));hover(new Point(cell.Left+4,y),false);
                    grid.Items.Clear();hover(new Point(cell.Left+4,y),false);w.Close();
                }
            }});
            Test("Aside defaults cover versioned helpers in preview and guard and allow saved exceptions",()=>{using(var r=new Rig()){
                string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string app=Path.Combine(Paths.PF,@"Aside\Application\Aside.exe"),cli=Path.Combine(local,@"Aside\CLI\versions\new\aside.exe");
                string daemon=Path.Combine(local,@"Aside\User Data\AsideDaemon\win-x64\next\aside-daemon.exe");
                string helper=Path.Combine(Paths.Profile,@".aside\memory-runtimes\future\runner.exe");
                string other=Path.Combine(local,@"AsideTools\CLI\aside.exe");
                string downloaded=Path.Combine(Paths.Profile,@".aside\u\project\helper.exe");
                r.Settings.CloseUnlisted=false;r.Settings.FullGuard=false;
                Is(!r.Settings.IsBlacklisted(app) && AppFamily.Known(helper).Name=="Aside","default leaked or owner missing");
                r.Settings.BenchAside=true;r.Live.Add(Row(877001,app));r.Live.Add(Row(877002,other));
                r.Start();Is(r.Actions.SequenceEqual(new[]{877001}),"preview or start missed Aside or included another app");
                r.Actions.Clear();r.Live.Clear();
                foreach(string path in new[]{cli,daemon,helper,downloaded,other}){
                    var p=Row(877010+r.Live.Count,path);p.Birth=DateTime.UtcNow.ToFileTimeUtc();r.Live.Add(p);
                }
                r.Engine.Guard(CancellationToken.None);r.Engine.End();
                Is(r.Actions.SequenceEqual(new[]{877010,877011,877012}),"versioned runtime or directory boundary failed");
                r.Settings.AllowExecutable(cli);r.Settings.RemoveExecutable(daemon);r.Settings.Validate();
                string file=Path.Combine(r.Root,"profile.json");Store.Write(file,r.Settings);var saved=Settings.Open(file);
                Is(saved.BenchAside && saved.MatchingRule(cli)==cli && !saved.IsBlacklisted(daemon) && saved.MatchingRule(daemon)==null &&
                    saved.IsBlacklisted(helper),"saved Rostered/Flex overrides failed");
                saved.BlockExecutable(cli);Is(saved.IsBlacklisted(cli),"could not re-bench overridden path");
                using(var w=new MainWindow(saved,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var option=Get<ToolStripMenuItem>(w,"benchAside");Is(option.Checked,"saved Aside setting hidden");
                    option.PerformClick();Is(!Settings.Open(Path.Combine(r.Root,"whitelist.json")).BenchAside && !saved.IsBlacklisted(helper),"could not turn off the default");
                    option.PerformClick();Confirm(w,true,"clearAll","Clear all rules?","Clear all Rostered and Benched rules");
                    Is(!saved.BenchAside && !saved.IsBlacklisted(cli) && !option.Checked,"clear all retained Aside rule");w.Close();
                }
            }});
            Test("Product helpers share an expandable owner across live, installed and filtered rows",()=>{using(var r=new Rig()){
                string main=Path.Combine(r.Root,@"Games\Battle.net\Battle.net.exe"),agent=Path.Combine(r.Root,@"Data\Battle.net\Agent\Agent.9886\Agent.exe");
                string helper=Path.Combine(Path.GetDirectoryName(agent),"AgentHelper.exe"),other=Path.Combine(r.Root,@"Other\Agent.exe");
                foreach(string file in new[]{main,agent,helper,other}){Directory.CreateDirectory(Path.GetDirectoryName(file));File.Copy(fixture,file);}
                r.Settings.CloseUnlisted=false;r.Settings.AllowExecutable(main);r.Settings.BlockExecutable(agent);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var live=Get<List<ProcessRow>>(w,"processRows");
                    live.AddRange(new[]{Row(861001,main),Row(861002,agent),Row(861003,agent),Row(861004,other)});
                    Policy.Classify(live,r.Settings,new List<ProcessRow>());
                    Get<List<AppEntry>>(w,"catalog").Add(new AppEntry{Image=helper,Name="AgentHelper",Source="Game install"});
                    var grid=Get<GroupedProcessView>(w,"processes");var views=Get<List<Button>>(w,"viewButtons");var search=Get<TextBox>(w,"search");
                    var flags=BindingFlags.Instance|BindingFlags.NonPublic;
                    typeof(MainWindow).GetMethod("FillApps",flags).Invoke(w,null);
                    Func<ListViewItem> owner=()=>grid.Items.Cast<ListViewItem>().Single(i=>i.Name=="family:Battle.net");
                    Func<string,ListViewItem> child=path=>grid.Items.Cast<ListViewItem>().First(i=>i.SubItems[6].Text==path);
                    Is(grid.Items.Count==2 && owner().Text.Contains("3 files, 3 running") && owner().SubItems[1].Text=="Mixed" && child(other)!=null,"wrong owner or inflated totals");
                    ClickDisclosure(grid,owner());
                    Is(grid.Items.Count==6 && child(agent).Text.Contains("Agent.exe (PID ") && child(helper).SubItems[2].Text=="Not running","missing process or offline helper");
                    ClickHeader(grid,1);ClickHeader(grid,1);
                    var children=grid.Items.Cast<ListViewItem>().Skip(owner().Index+1).Take(4).ToArray();
                    Is(children.Length==4 && children.All(i=>i.SubItems[6].Text!=other),"sorting split the family");
                    CheckRowDetails(w,child(agent),"Application: Battle.net");CheckRowDetails(w,owner(),helper);
                    grid.SelectedItems.Clear();child(agent).Selected=true;Get<Button>(w,"flexProcess").PerformClick();
                    Is(!r.Settings.IsBlacklisted(agent) && r.Settings.Allow.Contains(main) && !r.Settings.Allow.Contains(other),"editing a helper changed a sibling");
                    search.Text="Battle.net Update Agent";Is(grid.Items.Count==4 && child(agent).Text.Contains("Update Agent") && child(helper)!=null,"friendly name failed to find the agents");
                    search.Text="AgentHelper";Is(grid.Items.Count==2 && child(helper)!=null,"search hid the matching helper");
                    grid.SelectedItems.Clear();owner().Selected=true;Get<Button>(w,"blockProcess").PerformClick();
                    Is(r.Settings.IsBlacklisted(helper) && !r.Settings.IsBlacklisted(agent) && r.Settings.Allow.Contains(main),"filtered edit affected a hidden sibling");
                    views[2].PerformClick();search.Clear();Is(owner().Text.Contains("1 file") && owner().SubItems[1].Text=="Benched","missing owner for a single filtered helper");
                    views[0].PerformClick();grid.SelectedItems.Clear();owner().Selected=true;Get<Button>(w,"keep").PerformClick();
                    var saved=Settings.Open(Path.Combine(r.Root,"whitelist.json"));
                    Is(new[]{main,agent,helper}.All(p=>saved.MatchingRule(p)!=null) && saved.MatchingRule(other)==null,"whole product edit lost exact path scope");
                    typeof(MainWindow).GetMethod("ShowPickedApps",flags).Invoke(w,new object[]{new[]{helper}});
                    Is(grid.SelectedItems.Count==1 && grid.SelectedItems[0].SubItems[6].Text==helper,"picked helper stayed hidden inside owner");
                    w.Close();
                }
            }});
            Test("Other products use matching publisher, product and installation folder",()=>{
                var first=AppFamily.FromProduct(@"D:\Tools\Northwind\Client.exe","Northwind","NW");
                var helper=AppFamily.FromProduct(@"D:\Tools\Northwind\bin\Agent.exe","Northwind","NW");
                Is(first!=null && helper!=null && first.Key==helper.Key && helper.ShowOwnerWhenAlone,"related helpers missing");
                Is(AppFamily.FromProduct(@"E:\Other\Northwind\Agent.exe","Northwind","NW").Key!=first.Key &&
                    AppFamily.FromProduct(@"D:\Tools\Northwind\Agent.exe","Northwind","Other").Key!=first.Key &&
                    AppFamily.FromProduct(@"D:\Tools\Agent.exe","Northwind","NW")==null,"ambiguous installations merged");
                Is(AppFamily.Known(@"D:\Other\Agent.exe")==null && AppFamily.Known(@"D:\Battle.net\AgentArchive\Agent.exe")==null,"unrelated agent claimed");
            });
            Test("Roster totals count executable groups and preserve the search and action context",()=>{using(var r=new Rig()){
                var discord=Path.Combine(r.Root,"Discord.exe");var fan=Path.Combine(r.Root,"FanControl.exe");
                var music=Path.Combine(r.Root,"Music.exe");var wow=Path.Combine(r.Root,"Wow.exe");
                foreach(var path in new[]{discord,fan,music,wow})File.Copy(fixture,path);
                r.Settings.CloseUnlisted=false;r.Settings.AllowExecutable(discord);r.Settings.BlockExecutable(music);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var live=Get<List<ProcessRow>>(w,"processRows");
                    live.AddRange(new[]{Row(860001,discord),Row(860002,discord),Row(860003,music)});
                    Policy.Classify(live,r.Settings,new List<ProcessRow>());
                    var catalog=Get<List<AppEntry>>(w,"catalog");
                    foreach(var path in new[]{discord,fan,music,wow})catalog.Add(new AppEntry{Image=path,Name=Path.GetFileNameWithoutExtension(path),Source="Game install"});
                    var flags=BindingFlags.Instance|BindingFlags.NonPublic;
                    typeof(MainWindow).GetMethod("FillApps",flags).Invoke(w,null);
                    var views=Get<List<Button>>(w,"viewButtons");var search=Get<TextBox>(w,"search");var filter=Get<ComboBox>(w,"filter");
                    var grid=Get<ListView>(w,"processes");var empty=Get<Label>(w,"emptyRoster");var footer=Get<Label>(w,"footer");
                    Action totals=()=>Is(views.Select(b=>b.Text.TrimStart('\u2713',' ')).SequenceEqual(
                        new[]{"All apps (4)","Rostered (1)","Benched (1)","Flex (2)","Suggested (1)"}),"incorrect or search-dependent roster counts");
                    totals();Is(footer.Text.Contains("Flex stay open") && grid.Columns[1].DisplayIndex==2,"missing rule position or default Flex policy");
                    views[1].PerformClick();search.Text="nothing matches";totals();
                    Is(grid.Items.Count==0 && empty.Visible && empty.Text.Contains("search"),"missing empty search feedback");
                    search.Clear();filter.SelectedIndex=1;views[2].PerformClick();totals();
                    Is(grid.Items.Count==1 && grid.Items[0].SubItems[1].Text=="Benched","rule and action filters failed to combine");
                    filter.SelectedIndex=3;Is(!search.Enabled && empty.Visible,"search remained editable in a report");
                    views[3].PerformClick();Is(search.Enabled && filter.SelectedIndex==0 && grid.Items.Count==2,"cannot return to Flex from report");
                    filter.SelectedIndex=1;
                    typeof(MainWindow).GetMethod("ShowPickedApps",flags).Invoke(w,new object[]{new[]{fan}});
                    Is(filter.SelectedIndex==0 && grid.SelectedItems.Count==1 && grid.SelectedItems[0].SubItems[6].Text==fan,"picked executable hidden by old action filter");
                    Get<Button>(w,"blockProcess").PerformClick();Is(Get<Label>(w,"summary").Text.Contains("1 rule changed to Benched"),"missing edit feedback");
                    Get<Button>(w,"flexProcess").PerformClick();Is(!r.Settings.IsBlacklisted(fan) && views[3].Text.Contains("(2)"),"Flex button failed to clear the selected rule");
                    Get<List<Button>>(w,"tabs")[1].PerformClick();Get<CheckBox>(w,"full").Checked=true;
                    Is(footer.Text.Contains("Eligible Flex apps may close"),"strict Flex policy hidden");
                    w.Close();
                }
            }});
            Test("Right-click moves single, Shift-selected and Ctrl-selected apps between Session rule lists",()=>{using(var r=new Rig()){
                string[] paths=new[]{"Alpha","Bravo","Charlie","Delta"}.Select(n=>Path.Combine(r.Root,n+".exe")).ToArray();
                foreach(string path in paths){File.Copy(fixture,path);r.Settings.AllowExecutable(path);}
                string file=Path.Combine(r.Root,"whitelist.json");Store.Write(file,r.Settings);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var grid=Get<GroupedProcessView>(w,"processes");var views=Get<List<Button>>(w,"viewButtons");
                    var menu=grid.ContextMenuStrip;
                    Func<int,ListViewItem> row=i=>grid.Items.Cast<ListViewItem>().Single(x=>Paths.Equal(x.SubItems[6].Text,paths[i]));
                    Action<int,int,int> choose=(target,count,action)=>{
                        ClickRuleRow(grid,row(target),MouseButtons.Right);
                        Is(menu.Visible && grid.SelectedItems.Count==count,"right-click lost its selection: "+grid.SelectedItems.Count);
                        Is(menu.Items[action].Enabled,"target status disabled");
                        menu.Items[action].PerformClick();menu.Close();Application.DoEvents();
                    };
                    views[1].PerformClick();
                    ClickRuleRow(grid,row(0),MouseButtons.Left);
                    ClickRuleRow(grid,row(2),MouseButtons.Left,Keys.Shift);
                    Is(grid.SelectedItems.Count==3,"Shift range selection failed");
                    choose(1,3,1);
                    Is(grid.Items.Count==1 && Settings.Open(file).Block.SequenceEqual(paths.Take(3)),"whitelist to blacklist did not save the range");
                    views[2].PerformClick();
                    ClickRuleRow(grid,row(0),MouseButtons.Left);
                    ClickRuleRow(grid,row(2),MouseButtons.Left,Keys.Control);
                    Is(grid.SelectedItems.Count==2,"Ctrl selection failed");
                    choose(2,2,0);
                    Is(grid.Items.Count==1 && Settings.Open(file).Block.SequenceEqual(new[]{paths[1]}),"blacklist to whitelist affected another row");
                    views[0].PerformClick();
                    ClickRuleRow(grid,row(0),MouseButtons.Left);
                    ClickRuleRow(grid,row(2),MouseButtons.Left,Keys.Control);
                    choose(3,1,2);
                    var saved=Settings.Open(file);
                    Is(saved.Allow.SequenceEqual(new[]{paths[0],paths[2]}) && saved.MatchingRule(paths[3])==null,"right-click on unselected row targeted other rules");
                    views[3].PerformClick();choose(3,1,1);
                    Is(grid.Items.Count==0 && Settings.Open(file).Block.SequenceEqual(new[]{paths[1],paths[3]}) && !r.Actions.Any(),"changing a free agent rule failed");
                    w.Close();
                }
            }});
            Test("Session applies every eligible suggestion in place and refreshes the plan before confirmation",()=>{using(var r=new Rig()){
                string wow=Path.Combine(Temp(),"Wow.exe"),folder=Temp(),discord=Path.Combine(folder,"Discord.exe"),fan=Path.Combine(folder,"FanControl.exe");
                foreach(string path in new[]{wow,discord,fan}) File.Copy(fixture,path);
                r.Settings.CloseUnlisted=false;r.Settings.BlockExecutable(fixture);
                r.Settings.Allow.Add(folder+@"\*");r.Settings.RemoveExecutable(fan);r.Settings.BlockExecutable(discord);
                r.Live.Add(Row(680001,fixture));r.Live.Add(Row(680002,wow));
                r.Live.Add(Row(680003,discord));r.Live.Add(Row(680004,fan));
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var scan=Get<Button>(w,"scan");var suggestions=Get<Button>(w,"suggestions");var start=Get<Button>(w,"start");
                    Is(!suggestions.Visible && !start.Enabled,"unexpected actions before scan");
                    Get<TextBox>(w,"search").Text="previous search";
                    scan.PerformClick();Is(suggestions.Visible && !suggestions.Enabled,"apply missing or enabled while scanning");Wait(()=>!Get<bool>(w,"busy"));
                    Is(suggestions.Enabled && start.Enabled && scan.Right<=suggestions.Left && suggestions.Right<=start.Left && start.BackColor!=scan.BackColor,"toolbar order or color");
                    var eligible=Get<List<AppEntry>>(w,"catalog").Where(a=>RaidSuggestion.Products.Any(p=>p.Matches(a)) &&
                        !r.Settings.IsBlacklisted(a.Image) && r.Settings.MatchingRule(a.Image)==null && !r.Settings.FolderExceptions.Contains(a.Image,Paths.Comparer))
                        .Select(a=>a.Image).Distinct(Paths.Comparer).ToList();
                    Is(eligible.Contains(wow) && suggestions.Text=="Apply suggestions ("+eligible.Count+")","global count followed a hidden library filter");
                    var oldPlan=Get<Plan>(w,"plan");suggestions.PerformClick();
                    Is(!start.Enabled,"obsolete plan remained available");Wait(()=>!Get<bool>(w,"busy"));
                    var saved=Settings.Open(Path.Combine(r.Root,"whitelist.json"));var plan=Get<Plan>(w,"plan");
                    Is(scan.Visible && suggestions.Visible && !suggestions.Enabled && suggestions.Text=="Apply suggestions (0)" && start.Enabled,"session did not stay ready");
                    Is(plan!=null && plan!=oldPlan && saved.Allow.Count==eligible.Count+1 && eligible.All(p=>saved.Allow.Contains(p,Paths.Comparer)) &&
                        saved.IsBlacklisted(discord) && saved.FolderExceptions.Contains(fan) && !r.Actions.Any(),"apply did not persist the reviewed batch");
                    Confirm(w,false);Is(Get<Plan>(w,"plan")==plan && !r.Actions.Any() && !Get<Session>(w,"session").Active,"cancel applied the plan");
                    Confirm(w,true);Wait(()=>!Get<bool>(w,"busy"));
                    Is(Get<Session>(w,"session").Active && !suggestions.Visible && r.Actions.OrderBy(id=>id).SequenceEqual(new[]{680001,680003}),"confirmed fixture plan");
                    Get<Button>(w,"end").PerformClick();Wait(()=>!Get<bool>(w,"busy"));w.Close();
                }
            }});
            Test("Applying suggestions promotes default Benched Archon and running browsers and respects a manual bench",()=>{using(var r=new Rig()){
                string archon=Path.Combine(r.Root,"Archon App.exe"),browser=Path.Combine(r.Root,"firefox.exe"),bnet=Path.Combine(r.Root,"Battle.net.exe");
                foreach(string path in new[]{archon,browser,bnet})File.Copy(fixture,path);
                r.Settings.UseRaidDefaults=true;r.Settings.CloseUnlisted=false;r.Settings.BlockExecutable(bnet);
                r.Live.AddRange(new[]{Row(689001,archon),Row(689002,browser),Row(689003,bnet)});
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var pending=Get<HashSet<string>>(w,"sessionSuggestions");
                    Is(pending.Contains(archon) && pending.Contains(browser) && !pending.Contains(bnet),"wrong pending suggestions");
                    Is(Get<Plan>(w,"plan").Targets.Count()==3 && !r.Actions.Any(),"default bench preview");
                    Get<Button>(w,"suggestions").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var saved=Settings.Open(Path.Combine(r.Root,"whitelist.json"));
                    Is(saved.Resolve(archon).Origin==RuleOrigin.SavedRoster && saved.Resolve(browser).Origin==RuleOrigin.SavedRoster &&
                        Get<Plan>(w,"plan").Targets.Single().Image==bnet && !r.Actions.Any(),"suggestions did not persist or changed the manual bench");w.Close();
                }
            }});
            Test("Personal setup starts with two empty user lists and edition-specific defaults",()=>{
                var s=Settings.Open(Path.Combine(Temp(),"whitelist.json"));
                Is(s.Allow.Count==0 && s.Block.Count==0 && !s.CloseUnlisted && !s.BenchAside && s.FolderExceptions.Count==0,"fresh roster rules");
#if RAIDERS
                const string profileFolder="RaidModeRaiders";
#else
                const string profileFolder="RaidModePersonal";
#endif
                Is(Paths.Equal(Paths.Data,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),profileFolder)) &&
                    !Paths.Equal(Paths.Data,Paths.SharedSessions),"shared rules profile");
                Is(RaidSuggestion.Products.Any(p=>p.Name=="World of Warcraft"),"missing suggestions");
                Is(s.UseRaidDefaults==Program.Raiders,"wrong defaults on first launch");
            });
            Test("A clean tester can bench and roster apps, close the window, and recover both lists on relaunch",()=>{using(var r=new Rig()){
                string file=Path.Combine(r.Root,"whitelist.json");
                string music=Path.Combine(r.Root,"Music.exe"),game=Path.Combine(r.Root,"Game.exe");
                File.Copy(fixture,music);File.Copy(fixture,game);
                r.Settings=Settings.Open(file);Store.Write(file,r.Settings);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var pick=typeof(MainWindow).GetMethod("ShowPickedApps",BindingFlags.Instance|BindingFlags.NonPublic);
                    pick.Invoke(w,new object[]{new[]{music}});Get<Button>(w,"blockProcess").PerformClick();
                    pick.Invoke(w,new object[]{new[]{game}});Get<Button>(w,"keep").PerformClick();
                    w.Close();
                }
                r.Settings=Settings.Open(file);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var views=Get<List<Button>>(w,"viewButtons");var grid=Get<GroupedProcessView>(w,"processes");
                    views[2].PerformClick();Is(grid.Items.Count==1 && grid.Items[0].SubItems[6].Text==music && grid.Items[0].SubItems[1].Text=="Benched","lost saved bench");
                    views[1].PerformClick();Is(grid.Items.Count==1 && grid.Items[0].SubItems[6].Text==game && grid.Items[0].SubItems[1].Text=="Rostered","lost saved roster");
                    var rows=Policy.Classify(new List<ProcessRow>{Row(880101,music),Row(880102,game)},r.Settings,new List<ProcessRow>());
                    Is(rows[0].Close && !rows[1].Close && !r.Actions.Any(),"reopened rules or preview behavior changed");w.Close();
                }
            }});
            Test("The Rostered view shows the moved app once and a bench edit there follows the next update",()=>{using(var r=new Rig()){
                string old=Path.Combine(r.Root,@"Battle.net\Battle.net.15000\Battle.net.exe"),current=old.Replace("15000","16000");
                Directory.CreateDirectory(Path.GetDirectoryName(old));Directory.CreateDirectory(Path.GetDirectoryName(current));
                File.Copy(fixture,old);r.Settings.UseRaidDefaults=true;r.Settings.AllowExecutable(old);File.Move(old,current);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    typeof(MainWindow).GetMethod("ShowPickedApps",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,new object[]{new[]{current}});
                    Get<List<Button>>(w,"viewButtons")[1].PerformClick();var grid=Get<GroupedProcessView>(w,"processes");
                    Is(grid.Items.Count==1 && grid.Items[0].SubItems[6].Text==current && grid.Items[0].SubItems[1].Text=="Rostered","duplicate or missing rostered app");
                    grid.Items[0].Selected=true;Application.DoEvents();Get<Button>(w,"blockProcess").PerformClick();
                    var saved=Settings.Open(Path.Combine(r.Root,"whitelist.json"));
                    Is(grid.Items.Count==0 && !saved.Allow.Any() && saved.Resolve(current.Replace("16000","17000")).Origin==RuleOrigin.SavedBench,"bench edit on updated roster lost");w.Close();
                }
            }});
            Test("The roster shows the updated app once and Clear rule on that row removes the saved bench",()=>{using(var r=new Rig()){
                string old=Path.Combine(r.Root,@"Voice\app-1.0\Voice.exe"),current=old.Replace("1.0","2.0");
                Directory.CreateDirectory(Path.GetDirectoryName(current));File.Copy(fixture,current);
                string file=Path.Combine(r.Root,"whitelist.json");r.Settings.BlockExecutable(old);Store.Write(file,r.Settings);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var pick=typeof(MainWindow).GetMethod("ShowPickedApps",BindingFlags.Instance|BindingFlags.NonPublic);
                    pick.Invoke(w,new object[]{new[]{current}});
                    Get<List<Button>>(w,"viewButtons")[2].PerformClick();var grid=Get<GroupedProcessView>(w,"processes");
                    Is(grid.Items.Count==1 && grid.Items[0].SubItems[6].Text==current && grid.Items[0].SubItems[1].Text=="Benched","duplicate or missing updated app");
                    grid.Items[0].Selected=true;Application.DoEvents();Get<Button>(w,"removeProcess").PerformClick();
                    Is(grid.Items.Count==0 && !Settings.Open(file).IsBlacklisted(old) && !Settings.Open(file).IsBlacklisted(current),"clear from relocated row did not stick");
                    w.Close();
                }
            }});
            Test("Session combines running, installed and saved apps, showing each rule and its actual action",()=>{using(var r=new Rig()){
                string file=Path.Combine(r.Root,"whitelist.json"),folder=Temp();
                string discord=Path.Combine(folder,"Discord.exe"),fan=Path.Combine(folder,"FanControl.exe"),wow=Path.Combine(Temp(),"Wow.exe");
                foreach(string path in new[]{discord,fan,wow}) File.Copy(fixture,path);
                r.Settings=Settings.Open(file);r.Settings.UseRaidDefaults=false;r.Settings.Allow.Add(folder+@"\*");r.Settings.Allow.Add(launcher);
                r.Settings.BlockExecutable(discord);r.Settings.RemoveExecutable(fan);Store.Write(file,r.Settings);
                byte[] before=File.ReadAllBytes(file);
                r.Live.Add(Row(705011,discord));r.Live.Add(Row(705012,discord));r.Live.Add(Row(705013,fan));
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make(),firstRun:true)){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Wait(()=>Get<bool>(w,"catalogScanned")&&!Get<bool>(w,"busy"));
                    var grid=Get<GroupedProcessView>(w,"processes");var views=Get<List<Button>>(w,"viewButtons");
                    var search=Get<TextBox>(w,"search");var tabs=Get<List<Button>>(w,"tabs");
                    Is(grid.Visible && Get<Button>(w,"scan").Visible && before.SequenceEqual(File.ReadAllBytes(file)),"first launch did not stay in Session");
                    Is(grid.Columns.Count==4 && grid.Columns[3].Text=="Details" && grid.Columns[3].DisplayIndex==1 &&
                        grid.Columns[2].Text=="Action" && grid.Columns[1].Text=="Rule","wrong Session columns");
                    var initialSize=w.Size;w.Size=w.MinimumSize;Application.DoEvents();
                    var viewport=w.RectangleToScreen(w.ClientRectangle);
                    foreach(var last in views.Cast<Control>().Concat(tabs).Concat(new Control[]{search,Get<Button>(w,"manageRules"),Get<Button>(w,"removeProcess"),Get<ComboBox>(w,"filter"),Get<Button>(w,"flexProcess")}))
                        Is(viewport.Contains(last.RectangleToScreen(last.ClientRectangle)) && last.Width>20,"clipped "+last.Text+" at minimum width");
                    w.Size=initialSize;Application.DoEvents();
                    var catalog=Get<List<AppEntry>>(w,"catalog");catalog.Add(new AppEntry{Image=wow,Name="WoW client",Source="Game install"});
                    typeof(MainWindow).GetMethod("FillApps",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(w,null);
                    Func<string,ListViewItem> item=path=>grid.Items.Cast<ListViewItem>().First(i=>Paths.Equal(i.SubItems[6].Text,path));
                    views[2].PerformClick();var group=item(discord);
                    Is(grid.Items.Count==1 && group.Text.Contains("(2)") && group.SubItems[1].Text=="Benched" && group.SubItems[2].Text=="Close","blacklisted group duplicated or missing");
                    if(!SystemInformation.HighContrast)Is(group.SubItems[1].BackColor==RaidTheme.BenchBg,"Benched tint");
                    CheckRowDetails(w,group,discord);
                    ClickDisclosure(grid,group);Is(grid.Items.Count==3 && grid.Items[1].Text.Contains("PID"),"process identity hidden after expansion");
                    CheckRowDetails(w,grid.Items[1],"705011");
                    views[1].PerformClick();Is(item(launcher).SubItems[2].Text=="Not running" && item(folder+@"\*").SubItems[2].Text=="Folder rule","missing closed app or folder");
                    if(!SystemInformation.HighContrast)Is(item(launcher).SubItems[1].BackColor==RaidTheme.GreenBg,"Rostered tint");
                    views[3].PerformClick();Is(item(fan).SubItems[1].Text=="Flex" && item(fan).SubItems[2].Text=="Keep","free agent action");
                    CheckRowDetails(w,item(fan),fan);
                    views[4].PerformClick();search.Text=wow;
                    Is(grid.Items.Count==1 && item(wow).SubItems[2].Text=="Not running","missing detected suggestion");
                    CheckRowDetails(w,item(wow),"matches the built-in entry for World of Warcraft");
                    item(wow).Selected=true;tabs[1].PerformClick();
                    Is(tabs[1].Text=="Details" && Get<TextBox>(w,"selectedDetails").Text.Contains(wow),"selection details unavailable");
                    tabs[0].PerformClick();Get<Button>(w,"keep").PerformClick();
                    Is(Settings.Open(file).Allow.Contains(wow) && grid.Items.Count==0,"rostered app still pending");
                    views[2].PerformClick();search.Clear();Is(item(discord).SubItems[1].Text=="Benched" && r.Settings.FolderExceptions.Contains(fan),"existing choices changed");
                    w.Close();
                }
            }});
            Test("Clear rule handles multi-select in each list, including blocked apps in an allowed folder; Clear all persists without selection",()=>{using(var r=new Rig()){
                string file=Path.Combine(r.Root,"whitelist.json"),folder=Temp();
                string one=Path.Combine(folder,"one.exe"),two=Path.Combine(Temp(),"two.exe"),three=Path.Combine(Temp(),"three.exe");
                foreach(string path in new[]{one,two,three})File.Copy(fixture,path);
                r.Settings=Settings.Open(file);r.Settings.Allow.AddRange(new[]{folder+@"\*",fixture,launcher});
                r.Settings.BlockExecutable(one);r.Settings.BlockExecutable(two);r.Settings.BlockExecutable(three);
                r.Settings.CloseUnlisted=true;r.Settings.PauseRun=r.Settings.PauseTasks=r.Settings.PauseFiles=false;Store.Write(file,r.Settings);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var grid=Get<GroupedProcessView>(w,"processes");var views=Get<List<Button>>(w,"viewButtons");
                    var clear=Get<Button>(w,"removeProcess");var all=Get<ToolStripMenuItem>(w,"clearAll");var flex=Get<Button>(w,"flexProcess");
                    Func<string,ListViewItem> item=path=>grid.Items.Cast<ListViewItem>().Single(i=>Paths.Equal(i.SubItems[6].Text,path));
                    Is(clear.Parent==flex.Parent && clear.Left>=flex.Right,"Clear rule placement");
                    views[2].PerformClick();item(one).Selected=true;item(two).Selected=true;clear.PerformClick();
                    var saved=Settings.Open(file);
                    Is(grid.Items.Count==1 && item(three).SubItems[1].Text=="Benched" && saved.Block.SequenceEqual(new[]{three}) &&
                        saved.MatchingRule(one)==null && saved.FolderExceptions.Contains(one),"clearing blacklist restored inherited roster or removed another rule");
                    views[1].PerformClick();item(fixture).Selected=true;item(launcher).Selected=true;clear.PerformClick();
                    Is(grid.Items.Count==1 && item(folder+@"\*").SubItems[1].Text=="Rostered","clearing whitelist removed other rule");
                    views[3].PerformClick();foreach(string path in new[]{one,two,fixture,launcher})Is(item(path).SubItems[1].Text=="Flex","cleared app missing from Free agents");
                    views[2].PerformClick();Is(grid.SelectedItems.Count==0 && all.Enabled && !clear.Enabled,"Clear all depended on selection");
                    Confirm(w,false,"clearAll","Clear all rules?","Clear all Rostered and Benched rules");
                    Is(Settings.Open(file).Block.Contains(three),"cancelling clear all erased rules");
                    Confirm(w,true,"clearAll","Clear all rules?","Clear all Rostered and Benched rules");
                    saved=Settings.Open(file);
                    Is(!saved.Allow.Any() && !saved.Block.Any() && !saved.FolderExceptions.Any() && saved.CloseUnlisted && !saved.PauseRun,"rules or preferences after clearing all");
                    Is(!all.Enabled && grid.Items.Count==0 && !Get<Button>(w,"start").Enabled,"old actions remained enabled");
                    views[3].PerformClick();Is(item(three).SubItems[1].Text=="Flex" && !r.Actions.Any(),"clear all affected processes");
                    w.Close();
                }
                r.Settings=Settings.Open(file);
                using(var reopened=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    reopened.ShowInTaskbar=false;reopened.StartPosition=FormStartPosition.Manual;reopened.Location=new Point(-3000,-3000);reopened.Show();Application.DoEvents();
                    Is(!Get<ToolStripMenuItem>(reopened,"clearAll").Enabled && Get<CheckBox>(reopened,"full").Checked && !Get<CheckBox>(reopened,"pause").Checked,"rules or preferences failed to reload");
                    reopened.Close();
                }
            }});
        }
        static void GuiTests()
        {
            Test("Preview first launch opens an editable disposable whitelist and preserves the owner's profile",()=>{using(var r=new Rig()){
                r.Settings.Allow.Add(launcher);
                string profile=Path.Combine(r.Root,"whitelist.json");
                Store.Write(profile,r.Settings);
                byte[] before=File.ReadAllBytes(profile);
                string wow=Path.Combine(Temp(),"Wow.exe");File.Copy(fixture,wow);
                using(var owner=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    owner.ShowInTaskbar=false;owner.StartPosition=FormStartPosition.Manual;owner.Location=new Point(-3000,-3000);owner.Show();Application.DoEvents();
                    Get<List<Button>>(owner,"tabs")[1].PerformClick();
                    var open=Get<Button>(owner,"previewSetup");Is(open.Visible && open.Enabled,"preview entry missing");
                    Exception problem=null;
                    owner.BeginInvoke(new Action(()=>{
                        var w=Application.OpenForms.OfType<MainWindow>().Single(f=>f!=owner);
                        try {
                            w.Location=owner.Location;
                            Wait(()=>Get<bool>(w,"catalogScanned")&&!Get<bool>(w,"busy"));
                            var filter=Get<ComboBox>(w,"libraryFilter");
                            var settings=Get<Settings>(w,"settings");
                            Is(filter.Text=="Suggested apps" && settings.Allow.Count==0 && Get<string>(w,"root")==null,"opened a persistent profile");
                            var catalog=Get<List<AppEntry>>(w,"catalog");catalog.Clear();
                            catalog.Add(new AppEntry{Name="WoW",Image=wow,Source="Game install"});
                            filter.SelectedItem="All software";filter.SelectedItem="Suggested apps";
                            Get<Button>(w,"applySuggestions").PerformClick();
                            Is(settings.Allow.SequenceEqual(new[]{wow}),"preview edit failed");
                            Get<List<Button>>(w,"tabs")[0].PerformClick();Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                            Is(Get<Plan>(w,"plan")!=null && !Get<Button>(w,"start").Enabled,"preview plan or activation state incorrect");
                        } catch(Exception ex){problem=ex;} finally {w.Close();}
                    }));
                    open.PerformClick();if(problem!=null)throw problem;
                    Is(r.Settings.Allow.SequenceEqual(new[]{launcher}) && before.SequenceEqual(File.ReadAllBytes(profile)),"owner profile changed");
                    using(var next=MainWindow.CreateFirstLaunchPreview()) Is(Get<Settings>(next,"settings").Allow.Count==0,"test choices leaked to next preview");
                    owner.Close();
                }
            }});
            Test("Apply suggestions adds visible detected paths together and preserves existing rules and exclusions",()=>{using(var r=new Rig()){
                string folder=Temp(),discord=Path.Combine(folder,"Discord.exe");
                string wow=Path.Combine(Temp(),"Wow.exe"),classic=Path.Combine(Temp(),"WowClassic.exe"),battleNet=Path.Combine(Temp(),"Battle.net.exe"),fan=Path.Combine(Temp(),"FanControl.exe");
                foreach(string path in new[]{discord,wow,classic,battleNet,fan})File.Copy(fixture,path);
                r.Settings.Allow.AddRange(new[]{launcher,folder+@"\*"});r.Settings.FolderExceptions.Add(discord);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make(),firstRun:true)){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Wait(()=>!Get<bool>(w,"busy"));
                    var catalog=Get<List<AppEntry>>(w,"catalog");catalog.Clear();
                    foreach(string path in new[]{wow,classic,discord,battleNet,fan,launcher})
                        catalog.Add(new AppEntry{Name=Path.GetFileNameWithoutExtension(path),Image=path,Source="Running"});
                    var search=Get<TextBox>(w,"search");search.Text="World of Warcraft";
                    var apply=Get<Button>(w,"applySuggestions");
                    Is(apply.Visible && apply.Enabled && apply.Text.Contains("(2)"),"wrong filtered suggestion count");
                    apply.PerformClick();
                    string file=Path.Combine(r.Root,"whitelist.json");
                    var saved=Settings.Open(file);
                    Is(!apply.Enabled && saved.Allow.Count==4 && saved.Allow.Contains(wow) && saved.Allow.Contains(classic),"filtered bulk edit failed");
                    search.Clear();Is(apply.Enabled && apply.Text.Contains("(1)"),"already listed or excluded path counted");
                    apply.PerformClick();saved=Settings.Open(file);
                    Is(!apply.Enabled && saved.Allow.Count==5 && saved.Allow.Contains(battleNet) && !saved.Allow.Contains(fan) && saved.Allow.Contains(launcher) &&
                        saved.FolderExceptions.Contains(discord) && saved.MatchingRule(discord)==null,"bulk edit changed another rule");
                    Get<ComboBox>(w,"libraryFilter").SelectedItem="All software";Is(!apply.Visible,"bulk action outside suggestions");
                    w.Close();
                }
            }});
            Test("First launch shows optional suggestions; only chosen paths reload in that raider's profile",()=>{using(var r=new Rig()){
                string file=Path.Combine(r.Root,"whitelist.json");
                Store.Write(file,r.Settings);
                string wow=Path.Combine(Temp(),"Wow.exe"),discord=Path.Combine(Temp(),"Discord.exe");
                File.Copy(fixture,wow);File.Copy(fixture,discord);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make(),firstRun:true)){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Wait(()=>!Get<bool>(w,"busy"));
                    var filter=Get<ComboBox>(w,"libraryFilter");
                    Is(filter.Visible && filter.Text=="Suggested apps" && Get<bool>(w,"catalogScanned"),"first-run suggestions not scanned");
                    var catalog=Get<List<AppEntry>>(w,"catalog");catalog.Clear();
                    catalog.Add(new AppEntry{Name="WoW",Image=wow,Source="Game install"});
                    catalog.Add(new AppEntry{Name="Discord",Image=discord,Source="Running"});
                    filter.SelectedItem="All software";filter.SelectedItem="Suggested apps";
                    var grid=Get<ListView>(w,"apps");
                    Func<string,ListViewItem> row=name=>grid.Items.Cast<ListViewItem>().Single(i=>i.Text==name);
                    Is(grid.SelectedItems.Count==0 && Settings.Open(file).Allow.Count==0 && r.Actions.Count==0,"suggestions changed policy");
                    row("Battle.net").Selected=true;
                    Is(!Get<Button>(w,"addApp").Enabled,"undetected suggestion could be added");
                    grid.SelectedItems.Clear();row("World of Warcraft").Selected=true;
                    Get<Button>(w,"addApp").PerformClick();
                    Is(row("World of Warcraft").SubItems[1].Text=="Listed app" && row("Discord").SubItems[1].Text=="Suggested","unselected app added");
                    row("World of Warcraft").Selected=true;Get<Button>(w,"removeRule").PerformClick();
                    Is(Settings.Open(file).Allow.Count==0 && row("World of Warcraft").SubItems[1].Text=="Suggested","suggestion removal not saved");
                    row("World of Warcraft").Selected=true;Get<Button>(w,"addApp").PerformClick();w.Close();
                }
                r.Settings=Settings.Open(file);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Is(Get<Button>(w,"scan").Visible && !Get<bool>(w,"catalogScanned"),"returning launch repeated setup");
                    Get<List<Button>>(w,"tabs")[1].PerformClick();Get<ComboBox>(w,"libraryFilter").SelectedItem="Whitelist only";
                    var grid=Get<ListView>(w,"apps");
                    Is(grid.Items.Count==1 && (string)grid.Items[0].Tag==wow,"returning whitelist not populated");
                    Is(Settings.Open(Path.Combine(Temp(),"whitelist.json")).Allow.Count==0,"choice leaked to a fresh profile");w.Close();
                }
            }});
            Test("Ten instances collapse into one expandable app with intact PID and close identities",()=>{using(var r=new Rig()){
                string other=Path.Combine(Temp(),Path.GetFileName(fixture));
                for(int i=0;i<10;i++)r.Live.Add(Row(510000+i,i%2==0?fixture:fixture.ToUpperInvariant()));
                r.Live.Add(Row(510100,other));
                foreach(int id in new[]{510101,510102}) {
                    var unknown=Row(id,fixture);unknown.Image=null;r.Live.Add(unknown);
                }
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");var plan=Get<Plan>(w,"plan");
                    Is(grid.Items.Count==4 && grid.Items[fixture].Text.Contains("(10)"),"wrong count, duplicate path or unknown identities merged");
                    Is(plan.Targets.Count()==11 && plan.Rows.Count==13,"close plan was aggregated");
                    ClickDisclosure(grid,grid.Items[fixture]);
                    Is(grid.Items.Count==14,"mouse did not expand the group");
                    ClickHeader(grid,3);ClickHeader(grid,3);
                    int headerIndex=grid.Items[fixture].Index;
                    var childIds=grid.Items.Cast<ListViewItem>().Skip(headerIndex+1).Take(10).Select(i=>Int32.Parse(i.SubItems[3].Text));
                    Is(childIds.SequenceEqual(Enumerable.Range(510000,10).Reverse()),"PID sorting separated children or put header below children");
                    grid.Focus();grid.Items[headerIndex+5].Focused=true;
                    // Supply the fixture's unmodified arrow key independently of the user's desktop keyboard state.
                    var keyDown=typeof(GroupedProcessView).GetMethod("OnKeyDown",BindingFlags.Instance|BindingFlags.NonPublic);
                    keyDown.Invoke(grid,new object[]{new KeyEventArgs(Keys.Left)});
                    Is(grid.Items.Count==4&&grid.FocusedItem==grid.Items[fixture],"keyboard collapse lost app focus, rows="+grid.Items.Count+", focus="+(grid.FocusedItem==null?"none":grid.FocusedItem.Name));
                    keyDown.Invoke(grid,new object[]{new KeyEventArgs(Keys.Right)});
                    Is(grid.Items.Count==14,"keyboard expand");
                    ClickDisclosure(grid,grid.Items[fixture]);
                    Is(grid.Items.Count==4&&Get<Plan>(w,"plan")==plan&&r.Actions.Count==0,"collapse altered the plan");
                    w.Close();
                }
            }});
            Test("App summary, filtered counts, refresh and group-level edits retain exact executable scope",()=>{using(var r=new Rig()){
                r.Settings.Allow.Add(launcher);r.Live.Add(Row(520000,launcher));
                for(int i=0;i<5;i++){
                    var row=Row(520001+i,fixture);if(i<2)row.Parent=520000;r.Live.Add(row);
                }
                string other=Path.Combine(Temp(),Path.GetFileName(fixture));r.Live.Add(Row(520020,other));
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");var filter=Get<ComboBox>(w,"filter");
                    Is(grid.Items[fixture].SubItems[2].Text=="Mixed"&&grid.Items[fixture].ToolTipText.Contains("3 to close, 2 kept"),"misleading action summary");
                    filter.SelectedIndex=1;Is(grid.Items[fixture].Text.Contains("(3)")&&grid.Items[fixture].SubItems[2].Text=="Close","close group includes kept instances");
                    filter.SelectedIndex=2;Is(grid.Items[fixture].Text.Contains("(2)")&&grid.Items[fixture].SubItems[2].Text=="Keep","kept group includes close targets");
                    filter.SelectedIndex=0;grid.Items[fixture].Selected=true;Get<Button>(w,"keep").PerformClick();
                    Is(r.Settings.Allow.Contains(fixture)&&!r.Settings.Allow.Contains(other)&&grid.Items[fixture].SubItems[2].Text=="Keep","group edit crossed paths or failed");
                    Is(grid.Items[fixture].Selected&&Get<Plan>(w,"plan")==null,"edit lost selection or retained stale approval");
                    Get<Button>(w,"removeProcess").PerformClick();Is(!r.Settings.Allow.Contains(fixture),"group removal failed");
                    ClickDisclosure(grid,grid.Items[fixture]);r.Live.RemoveAt(3);
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    Is(grid.Items[fixture].Text.Contains("(4)")&&grid.Items.Count==7,"rescan lost expansion or retained old count");
                    Is(!grid.Items.ContainsKey("520003")&&r.Actions.Count==0,"exited instance shown or view closed an app");w.Close();
                }
            }});
            Test("Header clicks group whitelist status, reverse direction and sort numeric PIDs",()=>{using(var r=new Rig()){
                string folder=Temp();
                r.Settings.Allow.AddRange(new[]{launcher,folder+@"\*"});
                r.Live.AddRange(new[]{Row(240105,Path.Combine(Temp(),"Other.exe")),Row(832,Path.Combine(folder,"Editor.exe")),Row(9101,launcher),
                    Row(52094,@"D:\Tools\Bitdefender\agent.exe"),Row(76,fixture)});
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");var plan=Get<Plan>(w,"plan");
                    grid.Items.Cast<ListViewItem>().Single(i=>((ProcessRow)i.Tag).Id==76).Selected=true;
                    Func<string[]> statuses=()=>grid.Items.Cast<ListViewItem>().Select(i=>i.SubItems[1].Text).ToArray();
                    string[] expected={"Listed app","Listed folder","Locked","Off whitelist","Off whitelist"};
                    ClickHeader(grid,1);Is(statuses().SequenceEqual(expected),"whitelist categories not grouped");
                    ClickHeader(grid,1);Is(statuses().SequenceEqual(expected.Reverse()),"reverse grouping");
                    Is(Get<Plan>(w,"plan")==plan && r.Actions.Count==0,"sorting changed the approved snapshot");
                    ClickHeader(grid,3);Is(grid.Items.Cast<ListViewItem>().Select(i=>((ProcessRow)i.Tag).Id).SequenceEqual(new[]{76,832,9101,52094,240105}),"lexical PID order");
                    Is(((ProcessRow)grid.SelectedItems[0].Tag).Id==76,"sort moved selection to another identity");
                    Is(grid.Columns[1].Text=="Whitelist" && grid.Columns[3].Text.Contains("\u2191"),"header indicator");
                    ClickHeader(grid,1);Get<Button>(w,"keep").PerformClick();
                    Is(statuses().SequenceEqual(new[]{"Listed app","Listed app","Listed folder","Locked","Off whitelist"}),"edit lost active sort");
                    Is(((ProcessRow)grid.SelectedItems[0].Tag).Id==76,"edit restored the wrong sorted selection");
                    Get<ComboBox>(w,"filter").SelectedIndex=2;Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    Is(statuses().SequenceEqual(new[]{"Listed app","Listed app","Listed folder","Locked"}),"rescan or filter lost order");
                    w.Close();
                }
            }});
            Test("Whitelist library retains header order through searches and page changes",()=>{using(var r=new Rig()){
                r.Settings.Allow.AddRange(new[]{@"D:\Games\Zeta\alpha.exe",@"D:\Games\Alpha\*",@"D:\Games\Beta\beta.exe"});
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var tabs=Get<List<Button>>(w,"tabs");tabs[1].PerformClick();var grid=Get<ListView>(w,"apps");
                    ClickHeader(grid,2);ClickHeader(grid,2);
                    Is(grid.Items[0].SubItems[2].Text=="Folder rule","folder rule not grouped");
                    Get<TextBox>(w,"search").Text="Alpha";Is(grid.Items.Count==2&&grid.Items[0].SubItems[2].Text=="Folder rule","search discarded sort");
                    tabs[0].PerformClick();tabs[1].PerformClick();Is(grid.Items[0].SubItems[2].Text=="Folder rule","navigation discarded sort");
                    w.Close();
                }
            }});
            Test("Activity headers sort full timestamps and keep newest entries when sorted by event",()=>{using(var r=new Rig()){
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<List<Button>>(w,"tabs")[2].PerformClick();var grid=Get<ListView>(w,"events");
                    grid.Items.Clear();var history=new Queue<ListViewItem>();var midnight=DateTime.Today.ToUniversalTime();
                    MainWindow.AddEvent(grid,history,3,midnight.AddMinutes(-2),"Zulu");
                    MainWindow.AddEvent(grid,history,3,midnight.AddMinutes(-1),"Alpha");
                    MainWindow.AddEvent(grid,history,3,midnight.AddMinutes(1),"Bravo");
                    ClickHeader(grid,0);Is(grid.Items[0].SubItems[1].Text=="Zulu"&&grid.Items[2].SubItems[1].Text=="Bravo","time sort across midnight");
                    ClickHeader(grid,1);MainWindow.AddEvent(grid,history,3,midnight.AddMinutes(2),"Charlie");
                    Is(grid.Items.Cast<ListViewItem>().Select(i=>i.SubItems[1].Text).SequenceEqual(new[]{"Alpha","Bravo","Charlie"}),"new event order or eviction");
                    w.Close();
                }
            }});
            Test("Preview selections persist exact whitelist edits and invalidate the plan",()=>{using(var r=new Rig()){
                r.Live.Add(Row(156,fixture));
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");grid.Items[0].Selected=true;Application.DoEvents();Get<Button>(w,"keep").PerformClick();
                    string file=Path.Combine(r.Root,"whitelist.json");
                    Is(Settings.Open(file).Allow.Contains(fixture)&&Get<Plan>(w,"plan")==null,"edit lost or stale approval enabled");
                    Get<List<Button>>(w,"tabs")[1].PerformClick();var apps=Get<ListView>(w,"apps");apps.Items[0].Selected=true;Application.DoEvents();
                    Get<Button>(w,"removeRule").PerformClick();Is(Settings.Open(file).Allow.Count==0,"removal lost");w.Close();
                }
            }});
            Test("All processes supports repeated multi-select edits, helpers and locked rows",()=>{using(var r=new Rig()){
                var parent=Row(200001,launcher);r.Settings.Allow.Add(launcher);
                var helper=Row(200002,fixture);helper.Parent=parent.Id;
                var duplicate=Row(200003,fixture);
                var locked=Row(200004,@"D:\Tools\NVIDIA Corporation\NvContainer\container.exe");
                r.Live.AddRange(new[]{parent,helper,duplicate,locked});
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<List<Button>>(w,"tabs")[1].PerformClick();Get<Button>(w,"running").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");var add=Get<Button>(w,"keep");var remove=Get<Button>(w,"removeProcess");
                    Is(grid.Items.Count==3&&Get<ComboBox>(w,"filter").Text=="All processes","missing grouped process picker");
                    ClickDisclosure(grid,grid.Items[fixture]);grid.SelectedItems.Clear();
                    Func<int,ListViewItem> item=id=>grid.Items.Cast<ListViewItem>().Single(i=>i.Tag is ProcessRow && ((ProcessRow)i.Tag).Id==id);
                    item(locked.Id).Selected=true;Is(!add.Enabled&&!remove.Enabled,"protected driver row unlocked");
                    item(helper.Id).Selected=true;Is(add.Enabled,"cannot explicitly allow an inherited helper");item(duplicate.Id).Selected=true;
                    add.PerformClick();
                    Is(grid.Items.Count==5&&grid.SelectedItems.Count==3&&remove.Enabled,"selection lost during edit");
                    string profile=Path.Combine(r.Root,"whitelist.json");
                    Is(Settings.Open(profile).Allow.Count==2&&item(duplicate.Id).SubItems[1].Text=="Listed app","duplicate rule or stale label");
                    remove.PerformClick();
                    Is(Settings.Open(profile).Allow.SequenceEqual(new[]{launcher}),"removed unrelated rule");
                    Is(item(helper.Id).SubItems[2].Text=="Keep"&&item(duplicate.Id).SubItems[2].Text=="Close","helper decisions");
                    Is(!Get<Button>(w,"start").Enabled&&r.Actions.Count==0,"edits authorized a stale plan");w.Close();
                }
            }});
            Test("Windows components stay protected and hidden across process views and whitelist edits",()=>{using(var r=new Rig()){
                var game=Row(301001,launcher);
                var shell=Row(301002,Path.Combine(Paths.Win,@"System32\shell-helper.exe"));shell.Parent=game.Id;
                var child=Row(301003,@"D:\Tools\game-helper.exe");child.Parent=shell.Id;
                var critical=Row(301004,@"D:\OS\required.exe");critical.Critical=true;
                var unreadable=Row(301005,fixture);unreadable.Name="csrss";unreadable.Sid=null;unreadable.Image=null;
                var app=Row(301006,fixture);
                var security=Row(301007,@"D:\Tools\Bitdefender\agent.exe");
                var defender=Row(301008,Path.Combine(Paths.PF,@"Windows Defender\worker.exe"));
                r.Live.AddRange(new[]{game,shell,child,critical,unreadable,app,security,defender});r.Settings.Allow.Add(launcher);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));
                    var grid=Get<ListView>(w,"processes");var filter=Get<ComboBox>(w,"filter");var complete=Get<Plan>(w,"plan");
                    Func<int[]> visible=()=>grid.Items.Cast<ListViewItem>().Select(i=>((ProcessRow)i.Tag).Id).OrderBy(id=>id).ToArray();
                    Is(w.Text=="Reverse's Raid Mode","wrong window title");
                    Is(complete.Rows.Count==8 && complete.Targets.Single().Id==app.Id,"incomplete scan or protected process targeted");
                    Is(visible().SequenceEqual(new[]{game.Id,child.Id,app.Id,security.Id}),"required components appeared or user apps disappeared");
                    Is(Get<Label>(w,"sub").Text.Contains("3 kept"),"kept count includes hidden components");
                    filter.SelectedIndex=2;Is(visible().SequenceEqual(new[]{game.Id,child.Id,security.Id}),"incorrect kept view");
                    filter.SelectedIndex=1;Is(visible().SequenceEqual(new[]{app.Id}),"incorrect close view");
                    grid.Items[0].Selected=true;Get<Button>(w,"keep").PerformClick();filter.SelectedIndex=0;ClickHeader(grid,1);
                    Is(visible().SequenceEqual(new[]{game.Id,child.Id,app.Id,security.Id}),"hidden rows returned after editing or sorting");
                    Is(grid.Items.Cast<ListViewItem>().All(i=>!((ProcessRow)i.Tag).Close),"helper ancestry broke after editing");
                    Is(Get<Label>(w,"sub").Text.Contains("4 processes"),"last scan count includes hidden components");w.Close();
                }
            }});
            Test("Removing a folder-listed app exempts that executable alone and can be undone",()=>{using(var r=new Rig()){
                string folder=Path.GetDirectoryName(fixture)+@"\*";r.Settings.Allow.AddRange(new[]{folder,fixture});
                r.Live.Add(Row(200010,fixture));r.Live.Add(Row(200011,launcher));
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));var grid=Get<ListView>(w,"processes");
                    grid.Items.Cast<ListViewItem>().Single(i=>Paths.Equal(((ProcessRow)i.Tag).Image,fixture)).Selected=true;
                    Get<Button>(w,"removeProcess").PerformClick();string profile=Path.Combine(r.Root,"whitelist.json");var saved=Settings.Open(profile);
                    Is(saved.Allow.SequenceEqual(new[]{folder})&&saved.FolderExceptions.SequenceEqual(new[]{fixture}),"folder rule incorrectly changed");
                    var checkedRows=Policy.Classify(r.Live,saved,new List<ProcessRow>());Is(checkedRows[0].Close&&!checkedRows[1].Close,"sibling affected");
                    var refreshed=Get<Session>(w,"session").Scan();Is(refreshed.Targets.Single().Id==200010,"backend did not honor exception");
                    Get<Button>(w,"keep").PerformClick();saved=Settings.Open(profile);
                    Is(saved.FolderExceptions.Count==0&&saved.Allow.SequenceEqual(new[]{folder})&&saved.MatchingRule(fixture)==folder,"folder membership not restored");w.Close();
                }
            }});
            Test("A failed whitelist write preserves the old policy and displayed membership",()=>{using(var r=new Rig()){
                r.Live.Add(Row(200020,fixture));string profile=Path.Combine(r.Root,"whitelist.json");Directory.CreateDirectory(profile);
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));var grid=Get<ListView>(w,"processes");grid.Items[0].Selected=true;
                    Get<Button>(w,"keep").PerformClick();
                    Is(r.Settings.Allow.Count==0&&grid.Items[0].SubItems[1].Text=="Off whitelist","failed write changed policy");
                    Is(Get<Label>(w,"summary").Text.Contains("could not be saved")&&!Get<Button>(w,"start").Enabled,"save failure hidden");w.Close();
                }
            }});
            Test("Desktop preview, cancel, confirm, active state and end through UI",()=>{using(var r=new Rig()){
                r.Live.Add(Row(101,fixture));
                using(var w=new MainWindow(r.Settings,r.Root,output=>{r.Report=output;return r.Make();})){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));Is(Get<Plan>(w,"plan")!=null,"Scan: "+Get<Label>(w,"summary").Text);
                    Is(Get<ListView>(w,"processes").Items.Count==1,"preview rows");Is(!r.Actions.Any(),"scan acted");
                    Confirm(w,false);Is(!r.Actions.Any()&&!Get<Session>(w,"session").Active,"cancel acted");
                    Is(Get<Button>(w,"start").Enabled,"Start disabled; elevated="+Native.Elevated);
                    Confirm(w,true);Wait(()=>!Get<bool>(w,"busy"));Is(Get<Session>(w,"session").Active,"Start: "+Get<Label>(w,"summary").Text);Is(r.Actions.SequenceEqual(new[]{101}),"unreviewed action");
                    Get<Button>(w,"end").PerformClick();Wait(()=>!Get<bool>(w,"busy")&&!Get<Session>(w,"session").Active);w.Close();
                }
            }});
            Test("Desktop exposes interrupted state and retryable recovery",()=>{using(var r=new Rig()){
                r.Sources.Add();r.Start();r.Engine.Dispose();r.Sources.OnRestore=i=>{throw new IOException("fixture conflict");};
                using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    var end=Get<Button>(w,"end");Is(end.Text=="Recover session"&&end.Enabled,"missing recover action");end.PerformClick();
                    Wait(()=>!Get<bool>(w,"busy"));Is(Get<Label>(w,"summary").Text.Contains("fixture conflict"),"hidden recovery failure");
                    r.Sources.OnRestore=i=>{};Is(end.Enabled&&end.Visible,"Recover button unavailable");end.PerformClick();Wait(()=>!Get<bool>(w,"busy"));Is(!r.Engine.NeedsRecovery,"retry failed: "+Get<Label>(w,"summary").Text);w.Close();
                }
            }});
            Test("Desktop timeout ends the fixture session and restores its journal",()=>{using(var r=new Rig()){
                r.Sources.Add();using(var w=new MainWindow(r.Settings,r.Root,output=>r.Make())){
                    w.ShowInTaskbar=false;w.StartPosition=FormStartPosition.Manual;w.Location=new Point(-3000,-3000);w.Show();Application.DoEvents();
                    Get<Button>(w,"scan").PerformClick();Wait(()=>!Get<bool>(w,"busy"));Confirm(w,true);
                    Wait(()=>!Get<bool>(w,"busy"));var engine=Get<Session>(w,"session");Is(engine.Active,"not started");
                    engine.Started=DateTime.UtcNow.AddDays(-1);Wait(()=>!engine.Active&&!engine.NeedsRecovery&&!Get<bool>(w,"busy"));
                    Is(Get<Label>(w,"summary").Text.Contains("time limit"),"timeout not reported");w.Close();
                }
            }});
        }
    }
}
