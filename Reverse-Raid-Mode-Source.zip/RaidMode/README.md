# Reverse's Raid Mode for Windows

Development build 0.8 for 64-bit Windows 11. Open **Reverse's Raid Mode.exe** normally. Existing users keep their saved whitelist and recovery journal. The window owns the session. It uses Windows Forms, the .NET Framework supplied with Windows, and Windows process APIs. The executable can be moved to a folder of your choice. Settings follow your Windows account.

## Set up your raid apps

First launch opens **Whitelist → Suggested apps** and scans the local PC. The editable whitelist starts empty. Click **Apply suggestions** to add all detected executables marked **Suggested** in the current search. The button shows how many it will add. You can also select individual rows and click **Add to whitelist**. A suggestion is a product name matched to a local executable. Windows protections apply immediately. Edits save automatically, including removal of the last app. If a product is marked **Not detected**, launch it and rescan or use **Browse .exe**.

1. Open **Whitelist → All processes** to pick from the last process scan, or start one if needed. Select one or more rows and choose **Add to whitelist** or **Remove from whitelist**. Edits apply to the executable path across all its instances. Removing an executable covered by a folder rule creates a path-specific exception. The other executables in the folder retain their coverage. Add the executable back to undo the exception. The Action and Reason columns show independent protections, including helpers of an allowed parent.
2. **Whitelist → Scan software** also finds registered apps, uninstall display icons and Start menu shortcuts. Use **Browse .exe** for a portable game. For an app that changes its executable path with each update, choose **Allow folder** and review the installation directory. **Whitelist only → Remove from whitelist** removes selected saved rules, including entire folder rules. The All software view lists folder exceptions that you can add back later.
3. Open **System rules** to see the built-in protections and session limits. The app keeps Windows components, critical processes, the shell, security and driver components covered by the Hermes rules, and its own launch ancestry. Process ownership, session, executable path and creation time must all be readable before a process can be selected.

Existing desktop profiles load from `%LOCALAPPDATA%\RaidModeDesktop\whitelist.json` on subsequent runs. Each Windows account has a separate profile. Users can return to **Suggested apps** at any time to review new installations.

## Preview and start

To try setup again, open **Whitelist → Preview first launch**. The preview opens **Suggested apps** with an empty whitelist. Add or remove apps and scan a raid plan. The preview keeps your choices in memory until you close it. You can also open it directly from PowerShell with `& ".\Reverse's Raid Mode.exe" --first-launch-preview`.

Repeated instances appear in one row, such as **Battle.net (10)**. Click its arrow to see each PID, window type and planned action. Click again to collapse. With the app row selected, Right expands it and Left collapses it. **Mixed** means individual processes have different values in that column. Counts reflect the current view. Separate executable paths have separate rows, even when their filenames match.

Click a column header to sort the displayed rows. **Whitelist** brings listed apps and folders together, **Action** groups Keep and Close, and **PID** sorts by number. Click the same header again to reverse direction. Each table remembers its sort while the window is open, including after rescanning or editing rules.

1. Choose **Session → Scan & preview**. Use the dropdown to inspect **Will close**, **Kept**, **All processes**, **Startup changes**, and **Inventory notes**. Rows include background apps. The process list and its counts exclude required Windows components. The guard continues to protect them. Scroll horizontally or hover over a row to see longer paths and reasons.
2. All processes opens by default. Select a row to edit its whitelist membership. The list reflects each edit immediately. Run **Scan & preview** again after editing to authorize a fresh plan. A preview expires after five minutes. A new closure candidate, changed identity, or changed policy can require another scan.
3. Save open work. **Start raid** shows the counts, guard scope, plan ID, and timeout for your confirmation. Windowed targets get a normal close request. Survivors can be forcibly terminated after the configured grace period. Background processes can be forcibly closed directly. The default grace period is eight seconds.

For a scan-only test from PowerShell, run `& ".\Reverse's Raid Mode.exe" --preview`. That mode permits inventory and review with activation and whitelist editing disabled.

## During a raid

**Guard newly launched unlisted apps** is enabled by default. The guard checks for new processes at the configured interval, three seconds with the Hermes settings. A new program can appear and do work before the next check. Windows protections and observed helpers of whitelisted apps stay in effect. This is a resource-management tool. Windows retains its normal process creation and security policies.

Turn off that checkbox before scanning to use Hermes-style guarding of executable paths from the reviewed close list. A preexisting identity omitted from initial approval stays outside the guard when it later becomes readable.

**Launch once** opens a selected executable for this session. Approval follows its exact process identity and observed descendants. The guard can recognize direct children born during a short-lived launcher's lifetime. An application started by an unrelated broker, a single-instance handoff, or a helper chain that exits between checks can escape that tracking. Choose the actual app executable in those cases.

Keep the window open or minimized. **Activity** shows close results, skips and errors. Selecting **End session** releases the guard and restores journaled startup changes. Closed apps stay closed. Closing an active window offers to end the session. The default session limit is six hours.

## Startup changes and recovery

**Pause matching startup entries during raid** controls temporary suppression of reviewed current-user Run and RunOnce values, Startup-folder files, and clearly owned single-action scheduled tasks. The preview identifies the entries selected for a pause. Ambiguous tasks are left enabled. Services are inventory-only. You can turn startup pausing off and keep process guarding enabled.

The app writes a local journal before each startup mutation. It checks the saved value or file hash and task definition during restoration. A conflict preserves the journal and any saved file. **Recover session** retries the unresolved entries. Read **Activity** for the specific item and preserve its saved copy while resolving the conflict.

A crash or forced exit stops the guard. On reopening, recover the interrupted session before starting another. An active or interrupted original Hermes session must be ended with the original utility. Launch the desktop app without elevation to activate or recover.

Local files live in `%LOCALAPPDATA%\RaidModeDesktop`. The profile contains `whitelist.json`, an active `session.json` when needed, saved Startup-folder items under `Saved`, and finished journals and event logs under `Sessions`. Session records can contain local executable paths and startup commands.

## Build and test

For the Personal edition, build with `.\build.ps1 -Personal -Tests`. **Session** shows running and installed apps together with saved rules from `%LOCALAPPDATA%\RaidModePersonal\whitelist.json`. First launch scans automatically. **Rostered**, **Benched** and **Flex** filter the same editable table. The counts include grouped executables and saved folder entries. Select one or more rows to edit their rule, or use the right-click menu. **Manage rules** holds the executable picker, folder rules and confirmed global reset. Click **Details** beside an app to inspect it within the grid, then **Back** to return to the same row. **Apply suggestions** rosters all eligible WoW, Battle.net and Discord paths and refreshes the preview. `--suggestions` opens the Suggested view in Session. **Details** explains matching and holds startup and guard preferences. Personal closes eligible Benched apps by default. Both editions share session locking and startup recovery.

Extract the source ZIP. From that folder, use Windows PowerShell or PowerShell 7.

```powershell
.\build.ps1
& ".\bin\Reverse's Raid Mode.exe" --preview
```

The build uses the x64 .NET Framework compiler already supplied on the test PC. It produces a single unsigned, GUI-subsystem executable in `bin`. Copy that file to distribute the development build. The build uses local framework assemblies and has no package download step.

```powershell
.\build.ps1 -Tests
.\bin\RaidMode.Tests.exe
.\tests\PreviewSmoke.ps1 -Exe ".\bin\Reverse's Raid Mode.exe"
.\tests\PreviewSmoke.ps1 -Exe ".\bin\Reverse's Raid Mode.exe" -FirstLaunch
```

The executable tests use synthetic process inventories, disposable executables, temporary files and isolated HKCU registry fixtures. The smoke test drives the shipping executable in read-only mode. The test results from this build are in `TESTING.md`.
