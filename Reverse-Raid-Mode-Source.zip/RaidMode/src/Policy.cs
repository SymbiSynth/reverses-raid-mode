using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace RaidMode
{
    internal static class Paths
    {
        internal static readonly StringComparer Comparer = StringComparer.OrdinalIgnoreCase;
        internal static bool Equal(string a, string b) { return Comparer.Equals(a, b); }
        internal static readonly string Profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        internal static readonly string Legacy = Path.Combine(Profile, "RaidMode");
        internal static readonly string SharedSessions = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RaidModeDesktop");
        internal static readonly string Data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),Program.ProfileFolderName);
        internal static readonly string Win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        internal static readonly string PF = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        internal static readonly string X86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        internal static readonly string Wave = Path.Combine(PF, @"WindowsApps\Elgato.WaveLink_*\*");
        internal static string Exe(string raw, bool mustExist)
        {
            if (String.IsNullOrWhiteSpace(raw) || !Regex.IsMatch(raw, @"^[a-zA-Z]:\\") || raw.Substring(2).IndexOf(':') >= 0 ||
                raw.IndexOfAny(new char[] {'*','?','"','<','>','|'}) >= 0 || !Equal(Path.GetExtension(raw), ".exe")) throw new InvalidDataException("Choose a local .exe file.");
            string full = Path.GetFullPath(raw);
            if (mustExist && !File.Exists(full)) throw new FileNotFoundException("This executable is missing.", full);
            return full;
        }

        internal static string Rule(string raw)
        {
            if (Equal(raw, Wave)) return Wave;
            if (raw == null || !raw.EndsWith(@"\*")) return Exe(raw, false);
            string folder = raw.Substring(0, raw.Length - 2);
            if (!Regex.IsMatch(folder, @"^[a-zA-Z]:\\[^*?""<>|:]+$") || folder.EndsWith(@"\") || !Equal(folder, Path.GetFullPath(folder))) throw new InvalidDataException("Invalid application folder rule: " + raw);
            string[] roots = { PF, X86, Win, Profile, Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                Path.Combine(PF,"WindowsApps"), Path.Combine(Profile,@"AppData\Local\Programs"), Path.GetDirectoryName(Profile),
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                Path.Combine(Profile,"Downloads"),Path.GetTempPath().TrimEnd('\\') };
            if (roots.Any(r => Equal(r, folder) || r.StartsWith(folder+"\\",StringComparison.OrdinalIgnoreCase)) || folder.Split('\\').Length < 3)
                throw new InvalidDataException("Choose an individual application's installation folder.");
            return raw;
        }
        internal static bool Matches(string rule, string image)
        {
            if (image == null) return false;
            if (Equal(rule, Wave)) {
                string prefix = Wave.Substring(0, Wave.IndexOf('*'));
                if (!image.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)) return false;
                int slash = image.IndexOf('\\',prefix.Length);
                return slash > prefix.Length && slash < image.Length - 1;
            }
            return rule.EndsWith(@"\*") ? image.StartsWith(rule.Substring(0, rule.Length - 1), StringComparison.OrdinalIgnoreCase) : Equal(rule, image);
        }
    }

    internal static class Store
    {
        internal static T Load<T>(string file) { return new JavaScriptSerializer().Deserialize<T>(File.ReadAllText(file)); }
        internal static void Write(string file, object value)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(file));
            string temp = file + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try {
                byte[] bytes = new UTF8Encoding(false).GetBytes(new JavaScriptSerializer().Serialize(value));
                using (var f = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { f.Write(bytes,0,bytes.Length); f.Flush(true); }
                if (File.Exists(file)) File.Replace(temp,file,null);
                else File.Move(temp,file);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }

    internal enum RuleOrigin { Flex, FlexOverride, SavedBench, SavedRoster, Folder, Aside, DefaultBench, DefaultRoster }
    internal struct AppRule
    {
        internal readonly RuleOrigin Origin;
        internal readonly string Anchor;
        internal AppRule(RuleOrigin origin,string anchor) {Origin=origin;Anchor=anchor;}
        internal bool Benched {get {return Origin==RuleOrigin.SavedBench || Origin==RuleOrigin.Aside || Origin==RuleOrigin.DefaultBench;}}
        internal string Roster {get {return Origin==RuleOrigin.SavedRoster || Origin==RuleOrigin.Folder || Origin==RuleOrigin.DefaultRoster?Anchor:null;}}
        internal bool Suggestible {get {return Origin==RuleOrigin.DefaultBench || Origin==RuleOrigin.Flex;}}
    }

    public sealed class Settings
    {
        public int Version = 1;
        public List<string> Allow = new List<string>();
        public List<string> Block = new List<string>();
        public Dictionary<string,string> BenchProducts = new Dictionary<string,string>(Paths.Comparer);
        public Dictionary<string,string> RosterProducts = new Dictionary<string,string>(Paths.Comparer);
        public Dictionary<string,AfterRaidMode> AfterRaid = new Dictionary<string,AfterRaidMode>(Paths.Comparer);
        public Dictionary<string,string> AfterProducts = new Dictionary<string,string>(Paths.Comparer);
        public bool UseRaidDefaults = Program.Raiders;
        public bool BenchAside = false;
        public bool CloseUnlisted = true;
        public List<string> FolderExceptions = new List<string>();
        public bool FullGuard = true, PauseRun = true, PauseFiles = true, PauseTasks = true;
        public int Grace = 8, Interval = 3, Minutes = 360, Limit = 200;
        public string Origin = "Local whitelist";
        internal void Validate()
        {
            if (Version != 1 || Allow == null || Allow.Count > 3000 || Block == null || Block.Count > 3000 || FolderExceptions == null || FolderExceptions.Count > 3000 || Grace < 0 || Grace > 30 || Interval < 1 || Interval > 30 ||
                Minutes < 1 || Minutes > 720 || Limit < 1 || Limit > 300) throw new InvalidDataException("The saved whitelist or session limits are invalid.");
            Block = Block.Select(p=>Paths.Exe(p,false)).Distinct(Paths.Comparer).OrderBy(x=>x, Paths.Comparer).ToList();
            Allow = Allow.Select(Paths.Rule).Where(p=>!Block.Contains(p,Paths.Comparer)).Distinct(Paths.Comparer).OrderBy(x=>x, Paths.Comparer).ToList();
            BenchProducts=ValidProducts(BenchProducts,Block);
            RosterProducts=ValidProducts(RosterProducts,Allow);
            var choices=new Dictionary<string,AfterRaidMode>(Paths.Comparer);
            if(AfterRaid!=null) {
                if(AfterRaid.Count>3000)throw new InvalidDataException("Too many after-raid preferences.");
                foreach(var entry in AfterRaid) {
                    string path=Paths.Exe(entry.Key,false);
                    if(!Enum.IsDefined(typeof(AfterRaidMode),entry.Value))throw new InvalidDataException("Unknown after-raid preference.");
                    if(entry.Value!=AfterRaidMode.StayClosed && AppReopen.Eligible(path))choices[path]=entry.Value;
                }
            }
            AfterRaid=choices;AfterProducts=ValidProducts(AfterProducts,AfterRaid.Keys);
            FolderExceptions = FolderExceptions.Select(p=>Paths.Exe(p,false)).Distinct(Paths.Comparer)
                .Where(p=>!Block.Contains(p,Paths.Comparer) && !Allow.Contains(p,Paths.Comparer)).OrderBy(p=>p,Paths.Comparer).ToList();
        }

        static Dictionary<string,string> ValidProducts(Dictionary<string,string> products,ICollection<string> rules)
        {
            var valid=new Dictionary<string,string>(Paths.Comparer);
            if(products!=null)foreach(var item in products)
                if(!String.IsNullOrWhiteSpace(item.Value) && rules.Contains(item.Key,Paths.Comparer))valid[item.Key]=item.Value;
            return valid;
        }
        internal AppRule Resolve(string image)
        {
            if(String.IsNullOrEmpty(image))return new AppRule();
            if(Block.Contains(image,Paths.Comparer))return new AppRule(RuleOrigin.SavedBench,image);
            if(Allow.Contains(image,Paths.Comparer))return new AppRule(image.EndsWith(@"\*")?RuleOrigin.Folder:RuleOrigin.SavedRoster,image);
            if(FolderExceptions.Contains(image,Paths.Comparer))return new AppRule(RuleOrigin.FlexOverride,image);
            string anchor=ExecutableRulesFor(image,Block,BenchProducts).FirstOrDefault();
            if(anchor!=null)return new AppRule(RuleOrigin.SavedBench,anchor);
            anchor=ExecutableRulesFor(image,Allow,RosterProducts).FirstOrDefault();
            if(anchor!=null)return new AppRule(RuleOrigin.SavedRoster,anchor);
            if(BenchedByAside(image))return new AppRule(RuleOrigin.Aside,image);
            anchor=Allow.FirstOrDefault(r=>r.EndsWith(@"\*") && Paths.Matches(r,image));
            if(anchor!=null)return new AppRule(RuleOrigin.Folder,anchor);
            if(UseRaidDefaults && image.EndsWith(".exe",StringComparison.OrdinalIgnoreCase) &&
                !Policy.SystemImage(Path.GetFileNameWithoutExtension(image),image) && !Paths.Equal(image,System.Windows.Forms.Application.ExecutablePath))
                return new AppRule(RaidSuggestion.DefaultRoster(image)?RuleOrigin.DefaultRoster:RuleOrigin.DefaultBench,image);
            return new AppRule();
        }
        internal string MatchingRule(string image) {return Resolve(image).Roster;}
        bool CoveredByFolder(string image)
        {
            return Allow.Any(r=>r.EndsWith(@"\*") && Paths.Matches(r,image));
        }
        internal Settings Copy()
        {
            var copy=(Settings)MemberwiseClone();
            copy.Allow=new List<string>(Allow);
            copy.Block=new List<string>(Block);
            copy.BenchProducts=new Dictionary<string,string>(BenchProducts,Paths.Comparer);
            copy.RosterProducts=new Dictionary<string,string>(RosterProducts,Paths.Comparer);
            copy.AfterRaid=new Dictionary<string,AfterRaidMode>(AfterRaid,Paths.Comparer);
            copy.AfterProducts=new Dictionary<string,string>(AfterProducts,Paths.Comparer);
            copy.FolderExceptions=new List<string>(FolderExceptions);
            return copy;
        }
        internal void AllowExecutable(string path)
        {
            bool restore=FolderExceptions.Contains(path,Paths.Comparer);
            var prior=Resolve(path);
            path=Paths.Exe(path,!restore && prior.Origin!=RuleOrigin.SavedBench && prior.Origin!=RuleOrigin.Aside);
            RemoveRulesFor(path,Block,BenchProducts);
            FolderExceptions.RemoveAll(r=>Paths.Equal(r,path));
            if ((Program.Raiders || !restore || !CoveredByFolder(path) || BenchedByAside(path)) && !Allow.Contains(path,Paths.Comparer)) {
                Allow.Add(path);CaptureProduct(path,RosterProducts);
            }
        }
        internal void RemoveExecutable(string path)
        {
            RemoveRulesFor(path,Block,BenchProducts);
            RemoveRulesFor(path,Allow,RosterProducts);
            if ((Program.Raiders || UseRaidDefaults || CoveredByFolder(path) || BenchedByAside(path)) && !FolderExceptions.Contains(path,Paths.Comparer))
                FolderExceptions.Add(path);
        }
        internal bool BenchedByAside(string path) {return BenchAside && AsideInstall.Owns(path);}
        internal string AfterRaidAnchor(string path)
        {
            if(path==null || AfterRaid.Count==0)return null;
            return AfterRaid.ContainsKey(path)?path:ExecutableRulesFor(path,AfterRaid.Keys,AfterProducts).FirstOrDefault();
        }
        internal AfterRaidMode AfterMode(string path)
        {
            string anchor=AfterRaidAnchor(path);
            return anchor==null?AfterRaidMode.StayClosed:AfterRaid[anchor];
        }
        internal void SetAfterMode(string path,AfterRaidMode mode)
        {
            path=Paths.Exe(path,false);
            if(!AppReopen.Eligible(path))throw new InvalidDataException("Choose a desktop application.");
            foreach(string anchor in ExecutableRulesFor(path,AfterRaid.Keys,AfterProducts).ToArray()) {
                AfterRaid.Remove(anchor);AfterProducts.Remove(anchor);
            }
            if(mode!=AfterRaidMode.StayClosed){AfterRaid[path]=mode;CaptureProduct(path,AfterProducts);}
        }
        static IEnumerable<string> ExecutableRulesFor(string path,ICollection<string> rules,Dictionary<string,string> products)
        {
            if(rules.Count==0 || String.IsNullOrEmpty(path) || !path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))yield break;
            string suffix=@"\"+Path.GetFileName(path), version=null, product=null;
            bool checkedVersion=false,checkedProduct=false,canFollow=false;
            foreach(string anchor in rules) {
                if(Paths.Equal(path,anchor)){yield return anchor;continue;}
                if(!anchor.EndsWith(suffix,StringComparison.OrdinalIgnoreCase))continue;
                if(!checkedVersion){
                    canFollow=!Policy.SystemImage(Path.GetFileNameWithoutExtension(path),path) && !Paths.Equal(path,System.Windows.Forms.Application.ExecutablePath);
                    if(canFollow)version=ExecutableIdentity.VersionKey(path);
                    checkedVersion=true;
                }
                if(!canFollow)continue;
                bool sameInstall=version!=null && Paths.Equal(version,ExecutableIdentity.VersionKey(anchor));
                string recorded;
                if(!products.TryGetValue(anchor,out recorded)) {
                    if(sameInstall)yield return anchor;
                    continue;
                }
                if(!sameInstall && File.Exists(anchor))continue;
                if(!checkedProduct){product=ExecutableIdentity.ProductKey(path);checkedProduct=true;}
                if(Paths.Equal(recorded,product) || (sameInstall && product==null))yield return anchor;
            }
        }
        static void RemoveRulesFor(string path,List<string> rules,Dictionary<string,string> products)
        {
            foreach(string anchor in ExecutableRulesFor(path,rules,products).ToArray()) {
                rules.RemoveAll(p=>Paths.Equal(p,anchor));
                products.Remove(anchor);
            }
        }
        internal bool IsBlacklisted(string path)
        {
            return Resolve(path).Benched;
        }
        internal void BlockExecutable(string path)
        {
            path=Paths.Exe(path,false);
            if(Policy.SystemImage(Path.GetFileNameWithoutExtension(path),path) || Paths.Equal(path,System.Windows.Forms.Application.ExecutablePath))
                throw new InvalidDataException("This executable is protected.");
            RemoveRulesFor(path,Allow,RosterProducts);
            FolderExceptions.RemoveAll(r=>Paths.Equal(r,path));
            if(!Block.Contains(path,Paths.Comparer))Block.Add(path);
            CaptureProduct(path,BenchProducts);
        }

        static bool CaptureProduct(string path,Dictionary<string,string> products)
        {
            if(products.ContainsKey(path) || path.EndsWith(@"\*"))return false;
            string product=ExecutableIdentity.ProductKey(path);
            if(product==null)return false;
            products.Add(path,product);
            return true;
        }
        internal static Settings Open(string file,bool persistUpgrade=false)
        {
            if (File.Exists(file)) {
                var loaded=Store.Load<Settings>(file);loaded.Validate();
                bool upgraded=false;
                foreach(string path in loaded.Block)upgraded|=CaptureProduct(path,loaded.BenchProducts);
                foreach(string path in loaded.Allow)upgraded|=CaptureProduct(path,loaded.RosterProducts);
                if(upgraded && persistUpgrade)Store.Write(file,loaded);
                return loaded;
            }
            return new Settings {CloseUnlisted=!Program.Personal};
        }
    }

    internal static class Policy
    {
        static readonly HashSet<string> Names = new HashSet<string>(("Idle|System|Registry|Memory Compression|smss|csrss|wininit|services|lsass|winlogon|fontdrvhost|dwm|sihost|taskhostw|svchost|explorer|ShellExperienceHost|StartMenuExperienceHost|SearchHost|SearchApp|RuntimeBroker|ApplicationFrameHost|audiodg|WmiPrvSE|WUDFHost|SecurityHealthService|SecurityHealthSystray|MsMpEng|NisSrv|ctfmon|TextInputHost|LogonUI|conhost|OpenConsole|WindowsTerminal|ShellHost|StartMenuHost|LockApp|CredentialUIBroker|UserOOBEBroker|SecHealthUI|ShellAppRuntime").Split('|'), Paths.Comparer);
        static readonly Regex WindowsServices = new Regex(@"\\(Microsoft Security Client|Microsoft GameInput)\\", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        static readonly Regex ProtectedTools = new Regex(@"\\(Bitdefender|EasyAntiCheat[^\\]*|BattlEye|NVIDIA Corporation\\NvContainer)\\", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        internal static bool WindowsImage(string name, string image)
        {
            return Names.Contains(name) || (image != null && (Paths.Matches(Paths.Win + @"\*", image) ||
                Paths.Matches(Path.Combine(Paths.PF,@"Windows Defender\*"),image) || WindowsServices.IsMatch(image)));
        }
        internal static bool SystemImage(string name, string image)
        {
            return WindowsImage(name,image) || (image!=null && ProtectedTools.IsMatch(image));
        }

        internal static List<ProcessRow> Classify(List<ProcessRow> rows, Settings settings, List<ProcessRow> permits)
        {
            var byId = rows.ToDictionary(p=>p.Id);
            var ancestors = new HashSet<int>(); ProcessRow current;
            if (byId.TryGetValue(Native.Self, out current)) {
                while (ancestors.Add(current.Id)) {
                    ProcessRow parent;
                    if (!byId.TryGetValue(current.Parent,out parent) || (parent.Birth > 0 && current.Birth > 0 && parent.Birth > current.Birth)) break;
                    current = parent;
                }
            }
            var rules=new Dictionary<string,AppRule>(Paths.Comparer);
            foreach (var p in rows) {
                p.AllowTree = false; p.Close = false;
                var rule=new AppRule();
                if(p.Image!=null && !rules.TryGetValue(p.Image,out rule)) {
                    rule=settings.Resolve(p.Image);rules.Add(p.Image,rule);
                }
                p.Blacklisted = rule.Benched;
                p.DefaultBench = rule.Origin==RuleOrigin.DefaultBench;
                p.WhitelistRule = rule.Roster;
                p.CanEditWhitelist = false;
                p.IsWindowsComponent = p.Critical || WindowsImage(p.Name,p.Image);
                if (ancestors.Contains(p.Id)) p.Reason = Program.DisplayName+" or its launch ancestor";
                else if (!p.Verified) p.Reason = "Identity unavailable";
                else if (p.Session != Native.Session || p.Sid != Native.User) p.Reason = "Other account or session";
                else if (p.IsWindowsComponent || ProtectedTools.IsMatch(p.Image)) p.Reason = "Windows or protected component";
                else {
                    p.CanEditWhitelist = Paths.Equal(Path.GetExtension(p.Image),".exe") && p.Image.Length>=3 && p.Image[1]==':' && p.Image[2]=='\\';
                    if (p.DefaultBench && permits.Any(a=>a.Same(p))) { p.Reason="Previously allowed helper for this session"; p.AllowTree=true; }
                    else if (p.Blacklisted) { p.Reason = p.DefaultBench?"Benched by default":rule.Origin==RuleOrigin.Aside?"Benched by your Aside rule":"On your blacklist"; p.Close = true; }
                    else if (p.WhitelistRule!=null) { p.Reason = rule.Origin==RuleOrigin.DefaultRoster?"Rostered by default":"On your whitelist"; p.AllowTree = true; }
                    else if (permits.Any(a=>a.Same(p))) { p.Reason = "Allowed for this session"; p.AllowTree = true; }
                    else { p.Reason = settings.CloseUnlisted?"Outside your whitelist":"No close rule"; p.Close = settings.CloseUnlisted; }
                }
                // Explicit paths can also seed helper protection for mandatory-kept processes.
                if (!p.Blacklisted && p.Verified && p.Sid == Native.User && p.Session == Native.Session && !ancestors.Contains(p.Id) &&
                    (p.WhitelistRule!=null || permits.Any(a=>a.Same(p)))) p.AllowTree = true;
            }
            var children = rows.ToLookup(p=>p.Parent);
            var queue = new Queue<ProcessRow>(rows.Where(p=>p.AllowTree));
            while (queue.Count != 0) {
                var parent = queue.Dequeue();
                foreach (var child in children[parent.Id]) {
                    if (child.AllowTree || !child.Verified || child.Birth < parent.Birth || child.Session != parent.Session || child.Sid != parent.Sid) continue;
                    if (child.Blacklisted && (!child.DefaultBench || !AppFamily.SameInstallation(parent.Image,child.Image)))continue;
                    child.AllowTree = true; child.Close = false; child.Reason = "Helper of " + parent.Name; queue.Enqueue(child);
                }
            }
            return rows;
        }
    }
}
