using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace RaidMode
{
    internal sealed class Plan
    {
        internal readonly Guid Id = Guid.NewGuid();
        internal DateTime Created;
        internal List<ProcessRow> Rows;
        internal List<SourceItem> Sources;
        internal readonly List<string> Notes=new List<string>();
        internal readonly HashSet<string> DesktopLaunchers=new HashSet<string>(Paths.Comparer);
        internal bool Full;
        internal string PolicyStamp;
        internal IEnumerable<ProcessRow> Targets { get {return Rows.Where(p=>p.Close);} }
    }
    public sealed class Journal
    {
        public int Version=1;
        public string Run, State;
        public SessionReturn AfterSession;
        public List<SourceItem> Sources=new List<SourceItem>();
        public List<ReopenItem> Reopen=new List<ReopenItem>();
    }
    internal sealed class Session : IDisposable
    {
        readonly string root, legacyDir, mutexName;
        readonly Sources sources;
        readonly Func<List<ProcessRow>> snapshot;
        readonly Action<IEnumerable<ProcessRow>,int,CancellationToken,Action<string>> closer;
        readonly Func<bool> elevated;
        readonly Action<string> log;
        readonly Action<string,string> reopen;
        readonly Dictionary<string,string> restartArguments=new Dictionary<string,string>(Paths.Comparer);
        readonly Dictionary<int,ProcessRow> gentleRoots=new Dictionary<int,ProcessRow>();
        Dictionary<int,ProcessRow> gentleInstances=new Dictionary<int,ProcessRow>();
        readonly Dictionary<WinHandle,ProcessRow> awaitingClose=new Dictionary<WinHandle,ProcessRow>();
        internal readonly Settings Settings;
        internal Plan Reviewed;
        internal DateTime Started;
        readonly Stopwatch duration=new Stopwatch();
        readonly List<ProcessRow> permits=new List<ProcessRow>();
        readonly Dictionary<int,LaunchRecord> recentLaunches=new Dictionary<int,LaunchRecord>();
        readonly Queue<DateTime> recentActions=new Queue<DateTime>();
        Dictionary<int,ProcessRow> approvedInstances;
        long guardSince;
        HashSet<string> initial;
        Mutex compatibility;
        FileStream exclusive;
        Journal journal;
        internal bool Active {get;private set;}
        internal int Notices {get;private set;}
        internal TimeSpan Elapsed {get {return duration.Elapsed;}}
        internal bool Expired {get {return Active && (Elapsed.TotalMinutes>=Settings.Minutes || DateTime.UtcNow>=Started.AddMinutes(Settings.Minutes));}}
        internal bool NeedsRecovery {get {return root!=null && File.Exists(JournalFile);}}
        string JournalFile {get {return Path.Combine(root,"session.json");}}
        string BackupDir {get {return Path.Combine(root,"Saved",journal.Run);}}
        string LogFile {get {return Path.Combine(root,"Sessions",journal.Run+".log");}}
        sealed class LaunchRecord : IDisposable
        {
            public Process Process;
            public long Birth;
            public string Image;
            public void Dispose() { Process.Dispose(); }
        }
        internal Session(Settings settings,string directory,Action<string> output)
            : this(settings,directory,Paths.Legacy,@"Local\CarlosRaidModeMutex",Sources.Local(),Native.Snapshot,Native.CloseSelected,()=>Native.Elevated,output) {}
        internal Session(Settings settings,string directory,string legacy,string mutex,Sources store,Func<List<ProcessRow>> scan,
            Action<IEnumerable<ProcessRow>,int,CancellationToken,Action<string>> close,Func<bool> admin,Action<string> output,Action<string,string> reopenApp=null)
        {
            Settings=settings; root=directory; legacyDir=legacy; mutexName=mutex; sources=store; snapshot=scan; closer=close; elevated=admin; log=output;
            reopen=reopenApp??AppReopen.Launch;
        }
        string Stamp()
        {
            var json=new System.Web.Script.Serialization.JavaScriptSerializer();
            // Framework reflection can enumerate the very same fields in a different order after GC.
            return json.Serialize(OrderedFields(json.DeserializeObject(json.Serialize(Settings))));
        }
        static object OrderedFields(object value)
        {
            var fields=value as IDictionary<string,object>;
            if(fields!=null) {
                var ordered=new SortedDictionary<string,object>(StringComparer.Ordinal);
                foreach(var pair in fields)ordered.Add(pair.Key,OrderedFields(pair.Value));
                return ordered;
            }
            var array=value as object[];
            return array==null?value:array.Select(OrderedFields).ToArray();
        }
        internal Plan Scan()
        {
            if(Active || NeedsRecovery) throw new InvalidOperationException("End or recover the session first.");
            Reviewed=null;
            Settings.Validate();
            var plan=new Plan {Full=Settings.FullGuard, PolicyStamp=Stamp()};
            plan.Rows=Policy.Classify(snapshot().Select(p=>p.Copy()).ToList(),Settings,new List<ProcessRow>());
            plan.Sources=sources.Inspect(Settings,new HashSet<string>(plan.Targets.Select(p=>p.Image),Paths.Comparer),plan.Notes);
            plan.Created=DateTime.UtcNow;
            Reviewed=plan;
            return plan;
        }
        void Lock()
        {
            if (exclusive!=null) return;
            Directory.CreateDirectory(root);
            exclusive=new FileStream(Path.Combine(root,"session.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
            try {
                bool created;
                compatibility=new Mutex(false,mutexName,out created);
                if (!created || File.Exists(Path.Combine(legacyDir,@"State\active-session.json")))
                    throw new InvalidOperationException("End or recover the original Hermes session first.");
            } catch {Unlock(); throw;}
        }
        void Unlock()
        {
            if(compatibility!=null){compatibility.Dispose();compatibility=null;}
            if(exclusive!=null){exclusive.Dispose();exclusive=null;}
        }
        void Save() {Store.Write(JournalFile,journal);}
        void Report(string message)
        {
            if(message.StartsWith("Skipped")||message.StartsWith("Could not")||message.StartsWith("Close requested, exit unverified")) Notices++;
            if (journal!=null) {
                Directory.CreateDirectory(Path.GetDirectoryName(LogFile));
                File.AppendAllText(LogFile,DateTime.Now.ToString("HH:mm:ss")+"  "+message+Environment.NewLine);
            }
            log(message);
        }

        internal static string ReturnSummary(SessionReturn choice)
        {
            switch(choice) {
                case SessionReturn.Resume:return "After this raid, reopen apps and request their saved sessions.";
                case SessionReturn.LeaveClosed:return "After this raid, leave apps closed.";
                case SessionReturn.PerApp:return "After this raid, follow your per-app choices.";
                default:throw new ArgumentOutOfRangeException("choice");
            }
        }
        internal void Start(Plan plan, Guid confirmedId,CancellationToken stop,SessionReturn afterSession)
        {
            if (root==null) throw new InvalidOperationException("Raid sessions are disabled in first-launch preview.");
            if (Active || NeedsRecovery) throw new InvalidOperationException("A session is active or requires recovery.");
            if (elevated()) throw new InvalidOperationException("Open "+Program.DisplayName+" as a standard user before starting a session.");
            if (plan==null || plan!=Reviewed || plan.Id!=confirmedId || plan.PolicyStamp!=Stamp() || DateTime.UtcNow-plan.Created>TimeSpan.FromMinutes(5))
                throw new InvalidOperationException("The reviewed plan expired or changed. Refresh the preview.");
            Lock();
            try {
                if (NeedsRecovery) throw new InvalidOperationException("A prior session needs recovery.");
                guardSince=DateTime.UtcNow.ToFileTimeUtc();
                var current=Policy.Classify(snapshot().Select(p=>p.Copy()).ToList(),Settings,permits);
                var selected=plan.Targets.ToDictionary(p=>p.Id);
                var live=new List<ProcessRow>();
                foreach(var p in current.Where(p=>p.Close)) {
                    ProcessRow approved;
                    if(!selected.TryGetValue(p.Id,out approved) || !approved.Same(p)) throw new InvalidOperationException("Running apps changed. Scan again to review the new plan.");
                    live.Add(p);
                }
                if(live.Count>Settings.Limit || selected.Count>Settings.Limit) throw new InvalidOperationException("Safety limit exceeded. Add apps to your whitelist and scan again.");
                stop.ThrowIfCancellationRequested();
                permits.Clear(); permits.AddRange(current.Where(p=>p.AllowTree));
                initial=new HashSet<string>(selected.Values.Select(p=>p.Image),Paths.Comparer);
                approvedInstances=selected;
                Notices=0;
                string returnSummary=ReturnSummary(afterSession);
                journal=new Journal {Version=2,Run=Guid.NewGuid().ToString("N"),State="Starting",Sources=plan.Sources,AfterSession=afterSession};
                int n=0;
                foreach(var item in journal.Sources) {
                    if(item.Kind=="Startup file") item.Backup=Path.Combine(BackupDir,(++n).ToString("D4")+"-"+Path.GetFileName(item.Location));
                    sources.Validate(item,BackupDir);
                }
                Save();
                Report("Starting approved plan "+plan.Id.ToString("N").Substring(0,8)+". "+Settings.Minutes+" minute limit.");
                if(Program.Raiders)Report(returnSummary);
                foreach(var item in journal.Sources) {
                    stop.ThrowIfCancellationRequested();
                    item.Stage="Intent"; Save();
                    try {
                        item.Stage=sources.Pause(item) ? "Paused" : "Skipped";
                        if(item.Stage=="Skipped") Report("Skipped changed startup source: "+item.Label);
                    } catch(Exception ex) {
                        item.Issue=ex.Message;
                        Report("Could not confirm startup pause: "+item.Label+" - "+ex.Message);
                    }
                    Save();
                }
                if(afterSession!=SessionReturn.LeaveClosed || Program.Raiders)PrepareDesktopClose(plan,current,live);
                closer(live,Settings.Grace*1000,stop,Report);
                stop.ThrowIfCancellationRequested();
                journal.State="Active"; Save(); Active=true; Started=DateTime.UtcNow; duration.Restart(); Reviewed=null;
                Report("Guard active. "+live.Count+" reviewed process identities handled.");
            } catch {
                Active=false;
                if(journal!=null && NeedsRecovery) {try {End();} finally {Unlock();}}
                else {journal=null;permits.Clear();Unlock();}
                throw;
            }
        }
        void PrepareDesktopClose(Plan plan,List<ProcessRow> rows,List<ProcessRow> targets)
        {
            var byId=rows.ToDictionary(p=>p.Id);
            foreach(var p in targets) {
                if(!AppReopen.Eligible(p.Image))continue;
                if(p.Window!=IntPtr.Zero)gentleRoots.Add(p.Id,p);
                if(journal.AfterSession==SessionReturn.LeaveClosed)continue;
                var mode=journal.AfterSession==SessionReturn.PerApp?Settings.AfterMode(p.Image):AfterRaidMode.Resume;
                if(mode==AfterRaidMode.StayClosed)continue;
                if(p.Window==IntPtr.Zero) {
                    ProcessRow parent;
                    if(byId.TryGetValue(p.Parent,out parent) && parent.Birth<=p.Birth && Paths.Equal(p.Image,parent.Image))continue;
                    var family=AppFamily.Known(p.Image);
                    if(family!=null && family.ShowOwnerWhenAlone)continue;
                }
                var args=AppReopen.RegisteredResume(p);
                if(p.Window==IntPtr.Zero && args==null && !plan.DesktopLaunchers.Contains(p.Image) && journal.AfterSession!=SessionReturn.PerApp)continue;
                if(mode==AfterRaidMode.Resume && !String.IsNullOrEmpty(args))restartArguments[p.Image]=args;
                p.ConfirmClosed=closed=>{
                    if(!journal.Reopen.Any(item=>Paths.Equal(item.Image,closed.Image))) {
                        journal.Reopen.Add(new ReopenItem{Image=closed.Image,Mode=mode});Save();
                    }
                };
                p.WaitForClose=(row,handle)=>awaitingClose.Add(handle,row);
            }
            TrackGentleHelpers(rows);
            foreach(var p in targets)p.GentleClose=gentleInstances.ContainsKey(p.Id);
        }
        void TrackGentleHelpers(List<ProcessRow> rows)
        {
            if(gentleRoots.Count==0)return;
            var kept=new Dictionary<int,ProcessRow>();
            foreach(var p in rows) {
                ProcessRow previous;
                if(gentleRoots.TryGetValue(p.Id,out previous) && previous.Same(p))kept[p.Id]=p;
            }
            foreach(int id in gentleRoots.Keys.Where(id=>!kept.ContainsKey(id)).ToArray())gentleRoots.Remove(id);
            if(kept.Count==0){gentleInstances.Clear();return;}
            var children=rows.ToLookup(p=>p.Parent);
            var queue=new Queue<ProcessRow>(kept.Values);
            while(queue.Count!=0) {
                var parent=queue.Dequeue();
                foreach(var child in children[parent.Id]) {
                    if(kept.ContainsKey(child.Id) || !child.Verified || child.Sid!=parent.Sid || child.Session!=parent.Session ||
                        child.Birth<parent.Birth || child.Window!=IntPtr.Zero)continue;
                    kept[child.Id]=child;queue.Enqueue(child);
                }
            }
            gentleInstances=kept;
        }
        internal void Guard(CancellationToken stop)
        {
            if (!Active) throw new InvalidOperationException("Guard is inactive.");
            if (Expired) throw new InvalidOperationException("Session time limit reached.");
            RecordLateCloses(false);
            var rows=snapshot();
            BindLaunchChildren(rows);
            var plan=Policy.Classify(rows,Settings,permits);
            // Carry the observed helper identity across a launcher exit. Never authorize PID alone.
            permits.Clear(); permits.AddRange(plan.Where(p=>p.AllowTree));
            TrackGentleHelpers(rows);
            var targets=plan.Where(p=>p.Close && !gentleInstances.ContainsKey(p.Id) && (p.Blacklisted || Settings.FullGuard || initial.Contains(p.Image)) && EligibleInstance(p)).ToList();
            DateTime now=DateTime.UtcNow;
            while(recentActions.Count>0 && now-recentActions.Peek()>TimeSpan.FromMinutes(1)) recentActions.Dequeue();
            if(targets.Count>Settings.Limit || recentActions.Count+targets.Count>Settings.Limit)
                throw new InvalidOperationException("Repeated launches reached the safety limit. Guard stopped.");
            foreach(var p in targets) recentActions.Enqueue(now);
            closer(targets,0,stop,Report);
        }
        bool EligibleInstance(ProcessRow p)
        {
            ProcessRow reviewed;
            return p.Birth>=guardSince || (approvedInstances.TryGetValue(p.Id,out reviewed) && reviewed.Same(p));
        }
        internal void Launch(string path)
        {
            if (!Active || Expired) throw new InvalidOperationException("Start an active session before using Launch once.");
            path=Paths.Exe(path,true);
            if(Settings.IsBlacklisted(path)) throw new InvalidOperationException("Remove this app from the blacklist before launching it during a raid.");
            var p=Process.Start(new ProcessStartInfo(path){UseShellExecute=false,WorkingDirectory=Path.GetDirectoryName(path)});
            try {
                long birth=p.StartTime.ToUniversalTime().ToFileTimeUtc();
                var seed=new ProcessRow {Id=p.Id,Image=path,Name=Path.GetFileNameWithoutExtension(path),Birth=birth,Session=Native.Session,Sid=Native.User};
                permits.Add(seed);
                var record=new LaunchRecord {Process=p,Birth=birth,Image=path};
                LaunchRecord old;
                if(recentLaunches.TryGetValue(p.Id,out old)) old.Dispose();
                recentLaunches[p.Id]=record;
                Report("Allowed this launch: "+path);
            } catch {p.Dispose();throw;}
        }
        void BindLaunchChildren(List<ProcessRow> rows)
        {
            foreach(var pair in recentLaunches.ToList()) {
                var r=pair.Value;
                if(!r.Process.HasExited) continue;
                long exit=r.Process.ExitTime.ToUniversalTime().ToFileTimeUtc();
                // The pinned launch handle and lifetime also identify direct children of a short-lived launcher.
                foreach(var child in rows.Where(p=>p.Parent==pair.Key && p.Verified && p.Sid==Native.User && p.Session==Native.Session && p.Birth>=r.Birth && p.Birth<=exit))
                    permits.Add(child);
                if(DateTime.UtcNow.ToFileTimeUtc()-exit>TimeSpan.FromSeconds(15).Ticks) {
                    r.Dispose();recentLaunches.Remove(pair.Key);
                }
            }
        }
        void RecordLateCloses(bool ending)
        {
            foreach(var entry in awaitingClose.ToArray()) {
                bool exited=Native.HasExited(entry.Key);
                if(exited)entry.Value.ConfirmClosed(entry.Value);
                if(ending || exited){entry.Key.Dispose();awaitingClose.Remove(entry.Key);}
            }
        }
        void ReopenConfirmed(bool allowLaunch)
        {
            if(!allowLaunch || (journal.Version==2 && journal.AfterSession==SessionReturn.LeaveClosed) || journal.Reopen.Count==0)return;
            foreach(var item in journal.Reopen.Where(r=>!r.Attempted)) {
                item.Attempted=true;Save(); // A recovery retry must never launch the same app twice.
                try {
                    string path=Paths.Exe(item.Image,false);
                    if(!AppReopen.Eligible(path) || (item.Mode!=AfterRaidMode.Resume && item.Mode!=AfterRaidMode.Fresh))continue;
                    if(journal.Version==1 && item.Mode!=Settings.AfterMode(path))continue;
                    if(journal.Version==2 && journal.AfterSession==SessionReturn.Resume && item.Mode!=AfterRaidMode.Resume)continue;
                    if(!File.Exists(path)){Report("Skipped reopening "+Path.GetFileName(path)+" because the executable has moved or is missing.");continue;}
                    if(snapshot().Any(p=>p.Session==Native.Session && Paths.Equal(p.Image,path))) {
                        Report("Already running: "+Path.GetFileName(path));continue;
                    }
                    string registration;restartArguments.TryGetValue(path,out registration);
                    string arguments=AppReopen.Arguments(path,item.Mode,registration);
                    reopen(path,arguments);
                    string behavior=arguments.Length==0?"using its own startup settings":AppReopen.Label(item.Mode);
                    Report("Reopened "+Path.GetFileName(path)+" ("+behavior+").");
                } catch(Exception ex) {Report("Could not reopen app: "+ex.Message);}
            }
        }
        internal void End() {End(true);}
        internal void End(bool reopenApps)
        {
            Active=false; duration.Stop(); Reviewed=null;
            foreach(var record in recentLaunches.Values) record.Dispose();
            recentLaunches.Clear(); permits.Clear(); recentActions.Clear();gentleInstances.Clear();gentleRoots.Clear();
            if(!NeedsRecovery) {bool lost=journal!=null;journal=null;Unlock();if(lost)throw new IOException("The session journal is missing. Check saved startup items.");return;}
            Lock();
            try {
                if (elevated()) throw new InvalidOperationException("Reopen normally to recover this session.");
                journal=Store.Load<Journal>(JournalFile);
                Guid id;
                if(journal==null || (journal.Version!=1 && journal.Version!=2) || !Guid.TryParseExact(journal.Run,"N",out id) || journal.Sources==null ||
                    journal.Reopen==null || journal.Reopen.Count>300 || journal.Reopen.Any(r=>r==null) || !Enum.IsDefined(typeof(SessionReturn),journal.AfterSession))
                    throw new InvalidDataException("Unrecognized session journal. Saved items have been retained.");
                var issues=new List<string>();
                foreach(var item in journal.Sources) sources.Validate(item,BackupDir);
                RecordLateCloses(true);
                if(!reopenApps) {
                    journal.AfterSession=SessionReturn.LeaveClosed;
                    foreach(var item in journal.Reopen)item.Attempted=true;
                }
                journal.State="Ending"; Save();
                foreach(var item in journal.Sources.AsEnumerable().Reverse()) {
                    if(item.Stage=="Restored" || item.Stage=="Planned" || item.Stage=="Skipped") continue;
                    try {sources.Restore(item);item.Stage="Restored";item.Issue=null;}
                    catch(Exception ex) {item.Issue=ex.Message;issues.Add(item.Label+" - "+ex.Message);}
                    Save();
                }
                if(issues.Count>0) {journal.State="Recovery"; Save(); throw new IOException("Recovery needs attention. "+String.Join(Environment.NewLine,issues));}
                ReopenConfirmed(reopenApps);restartArguments.Clear();
                journal.State="Ended"; Save();
                Report("Session ended. Startup changes restored.");
                File.Move(JournalFile,Path.Combine(Path.GetDirectoryName(LogFile),journal.Run+".json"));
                if(Directory.Exists(BackupDir) && Directory.GetFileSystemEntries(BackupDir).Length==0) Directory.Delete(BackupDir);
            } finally {journal=null;Unlock();}
        }
        public void Dispose() {
            foreach(var r in recentLaunches.Values)r.Dispose();
            foreach(var handle in awaitingClose.Keys)handle.Dispose();
            awaitingClose.Clear();Unlock();
        }
    }
}
