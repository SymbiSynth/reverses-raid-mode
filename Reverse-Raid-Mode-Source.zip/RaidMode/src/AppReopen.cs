using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace RaidMode
{
    public enum AfterRaidMode { StayClosed, Fresh, Resume }
    public enum SessionReturn { LeaveClosed, Resume, PerApp }

    // No document names, URLs or restart arguments are written to the session journal.
    public sealed class ReopenItem
    {
        public string Image;
        public AfterRaidMode Mode;
        public bool Attempted;
    }

    internal static class AppReopen
    {
        static readonly HashSet<string> Chromium=new HashSet<string>(new[]{"chrome.exe","msedge.exe","brave.exe","vivaldi.exe","chromium.exe"},Paths.Comparer);
        internal static string Label(AfterRaidMode mode)
        {
            if(mode==AfterRaidMode.Fresh)return "Start fresh";
            return mode==AfterRaidMode.Resume?"Resume if supported":"Stay closed";
        }
        internal static bool Eligible(string path)
        {
            return !String.IsNullOrEmpty(path) && path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase) &&
                !Policy.SystemImage(Path.GetFileNameWithoutExtension(path),path) && !Paths.Equal(path,System.Windows.Forms.Application.ExecutablePath);
        }
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]
        static extern int GetApplicationRestartSettings(WinHandle process,StringBuilder arguments,ref uint size,out uint flags);

        internal static string RegisteredResume(ProcessRow p)
        {
            using(var h=Native.OpenProcess(Native.Query|0x0010,false,p.Id)) {
                if(h.IsInvalid || !p.Same(Native.Read(h,p.Id)))return null;
                uint size=1025,flags;
                var buffer=new StringBuilder((int)size);
                if(GetApplicationRestartSettings(h,buffer,ref size,out flags)==0)return buffer.ToString();
            }
            return null;
        }
        internal static string Arguments(string path,AfterRaidMode mode,string registration)
        {
            string exe=Path.GetFileName(path);
            if(mode==AfterRaidMode.Resume) {
                if(!String.IsNullOrEmpty(registration))return registration;
                if(Chromium.Contains(exe))return "--restore-last-session";
            } else if(mode==AfterRaidMode.Fresh) {
                if(Chromium.Contains(exe))return "--new-window about:blank";
                if(Paths.Equal(exe,"firefox.exe"))return "-new-window about:blank";
                if(Paths.Equal(exe,"Code.exe") || Paths.Equal(exe,"Code - Insiders.exe"))return "--new-window";
            }
            return "";
        }
        internal static void Launch(string path,string arguments)
        {
            using(Process.Start(new ProcessStartInfo(Paths.Exe(path,true),arguments){UseShellExecute=false,WorkingDirectory=Path.GetDirectoryName(path)})) {}
        }
    }
}
