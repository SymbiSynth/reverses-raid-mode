using System;
using System.IO;
using System.Linq;

namespace RaidMode
{
    internal sealed class RaidSuggestion
    {
        internal readonly string Name;
        readonly string[] files;
        string requiredFolder=null;

        RaidSuggestion(string name, params string[] files)
        {
            Name=name;
            this.files=files;
        }

        static readonly RaidSuggestion wow=new RaidSuggestion("World of Warcraft","Wow.exe","WowClassic.exe","WowT.exe","WowB.exe","World of Warcraft Launcher.exe");
        static readonly RaidSuggestion discord=new RaidSuggestion("Discord","Discord.exe","DiscordPTB.exe","DiscordCanary.exe");
        static readonly RaidSuggestion browser=new RaidSuggestion("Your browser");
        internal static readonly RaidSuggestion[] Products = {
            wow,
            new RaidSuggestion("Battle.net","Battle.net.exe","Battle.net Launcher.exe"),
            new RaidSuggestion("Battle.net Update Agent","Agent.exe","AgentHelper.exe"){requiredFolder=@"\Battle.net\Agent\"},
            discord, new RaidSuggestion("Archon","Archon.exe","Archon App.exe"), browser
        };

        internal static bool DefaultRoster(string path)
        {
            string file=Path.GetFileName(path);
            if(discord.files.Contains(file,Paths.Comparer) || wow.files.Contains(file,Paths.Comparer))return true;
            if(!Paths.Equal(file,"Update.exe"))return false;
            string folder=Path.GetDirectoryName(path);
            return folder!=null && discord.files.Contains(Path.GetFileName(folder)+".exe",Paths.Comparer);
        }
        internal bool Matches(AppEntry app)
        {
            if(this==browser)return app.BrowserInUse;
            if(this==discord)return DefaultRoster(app.Image) && !wow.files.Contains(Path.GetFileName(app.Image),Paths.Comparer);
            return files.Contains(Path.GetFileName(app.Image),Paths.Comparer) &&
                (requiredFolder==null || app.Image.IndexOf(requiredFolder,StringComparison.OrdinalIgnoreCase)>=0);
        }
    }
}
