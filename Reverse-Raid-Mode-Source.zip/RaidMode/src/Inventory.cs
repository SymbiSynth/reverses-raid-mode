using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace RaidMode
{
    // Use the existing Windows automation interfaces without loading a dynamic-language compiler.
    internal static class Com
    {
        internal static object Get(object obj,string name,params object[] args)
        {
            return obj.GetType().InvokeMember(name,BindingFlags.GetProperty,null,obj,args);
        }
        internal static object Call(object obj,string name,params object[] args)
        {
            return obj.GetType().InvokeMember(name,BindingFlags.InvokeMethod,null,obj,args);
        }
        internal static void Set(object obj,string name,object value)
        {
            obj.GetType().InvokeMember(name,BindingFlags.SetProperty,null,obj,new[]{value});
        }
    }
    internal sealed class AppEntry
    {
        public string Name, Image, Source;
        internal bool BrowserInUse, DesktopLauncher;
        internal AppFamily Family;
    }
    internal static class Software
    {
        internal static void Release(object com)
        {
            if (com != null && Marshal.IsComObject(com)) Marshal.ReleaseComObject(com);
        }
        internal static string Shortcut(object shell, string path)
        {
            object link = Com.Call(shell,"CreateShortcut",path);
            try { return (string)Com.Get(link,"TargetPath"); } finally { Release(link); }
        }

        static void AddShortcut(object shell,string path,Action<string,string,string> add)
        {
            object link=Com.Call(shell,"CreateShortcut",path);
            try {
                // A shortcut that requires arguments may point at a host or updater.
                string source=String.IsNullOrWhiteSpace((string)Com.Get(link,"Arguments"))?"Start menu":"Start menu shortcut";
                add((string)Com.Get(link,"TargetPath"),Path.GetFileNameWithoutExtension(path),source);
            } finally {Release(link);}
        }

        internal static List<AppEntry> Find(IEnumerable<ProcessRow> running, List<string> warnings)
        {
            var apps = new Dictionary<string,AppEntry>(Paths.Comparer);
            Action<string,string,string> add = (image,name,source) => {
                try {
                    image = Paths.Exe(Environment.ExpandEnvironmentVariables((image ?? "").Trim().Trim('"')), true);
                    if (Policy.SystemImage(Path.GetFileNameWithoutExtension(image),image)) return;
                    AppEntry app;
                    if(!apps.TryGetValue(image,out app)) {
                        app=new AppEntry{Name=name??Path.GetFileNameWithoutExtension(image),Image=image,Source=source};
                        apps.Add(image,app);
                    }
                    if(source=="Registered app" || source=="Start menu" || source=="Default browser")app.DesktopLauncher=true;
                } catch (ArgumentException) {} catch (InvalidDataException) {} catch (IOException) {}
            };
            foreach (var p in running.Where(p=>p.Verified && p.Sid == Native.User && !p.Critical && p.Id != Native.Self))
                add(p.Image,null,"Running");
            string defaultBrowser=BrowserInventory.DefaultBrowser();
            if(defaultBrowser!=null)add(defaultBrowser,null,"Default browser");
            var browsers=new HashSet<string>(Paths.Comparer);
            foreach (var hive in new [] {RegistryHive.CurrentUser,RegistryHive.LocalMachine})
            foreach (var view in new [] {RegistryView.Registry64,RegistryView.Registry32}) {
                try {
                    using (var root = RegistryKey.OpenBaseKey(hive,view))
                    using (var paths = root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\App Paths"))
                    using (var installed = root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall")) {
                        BrowserInventory.ReadClients(root,browsers);
                        if (paths != null) foreach (string key in paths.GetSubKeyNames()) using (var k=paths.OpenSubKey(key))
                            if (k!=null) add(k.GetValue("") as string,null,"Registered app");
                        if (installed != null) foreach (string key in installed.GetSubKeyNames()) using (var k=installed.OpenSubKey(key)) {
                            if (k==null) continue;
                            string icon=k.GetValue("DisplayIcon") as string; string name=k.GetValue("DisplayName") as string;
                            if (name==null || icon==null) continue;
                            string image=Regex.Replace(icon, @",\s*-?\d+\s*$","").Trim('"');
                            if (!Regex.IsMatch(Path.GetFileName(image),@"^(unins|uninstall|setup|msiexec)",RegexOptions.IgnoreCase))
                                add(image,name,"Installed app");
                        }
                    }
                } catch (Exception ex) { warnings.Add("Software inventory: " + ex.Message); }
            }
            object shell = null;
            try {
                shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell",true));
                var folders = new Stack<string>(new [] {Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms)}.Where(Directory.Exists));
                while (folders.Count > 0) {
                    string dir = folders.Pop();
                    try {
                        foreach (var sub in Directory.GetDirectories(dir))
                            if ((File.GetAttributes(sub) & FileAttributes.ReparsePoint) == 0) folders.Push(sub);
                        foreach (var link in Directory.GetFiles(dir,"*.lnk")) {
                            try { AddShortcut(shell,link,add); } catch (COMException) {} catch(TargetInvocationException) {}
                        }
                    } catch (UnauthorizedAccessException) { warnings.Add("Could not read Start menu folder " + dir); }
                    catch (IOException ex) { warnings.Add(ex.Message); }
                }
            } catch (Exception ex) { warnings.Add("Start menu inventory: " + ex.Message); }
            finally { Release(shell); }
            // The Start menu often points to the launcher while the raid client lives in a subfolder.
            var gameFolders = apps.Keys.Where(p=>Paths.Equal(Path.GetFileName(p),"World of Warcraft Launcher.exe"))
                .Select(Path.GetDirectoryName).Concat(new[]{Path.Combine(Paths.X86,"World of Warcraft"),
                    Path.Combine(Paths.PF,"World of Warcraft")}).Distinct(Paths.Comparer).Where(Directory.Exists).ToArray();
            foreach (string game in gameFolders)
                foreach (string client in new[]{@"_retail_\Wow.exe", @"_classic_\WowClassic.exe", @"_classic_era_\WowClassic.exe",
                    @"_classic_anniversary_\WowClassic.exe", @"_ptr_\WowT.exe", @"_beta_\WowB.exe"})
                    add(Path.Combine(game,client),null,"Game install");
            foreach(var app in apps.Values) {
                app.BrowserInUse=BrowserInventory.InUse(app.Image,app.Source=="Running",defaultBrowser,browsers);
                if(Program.Personal)app.Family=AppFamily.Detect(app.Image);
            }
            return apps.Values.OrderBy(a=>a.Name,Paths.Comparer).ThenBy(a=>a.Image,Paths.Comparer).ToList();
        }
    }
    public sealed class SourceItem
    {
        public string Kind, Location, Name, Original, Format, Fingerprint, Target, Backup;
        public string Stage = "Planned", Issue;
        public string Label { get { return Kind == "Run value" ? Location + "  /  " + Name : Location; } }
    }

    internal class Sources
    {
        internal readonly string Startup;
        internal readonly string[] RunKeys;
        internal Sources(string startup, params string[] keys) { Startup=startup; RunKeys=keys; }
        internal static Sources Local() { return new Sources(Environment.GetFolderPath(Environment.SpecialFolder.Startup),
            @"Software\Microsoft\Windows\CurrentVersion\Run", @"Software\Microsoft\Windows\CurrentVersion\RunOnce"); }
        internal static string HashFile(string path)
        {
            using (var stream = File.OpenRead(path)) using (var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(stream));
        }
        internal static string Match(string command, IEnumerable<string> targets)
        {
            var cmd = Environment.ExpandEnvironmentVariables(command ?? "").Trim();
            foreach (var path in targets) {
                if (Paths.Equal(cmd,path) || Paths.Equal(cmd,"\"" + path + "\"")) return path;
                foreach (string prefix in new [] {path, "\"" + path + "\""}) if (cmd.StartsWith(prefix,StringComparison.OrdinalIgnoreCase) &&
                    cmd.Length > prefix.Length && Char.IsWhiteSpace(cmd[prefix.Length])) return path;
            }
            return null;
        }
        internal virtual List<SourceItem> Inspect(Settings settings, HashSet<string> paths, List<string> notes)
        {
            var list = new List<SourceItem>();
            if (paths.Count == 0) return list;
            if (settings.PauseRun) foreach (string sub in RunKeys) {
                try { using (var key = Registry.CurrentUser.OpenSubKey(sub)) {
                    if (key == null) continue;
                    foreach (var name in key.GetValueNames()) {
                        var data=key.GetValue(name,null,RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
                        var target=Match(data,paths);
                        if (target != null) list.Add(new SourceItem {Kind="Run value",Location=sub,Name=name,Original=data,Format=key.GetValueKind(name).ToString(),Target=target});
                    }
                }} catch(Exception ex) {notes.Add("Startup registry inventory: " + ex.Message);}
            }
            if (settings.PauseFiles && Directory.Exists(Startup)) {
                object shell = null;
                try {
                    shell=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell",true));
                    foreach (string file in Directory.GetFiles(Startup)) {
                        if ((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0) continue;
                        string image = Paths.Equal(Path.GetExtension(file),".lnk") ? Software.Shortcut(shell,file) : file;
                        string target=Match(image,paths);
                        if (target!=null) list.Add(new SourceItem {Kind="Startup file",Location=file,Target=target,Fingerprint=HashFile(file)});
                    }
                } catch(Exception ex) {notes.Add("Startup folder inventory: " + ex.Message);}
                finally {Software.Release(shell);}
            }
            if (settings.PauseTasks) TaskSources.Inspect(paths,list,notes);
            try {
                using (var services=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services")) {
                    foreach (var name in services.GetSubKeyNames()) {
                        try { using (var service=services.OpenSubKey(name)) if (service!=null && Match(service.GetValue("ImagePath") as string,paths)!=null)
                            notes.Add("Service left running: " + name); } catch (System.Security.SecurityException) {} catch (UnauthorizedAccessException) {}
                    }
                }
            } catch(Exception ex) {notes.Add("Service inventory: " + ex.Message);}
            return list;
        }
        internal void Validate(SourceItem item, string backupDir)
        {
            if (item.Kind=="Run value" && RunKeys.Contains(item.Location,Paths.Comparer) && item.Name!=null &&
                (item.Format=="String" || item.Format=="ExpandString")) return;
            if (item.Kind=="Startup file" && Paths.Equal(Startup,Path.GetDirectoryName(Path.GetFullPath(item.Location))) &&
                Paths.Equal(backupDir,Path.GetDirectoryName(Path.GetFullPath(item.Backup))) && !String.IsNullOrEmpty(item.Fingerprint)) return;
            if (item.Kind=="Scheduled task" && item.Location.StartsWith(@"\") && !String.IsNullOrEmpty(item.Fingerprint)) return;
            throw new InvalidDataException("Unrecognized journal source " + item.Label);
        }
        static bool Original(RegistryKey key, SourceItem item)
        {
            return String.Equals(key.GetValue(item.Name,null,RegistryValueOptions.DoNotExpandEnvironmentNames) as string,item.Original,StringComparison.Ordinal) &&
                key.GetValueKind(item.Name).ToString()==item.Format;
        }
        // A changed precondition is a clean skip, distinguished from an uncertain mutation.
        internal virtual bool Pause(SourceItem item)
        {
            switch(item.Kind) {
                case "Run value":
                    using (var key=Registry.CurrentUser.OpenSubKey(item.Location,true)) {
                        if (key==null || !Original(key,item)) return false;
                        key.DeleteValue(item.Name); return true;
                    }
                case "Startup file":
                    if (!File.Exists(item.Location) || HashFile(item.Location)!=item.Fingerprint || File.Exists(item.Backup)) return false;
                    Directory.CreateDirectory(Path.GetDirectoryName(item.Backup));
                    File.Move(item.Location,item.Backup); return true;
                case "Scheduled task": return TaskSources.Set(item,false);
                default: throw new InvalidDataException("Unknown startup source.");
            }
        }
        internal virtual void Restore(SourceItem item)
        {
            switch(item.Kind) {
                case "Run value":
                    using (var read=Registry.CurrentUser.OpenSubKey(item.Location)) {
                        if(read==null) throw new IOException("Registry key was removed. Restore it and retry.");
                        if(read.GetValueNames().Contains(item.Name,Paths.Comparer)) {
                            if(!Original(read,item)) throw new IOException("A different startup value exists.");
                            return;
                        }
                    }
                    using (var key=Registry.CurrentUser.OpenSubKey(item.Location,true)) {
                        if (key==null) throw new IOException("Registry key was removed. Restore it and retry.");
                        if (!key.GetValueNames().Contains(item.Name, Paths.Comparer))
                            key.SetValue(item.Name,item.Original,(RegistryValueKind)Enum.Parse(typeof(RegistryValueKind),item.Format));
                        if (!Original(key,item)) throw new IOException("A different startup value exists.");
                    }
                    return;
                case "Startup file":
                    if (File.Exists(item.Backup)) {
                        if (File.Exists(item.Location) || HashFile(item.Backup)!=item.Fingerprint) throw new IOException("Startup file conflict. The saved copy is retained.");
                        File.Move(item.Backup,item.Location);
                    }
                    if (!File.Exists(item.Location) || HashFile(item.Location)!=item.Fingerprint) throw new IOException("Original Startup file is missing or different.");
                    return;
                case "Scheduled task":
                    if (!TaskSources.Set(item,true)) throw new IOException("Task definition or principal changed.");
                    return;
                default: throw new InvalidDataException("Unknown startup source.");
            }
        }
    }
}
