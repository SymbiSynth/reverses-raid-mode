using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace RaidMode
{
    internal sealed class ProcessRow
    {
        public int Id, Parent, Session = -1;
        public string Name, Image, Sid, Reason;
        internal string WhitelistRule;
        internal bool Blacklisted;
        internal bool DefaultBench;
        internal bool CanEditWhitelist;
        internal bool IsWindowsComponent;
        internal bool GentleClose;
        internal Action<ProcessRow> ConfirmClosed;
        internal Action<ProcessRow,WinHandle> WaitForClose;
        public long Birth;
        public bool Critical, AllowTree, Close;
        public IntPtr Window;
        internal ProcessRow Copy() {return (ProcessRow)MemberwiseClone();}
        public bool Verified { get { return Birth > 0 && !String.IsNullOrEmpty(Sid) && !String.IsNullOrEmpty(Image) && Session >= 0; } }
        public bool Same(ProcessRow b)
        {
            return b != null && Verified && b.Verified && Id == b.Id && Birth == b.Birth && Sid == b.Sid &&
                Session == b.Session && Paths.Equal(Image, b.Image);
        }
    }

    internal sealed class WinHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        public WinHandle() : base(true) { }
        protected override bool ReleaseHandle() { return Native.CloseHandle(handle); }
    }

    internal static class Native
    {
        internal const uint Query = 0x1000, Terminate = 1, Synchronize = 0x100000;
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct Entry
        {
            public uint Size, Usage; public int Id; public UIntPtr Heap; public uint Module, Threads;
            public int Parent, Priority; public uint Flags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string Name;
        }

        [DllImport("kernel32", SetLastError=true)] static extern WinHandle CreateToolhelp32Snapshot(uint flags, uint pid);
        [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool Process32FirstW(WinHandle h, ref Entry e);
        [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool Process32NextW(WinHandle h, ref Entry e);
        [DllImport("kernel32", SetLastError=true)] internal static extern WinHandle OpenProcess(uint access, bool inherit, int id);
        [DllImport("kernel32")] internal static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool QueryFullProcessImageName(WinHandle h, uint flags, StringBuilder name, ref int size);
        [DllImport("kernel32")] static extern bool GetProcessTimes(WinHandle h, out long birth, out long end, out long kernel, out long user);
        [DllImport("kernel32")] static extern bool IsProcessCritical(WinHandle h, out bool critical);
        [DllImport("kernel32")] static extern bool ProcessIdToSessionId(int pid, out int session);
        [DllImport("advapi32")] static extern bool OpenProcessToken(WinHandle h, uint access, out WinHandle token);
        [DllImport("advapi32")] static extern bool GetTokenInformation(WinHandle token, int kind, IntPtr p, int size, out int needed);
        [DllImport("kernel32", SetLastError=true)] static extern bool TerminateProcess(WinHandle h, uint exitCode);
        [DllImport("kernel32")] static extern uint WaitForSingleObject(WinHandle h, uint ms);
        internal static bool HasExited(WinHandle h) {return WaitForSingleObject(h,0)==0;}
        delegate bool EnumWindow(IntPtr window, IntPtr unused);
        [DllImport("user32")] static extern bool EnumWindows(EnumWindow callback, IntPtr data);
        [DllImport("user32")] static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32")] static extern bool IsWindowEnabled(IntPtr window);
        [DllImport("user32")] static extern IntPtr GetWindow(IntPtr window, uint cmd);
        [DllImport("user32")] static extern uint GetWindowThreadProcessId(IntPtr window, out int id);
        [DllImport("user32", SetLastError=true)] static extern bool PostMessage(IntPtr window, uint msg, IntPtr w, IntPtr l);

        internal static readonly int Self = Process.GetCurrentProcess().Id;
        internal static readonly int Session = Process.GetCurrentProcess().SessionId;
        internal static readonly string User = WindowsIdentity.GetCurrent().User.Value;
        internal static bool Elevated { get { using (var me = WindowsIdentity.GetCurrent()) return new WindowsPrincipal(me).IsInRole(WindowsBuiltInRole.Administrator); } }

        static Dictionary<int,IntPtr> Windows()
        {
            var result = new Dictionary<int,IntPtr>();
            EnumWindows(delegate(IntPtr w, IntPtr unused) {
                int id;
                if (IsWindowVisible(w) && GetWindowThreadProcessId(w, out id) != 0 &&
                    (!result.ContainsKey(id) || (GetWindow(result[id],4)!=IntPtr.Zero && GetWindow(w,4)==IntPtr.Zero)))
                    result[id]=w;
                return true;
            }, IntPtr.Zero);
            return result;
        }

        internal static ProcessRow Read(WinHandle h, int id)
        {
            var p = new ProcessRow { Id = id };
            int session, size = 32768;
            long end, kernel, user;
            if (h.IsInvalid || !ProcessIdToSessionId(id, out session)) return p;
            p.Session = session;
            var image = new StringBuilder(512);
            size = image.Capacity;
            if (!QueryFullProcessImageName(h, 0, image, ref size)) {
                if (Marshal.GetLastWin32Error()!=122) return p;
                image = new StringBuilder(32768); size = image.Capacity;
                if (!QueryFullProcessImageName(h, 0, image, ref size)) return p;
            }
            p.Image = image.ToString(); p.Name = Path.GetFileNameWithoutExtension(p.Image);
            if (!IsProcessCritical(h, out p.Critical) || !GetProcessTimes(h, out p.Birth, out end, out kernel, out user)) return p;
            WinHandle token;
            if (!OpenProcessToken(h, 8, out token)) return p;
            using (token) {
                int length;
                GetTokenInformation(token, 1, IntPtr.Zero, 0, out length);
                if (length <= 0 || length > 65536) return p;
                IntPtr data = Marshal.AllocHGlobal(length);
                try {
                    if (GetTokenInformation(token, 1, data, length, out length))
                        p.Sid = new SecurityIdentifier(Marshal.ReadIntPtr(data)).Value;
                } finally { Marshal.FreeHGlobal(data); }
            }
            return p;
        }

        internal static List<ProcessRow> Snapshot()
        {
            var result = new List<ProcessRow>();
            var windows = Windows();
            using (var snap = CreateToolhelp32Snapshot(2, 0)) {
                var entry = new Entry { Size = (uint)Marshal.SizeOf(typeof(Entry)) };
                if (snap.IsInvalid || !Process32FirstW(snap, ref entry)) throw new Win32Exception(Marshal.GetLastWin32Error());
                do {
                    int session;
                    if (!ProcessIdToSessionId(entry.Id, out session) || session != Session) continue;
                    using (var h = OpenProcess(Query, false, entry.Id)) {
                        var p = Read(h, entry.Id);
                        p.Parent = entry.Parent;
                        if (p.Name == null) p.Name = Path.GetFileNameWithoutExtension(entry.Name);
                        windows.TryGetValue(p.Id, out p.Window);
                        result.Add(p);
                    }
                } while (Process32NextW(snap, ref entry));
                int error = Marshal.GetLastWin32Error();
                if (error != 18) throw new Win32Exception(error);
            }
            if (!result.Any(p => p.Id == Self)) throw new InvalidOperationException("The process inventory is incomplete. Scan again.");
            return result;
        }

        internal static void CloseSelected(IEnumerable<ProcessRow> candidates, int graceMilliseconds,
            CancellationToken stop, Action<string> report)
        {
            var bound = new List<KeyValuePair<ProcessRow,WinHandle>>();
            var requested=new HashSet<ProcessRow>();
            var transferred=new HashSet<WinHandle>();
            bool sent = false;
            try {
                foreach (var p in candidates) {
                    if(stop.IsCancellationRequested)break;
                    if (!p.Close || p.Sid != User || p.Session != Session || p.Id == Self) continue;
                    var h = OpenProcess(Query | Synchronize | (p.GentleClose?0:Terminate), false, p.Id);
                    var check = Read(h, p.Id);
                    if (!p.Same(check) || check.Critical) {
                        h.Dispose(); report("Skipped " + p.Name + " (" + p.Id + ") - exited, changed, or access denied."); continue;
                    }
                    bound.Add(new KeyValuePair<ProcessRow,WinHandle>(p, h));
                    if(p.GentleClose) {
                        if(p.Window!=IntPtr.Zero) {
                            EnumWindows(delegate(IntPtr window,IntPtr unused) {
                                int owner;IntPtr parent=GetWindow(window,4);
                                if(GetWindowThreadProcessId(window,out owner)!=0 && owner==p.Id && IsWindowVisible(window) &&
                                    IsWindowEnabled(window) && (parent==IntPtr.Zero || !IsWindowVisible(parent)) && PostMessage(window,0x10,IntPtr.Zero,IntPtr.Zero))
                                    requested.Add(p);
                                return true;
                            },IntPtr.Zero);
                            sent|=requested.Contains(p);
                        }
                        continue;
                    }
                    int windowId;
                    if (graceMilliseconds > 0 && p.Window != IntPtr.Zero && GetWindowThreadProcessId(p.Window, out windowId) != 0 && windowId == p.Id)
                        sent |= PostMessage(p.Window, 0x10, IntPtr.Zero, IntPtr.Zero);
                }
                if (sent) stop.WaitHandle.WaitOne(graceMilliseconds);
                foreach (var entry in bound) {
                    var p = entry.Key; var h = entry.Value;
                    if (WaitForSingleObject(h, 0) == 0) {
                        if(requested.Contains(p) && p.ConfirmClosed!=null)p.ConfirmClosed(p);
                        report("Closed normally: " + p.Name); continue;
                    }
                    if(p.GentleClose) {
                        if(requested.Contains(p) && p.WaitForClose!=null) {
                            p.WaitForClose(p,h);transferred.Add(h);
                        }
                        if(p.Window!=IntPtr.Zero)report("Kept open: "+p.Name+" is still running. Check for an open window or save prompt.");
                        continue;
                    }
                    if(stop.IsCancellationRequested)continue;
                    var check = Read(h, p.Id);
                    if (!p.Same(check) || check.Critical) { report("Skipped after recheck: " + p.Name); continue; }
                    if (!TerminateProcess(h, 1)) { report("Could not close " + p.Name + ": " + new Win32Exception(Marshal.GetLastWin32Error()).Message); continue; }
                    bool exited=WaitForSingleObject(h,150)==0;
                    if(p.ConfirmClosed!=null) {
                        if(exited)p.ConfirmClosed(p);
                        else if(p.WaitForClose!=null){p.WaitForClose(p,h);transferred.Add(h);}
                    }
                    report((exited?"Force-closed: ":"Close requested, exit unverified: ") + p.Name + " (" + p.Id + ")");
                }
                stop.ThrowIfCancellationRequested();
            } finally { foreach (var entry in bound)if(!transferred.Contains(entry.Value))entry.Value.Dispose(); }
        }
    }
}
