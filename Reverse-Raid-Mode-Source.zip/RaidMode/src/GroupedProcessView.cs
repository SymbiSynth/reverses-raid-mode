using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace RaidMode
{
    internal sealed partial class GroupedProcessView : SortableListView
    {
        internal const int DetailsColumn=3;
        internal event Action<ListViewItem> DetailsRequested;
        internal event Action ViewScrolled;

        internal static void AddDetailsLink(ListViewItem row)
        {
            row.UseItemStyleForSubItems=false;
            row.SubItems[DetailsColumn].Text="Details";
            row.SubItems[DetailsColumn].ForeColor=RaidTheme.Accent;
        }

        sealed class FamilyEntry : ListViewItem
        {
            internal readonly AppFamily Family;
            internal readonly List<ListViewItem> Roots;
            internal readonly List<ListViewItem> Children=new List<ListViewItem>();
            internal readonly string SelectionKey;
            internal FamilyEntry(AppFamily family,List<ListViewItem> roots,bool open)
            {
                Family=family;Name=family.Key;Roots=roots;
                if(open)foreach(var root in roots.OrderBy(r=>r.SubItems[6].Text,Paths.Comparer)) {
                    var entry=root as Entry;
                    if(entry!=null)foreach(var process in entry.Members) {
                        var child=new Entry(new[]{process},null,false);
                        child.Text="\u2003\u2003"+family.ExecutableLabel(process.Image)+" (PID "+process.Id+")";
                        Children.Add(child);
                    } else {
                        var child=(ListViewItem)root.Clone();child.Name=root.Name;child.Tag=root.Tag;
                        child.Text="\u2003\u2003"+family.ExecutableLabel(root.SubItems[6].Text);
                        Children.Add(child);
                    }
                }
                var paths=roots.Select(r=>r.SubItems[6].Text).OrderBy(s=>s,Paths.Comparer).ToArray();
                SelectionKey=Name+"|"+String.Join("|",paths);
                int running=roots.OfType<Entry>().Sum(r=>r.Members.Length);
                bool scanned=roots.All(r=>r.SubItems[2].Text!="Awaiting scan");
                Text=(open?"\u25BE  ":"\u25B8  ")+family.Name+" ("+paths.Length+(paths.Length==1?" file":" files")+
                    (scanned?", "+running+" running":"")+")";
                SubItems.Add(Common(roots,1));MainWindow.TintRule(this);SubItems.Add(Common(roots,2));
                for(int i=3;i<=6;i++)SubItems.Add("");
                AddDetailsLink(this);
                ToolTipText=family.Name+Environment.NewLine+"Expand to see individual executables and processes. Editing this row changes its visible, editable executables."+
                    Environment.NewLine+String.Join(Environment.NewLine,roots.Select(r=>r.SubItems[1].Text+"  /  "+r.SubItems[2].Text+"  /  "+r.SubItems[6].Text));
            }
            static string Common(List<ListViewItem> rows,int column)
            {
                string first=rows[0].SubItems[column].Text;
                return rows.All(r=>r.SubItems[column].Text==first)?first:"Mixed";
            }
        }

        sealed class Entry : ListViewItem
        {
            internal readonly ProcessRow[] Members;
            internal readonly Entry ParentApp;
            internal bool IsApp { get { return Members.Length > 1; } }
            internal ProcessRow First { get { return Members[0]; } }

            internal Entry(ProcessRow[] members, Entry parent, bool expanded)
            {
                Members = members;
                ParentApp = parent;
                var p = First;
                Name = IsApp ? p.Image : p.Id.ToString(CultureInfo.InvariantCulture);
                Tag = IsApp ? (object)members : p;
                Text = IsApp ? (expanded ? "\u25BE  " : "\u25B8  ") + p.Name + " (" + members.Length + ")"
                             : (parent == null ? "" : "\u2003\u2003") + p.Name;
                if(Program.Personal && parent!=null) Text+=" (PID "+p.Id+")";
                SubItems.Add(Common(Membership));
                if(Program.Personal) MainWindow.TintRule(this);
                SubItems.Add(Common(m => m.Close ? "Close" : "Keep"));
                SubItems.Add(IsApp ? "" : Name);
                SubItems.Add(Common(m => m.Window == IntPtr.Zero ? "Background" : "Window"));
                SubItems.Add(Common(m => m.Reason));
                SubItems.Add(p.Image ?? "Unavailable");
                int close = members.Count(m => m.Close);
                ToolTipText = IsApp ? String.Format("{0} processes: {1} to close, {2} kept.\nClick the arrow to expand or collapse.\n",members.Length,close,members.Length-close) : "";
                ToolTipText += String.Join(Environment.NewLine, SubItems.Cast<ListViewSubItem>().Select(s => s.Text).Where(s => !String.IsNullOrEmpty(s)));
                if (p.WhitelistRule != null) ToolTipText += Environment.NewLine + p.WhitelistRule;
                if(Program.Personal) AddDetailsLink(this);
            }
            static string Membership(ProcessRow p)
            {
                if(Program.Personal) return MainWindow.PersonalRuleLabel(p.Blacklisted,p.WhitelistRule);
                if (!p.CanEditWhitelist) return "Locked";
                if (p.Blacklisted) return "Blacklisted";
                if (p.WhitelistRule == null) return "Off whitelist";
                return Paths.Equal(p.WhitelistRule,p.Image) ? "Listed app" : "Listed folder";
            }
            string Common(Func<ProcessRow,string> value)
            {
                string first = value(First);
                for (int i=1; i<Members.Length; i++)
                    if (value(Members[i]) != first) return "Mixed";
                return first;
            }
        }

        readonly HashSet<string> expanded = new HashSet<string>(Paths.Comparer);
        readonly HashSet<string> openFamilies=new HashSet<string>(Paths.Comparer);
        readonly HashSet<string> foldedSearchFamilies=new HashSet<string>(Paths.Comparer);
        readonly Dictionary<ListViewItem,FamilyEntry> parentFamilies=new Dictionary<ListViewItem,FamilyEntry>();
        Dictionary<string,AppFamily> families;
        string searchTerm="";
        ProcessRow[][] groups = new ProcessRow[0][];
        List<ListViewItem> offline;

        internal IEnumerable<ProcessRow> SelectedProcesses()
        {
            return SelectedMembers().OfType<Entry>().SelectMany(e => e.Members).Distinct();
        }
        internal IEnumerable<ListViewItem> SelectedMembers()
        {
            foreach(ListViewItem row in SelectedItems) {
                var family=row as FamilyEntry;
                if(family==null)yield return row;
                else foreach(var root in family.Roots)yield return root;
            }
        }
        internal void RevealPaths(IEnumerable<string> paths)
        {
            if(families==null)return;
            bool changed=false;
            foreach(string path in paths) {
                AppFamily family;
                if(families.TryGetValue(path,out family))changed|=openFamilies.Add(family.Key);
            }
            if(changed)Rebuild(false,null);
        }

        internal void Display(IEnumerable<ProcessRow> rows, bool retainSelection,List<ListViewItem> offlineRows=null,
            Dictionary<string,AppFamily> owners=null,string term="")
        {
            offline=offlineRows;
            families=owners;
            if(term!=searchTerm){searchTerm=term;foldedSearchFamilies.Clear();}
            // A missing image cannot establish that two instances belong to the same executable.
            groups = rows.GroupBy(p => String.IsNullOrEmpty(p.Image) ? p.Id.ToString(CultureInfo.InvariantCulture) : p.Image, Paths.Comparer)
                .Select(g => g.OrderBy(p => p.Id).ToArray())
                .OrderBy(g => g[0].Name, Paths.Comparer).ThenBy(g => g[0].Image, Paths.Comparer).ToArray();
            Rebuild(retainSelection,null);
        }

        internal void ForgetMissingPaths(IEnumerable<ProcessRow> snapshot)
        {
            expanded.IntersectWith(snapshot.Where(p => !p.IsWindowsComponent && p.Image != null).Select(p => p.Image));
        }

        void Rebuild(bool retainSelection, string focusApp)
        {
            var selected = new HashSet<string>(Paths.Comparer);
            string top = null, focus = focusApp;
            if (retainSelection) {
                foreach (ListViewItem item in SelectedItems) selected.Add(SelectionKey(item));
                if (focus == null && FocusedItem != null) focus = FocusedItem.Name;
                if (TopItem != null) top = TopItem.Name;
            }

            var roots = new List<ListViewItem>();
            foreach (var members in groups) {
                bool open = members.Length > 1 && expanded.Contains(members[0].Image);
                roots.Add(new Entry(members,null,open));
            }
            if(offline!=null && offline.Count>0) {
                roots.AddRange(offline);
                roots=roots.OrderBy(DisplayName,Paths.Comparer).ThenBy(r=>r.Name,Paths.Comparer).ToList();
            }
            var entries=new List<ListViewItem>();
            parentFamilies.Clear();
            if(families!=null) {
                var owned=roots.Where(r=>families.ContainsKey(r.SubItems[6].Text))
                    .GroupBy(r=>families[r.SubItems[6].Text].Key,Paths.Comparer).ToArray();
                var nested=new HashSet<ListViewItem>();
                foreach(var group in owned) {
                    var parts=group.ToList();
                    var owner=families[parts[0].SubItems[6].Text];
                    if(parts.Count==1 && !owner.ShowOwnerWhenAlone)continue;
                    var family=new FamilyEntry(owner,parts,FamilyOpen(owner.Key));
                    roots.Add(family);
                    nested.UnionWith(parts);
                }
                roots=roots.Where(r=>!nested.Contains(r)).OrderBy(DisplayName,Paths.Comparer).ThenBy(r=>r.Name,Paths.Comparer).ToList();
            }
            foreach(var root in roots) {
                entries.Add(root);
                var family=root as FamilyEntry;
                if(family!=null && FamilyOpen(family.Name))foreach(var child in family.Children){
                    parentFamilies.Add(child,family);entries.Add(child);
                }
                var app=root as Entry;
                if(app!=null && app.IsApp && expanded.Contains(app.Name))
                    foreach(var p in app.Members) entries.Add(new Entry(new[]{p},app,false));
            }
            BeginUpdate();
            try { Items.Clear(); Items.AddRange(entries.ToArray()); }
            finally { EndUpdate(); }
            foreach (var entry in entries) {
                if (selected.Contains(SelectionKey(entry)) || Paths.Equal(entry.Name,focusApp)) entry.Selected = true;
                if (Paths.Equal(entry.Name,top)) TopItem = entry;
            }
            if(focus!=null && Items.ContainsKey(focus)) Items[focus].Focused=true;
            if (focusApp != null && FocusedItem != null) FocusedItem.EnsureVisible();
        }
        static string SelectionKey(ListViewItem row)
        {
            var family=row as FamilyEntry;
            return family==null?row.Name:family.SelectionKey;
        }
        bool FamilyOpen(string key){return searchTerm.Length>0?!foldedSearchFamilies.Contains(key):openFamilies.Contains(key);}
        void ToggleFamily(FamilyEntry family)
        {
            var state=searchTerm.Length>0?foldedSearchFamilies:openFamilies;
            if(!state.Remove(family.Name))state.Add(family.Name);
            Rebuild(true,family.Name);
        }

        void Toggle(Entry app)
        {
            if (!expanded.Remove(app.Name)) expanded.Add(app.Name);
            Rebuild(true,app.Name);
        }

        bool OnArrow(ListViewItem app, Point point)
        {
            if(rosterStyled)return DisclosureRect(app).Contains(point);
            var label = GetItemRect(app.Index,ItemBoundsPortion.Label);
            return point.X >= label.Left && point.X < label.Left + Font.Height + 5;
        }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            var details=DetailsAt(e.Location);
            if(e.Button==MouseButtons.Left && details!=null) {DetailsRequested(details);return;}
            var row=GetItemAt(e.X,e.Y);
            var family=row as FamilyEntry;
            if(e.Button==MouseButtons.Left && family!=null && OnArrow(family,e.Location)){ToggleFamily(family);return;}
            var app = row as Entry;
            if (e.Button == MouseButtons.Left && app != null && app.IsApp && OnArrow(app,e.Location)) Toggle(app);
        }
        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            base.OnMouseDoubleClick(e);
            if(DetailsAt(e.Location)!=null)return;
            var row=GetItemAt(e.X,e.Y);
            var family=row as FamilyEntry;
            if(e.Button==MouseButtons.Left && family!=null && !OnArrow(family,e.Location)){ToggleFamily(family);return;}
            var app = row as Entry;
            if (e.Button == MouseButtons.Left && app != null && app.IsApp && !OnArrow(app,e.Location)) Toggle(app);
        }
        ListViewItem DetailsAt(Point point)
        {
            if(DetailsRequested==null || !IsHandleCreated || !ClientRectangle.Contains(point) || Columns.Count<=DetailsColumn)return null;
            // WinForms HitTest can index subitem -1 in the blank area to the right of the columns.
            var row=GetItemAt(point.X,point.Y);
            if(row==null || row.SubItems.Count<=DetailsColumn)return null;
            var cell=row.SubItems[DetailsColumn];
            return cell.Text=="Details" && cell.Bounds.Contains(point)?row:null;
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if(DetailsRequested!=null) Cursor=DetailsAt(e.Location)!=null?Cursors.Hand:Cursors.Default;
        }
        protected override void OnColumnClick(ColumnClickEventArgs e)
        {
            if(DetailsRequested!=null && e.Column==DetailsColumn)return;
            base.OnColumnClick(e);
        }
        protected override bool ProcessCmdKey(ref Message msg,Keys keyData)
        {
            var row=FocusedItem;
            if(keyData==(Keys.Alt|Keys.Enter) && DetailsRequested!=null && row!=null &&
                row.SubItems.Count>DetailsColumn && row.SubItems[DetailsColumn].Text=="Details") {
                DetailsRequested(row);return true;
            }
            return base.ProcessCmdKey(ref msg,keyData);
        }
        protected override void WndProc(ref Message msg)
        {
            if(HandleRosterCheckbox(ref msg))return;
            const int rightDown=0x204,rightUp=0x205;
            if(ContextMenuStrip!=null && (msg.Msg==rightDown || msg.Msg==rightUp)) {
                var point=new Point(unchecked((int)msg.LParam.ToInt64()));
                var row=GetItemAt(point.X,point.Y);
                if(row==null)return;
                if(msg.Msg==rightDown) {
                    Focus();
                    if(!row.Selected) {SelectedItems.Clear();row.Selected=true;}
                    row.Focused=true;
                } else if(row.Selected) ContextMenuStrip.Show(this,point);
                return;
            }
            // The details card is anchored to a cell. Scrolling moves that cell.
            if(ViewScrolled!=null && (msg.Msg==0x114 || msg.Msg==0x115 || msg.Msg==0x20A || msg.Msg==0x20E)) ViewScrolled();
            base.WndProc(ref msg);
        }
        protected override bool IsInputKey(Keys keyData)
        {
            if ((keyData == Keys.Enter || keyData == Keys.Right || keyData == Keys.Left) &&
                (FocusedItem is Entry || FocusedItem is FamilyEntry || (FocusedItem!=null && parentFamilies.ContainsKey(FocusedItem))))
                return true;
            return base.IsInputKey(keyData);
        }
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if(rosterStyled && e.Control && e.KeyCode==Keys.A){SelectVisible(true);e.SuppressKeyPress=true;return;}
            if(rosterStyled && e.KeyCode==Keys.Space && e.Modifiers==Keys.None && FocusedItem!=null){
                FocusedItem.Selected=!FocusedItem.Selected;e.SuppressKeyPress=true;return;
            }
            var family=FocusedItem as FamilyEntry;
            bool atFamily=family!=null;
            if(!atFamily && FocusedItem!=null)parentFamilies.TryGetValue(FocusedItem,out family);
            if(family!=null && e.Modifiers==Keys.None &&
                ((atFamily && e.KeyCode==Keys.Enter) || (e.KeyCode==Keys.Right && !FamilyOpen(family.Name)) || (e.KeyCode==Keys.Left && FamilyOpen(family.Name)))) {
                ToggleFamily(family);e.SuppressKeyPress=true;return;
            }
            var entry = FocusedItem as Entry;
            var app = entry == null ? null : entry.ParentApp ?? entry;
            if (app != null && app.IsApp && e.Modifiers == Keys.None) {
                bool open = expanded.Contains(app.Name);
                if ((e.KeyCode == Keys.Enter && entry.IsApp) || (e.KeyCode == Keys.Right && !open) || (e.KeyCode == Keys.Left && open)) {
                    Toggle(app);
                    e.SuppressKeyPress = true;
                    return;
                }
            }
            base.OnKeyDown(e);
        }

        static string DisplayName(ListViewItem row)
        {
            var family=row as FamilyEntry;
            if(family!=null)return family.Family.Name;
            var entry=row as Entry;
            return entry==null?row.Text:entry.First.Name;
        }

        protected override int CompareRows(ListViewItem left, ListViewItem right)
        {
            FamilyEntry leftFamily,rightFamily;
            parentFamilies.TryGetValue(left,out leftFamily);parentFamilies.TryGetValue(right,out rightFamily);
            leftFamily=leftFamily??left as FamilyEntry;rightFamily=rightFamily??right as FamilyEntry;
            if(leftFamily!=null || rightFamily!=null) {
                if(left==right)return 0;
                if(leftFamily==rightFamily){
                    if(left==leftFamily)return -1;
                    if(right==rightFamily)return 1;
                } else {
                    var leftApp=left as Entry;var rightApp=right as Entry;
                    left=(ListViewItem)leftFamily??(leftApp==null?left:leftApp.ParentApp??leftApp);
                    right=(ListViewItem)rightFamily??(rightApp==null?right:rightApp.ParentApp??rightApp);
                }
                int order=SortColumn==0?Paths.Comparer.Compare(DisplayName(left),DisplayName(right)):
                    Paths.Comparer.Compare(left.SubItems[SortColumn].Text,right.SubItems[SortColumn].Text);
                if(order!=0)return InSortDirection(order);
                order=Paths.Comparer.Compare(DisplayName(left),DisplayName(right));
                return order!=0?order:Paths.Comparer.Compare(left.Name,right.Name);
            }
            var a = left as Entry;
            var b = right as Entry;
            if (a == null || b == null) {
                // Compare an offline app against the whole group so its children stay together.
                if(a!=null) left=a.ParentApp??a;
                if(b!=null) right=b.ParentApp??b;
                string leftName=DisplayName(left), rightName=DisplayName(right);
                int order=SortColumn==0?Paths.Comparer.Compare(leftName,rightName):
                    Paths.Comparer.Compare(left.SubItems[SortColumn].Text,right.SubItems[SortColumn].Text);
                if(order!=0)return InSortDirection(order);
                order=Paths.Comparer.Compare(leftName,rightName);
                return order==0?Paths.Comparer.Compare(left.SubItems[left.SubItems.Count-1].Text,right.SubItems[right.SubItems.Count-1].Text):order;
            }
            if (a == b) return 0;
            var rootA = a.ParentApp ?? a;
            var rootB = b.ParentApp ?? b;
            if (rootA != rootB) { a = rootA; b = rootB; }
            else if (a.IsApp) return -1;
            else if (b.IsApp) return 1;

            int result;
            if (SortColumn == 0) result = Paths.Comparer.Compare(a.First.Name,b.First.Name);
            else if (SortColumn == 3) result = a.First.Id.CompareTo(b.First.Id);
            else result = Paths.Comparer.Compare(a.SubItems[SortColumn].Text,b.SubItems[SortColumn].Text);
            if (result != 0) return InSortDirection(result);
            result = Paths.Comparer.Compare(a.First.Name,b.First.Name);
            if (result == 0) result = Paths.Comparer.Compare(a.First.Image,b.First.Image);
            return result == 0 ? a.First.Id.CompareTo(b.First.Id) : result;
        }
    }
}
