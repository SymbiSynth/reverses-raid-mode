using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace RaidMode
{
    internal sealed partial class MainWindow
    {
        enum PersonalRule { Whitelist, Blacklist, Clear }
        enum PersonalView { All, Rostered, Benched, Flex, Suggested }
        PersonalView personalView;
        readonly List<Button> viewButtons=new List<Button>();
        readonly Panel personalEdits=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty};
        readonly Button blockProcess=Btn("Bench",false), flexProcess=Btn("Flex",false), manageRules=Btn("Manage rules \u25be",false);
        readonly ToolStripMenuItem clearAll=new ToolStripMenuItem("Clear all rules...");
        readonly ToolStripMenuItem benchAside=new ToolStripMenuItem("Bench Aside and its helpers by default");
        readonly ToolStripMenuItem afterRaidMenu=new ToolStripMenuItem("After raid");
        readonly ToolStripMenuItem raidDefaults=new ToolStripMenuItem("Roster Discord and WoW by default and bench other apps");
        readonly Label selectionLabel=LabelOf("Set rule",10,true), emptyRoster=LabelOf("",10,false);
        readonly ToolTip ruleTips=new ToolTip();
        static readonly string[] ViewNames={"All apps","Rostered","Benched","Flex","Suggested"};
        readonly TextBox selectedDetails=new TextBox {Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill};
        Panel rowDetails;
        Button backToRow;
        TextBox rowDetailsText;
        const string Rostered="Rostered", Benched="Benched", Flex="Flex";

        internal static string PersonalRuleLabel(bool blocked,string matchingRule)
        {
            if(blocked) return Benched;
            return matchingRule==null?Flex:Rostered;
        }

        internal static void TintRule(ListViewItem row)
        {
            var cell=row.SubItems[1];
            if(SystemInformation.HighContrast || (cell.Text!=Rostered && cell.Text!=Benched && cell.Text!=Flex))return;
            row.UseItemStyleForSubItems=false;
            cell.BackColor=cell.Text==Rostered?RaidTheme.GreenBg:cell.Text==Benched?RaidTheme.BenchBg:RaidTheme.FlexBg;
            cell.ForeColor=cell.Text==Rostered?RaidTheme.Green:cell.Text==Benched?RaidTheme.Rose:RaidTheme.Blue;
        }

        void BuildSessionRules()
        {
            removeProcess.Text="Clear rule";
            personalEdits.BackColor=RaidTheme.Surface;personalEdits.Padding=new Padding(10,0,7,0);
            foreach(string label in ViewNames) {
                var view=(PersonalView)viewButtons.Count;
                var button=Btn(label,view==PersonalView.All);
                button.Padding=new Padding(5,0,5,0);
                button.Click+=(o,e)=>SelectPersonalView(view);
                viewButtons.Add(button);review.Controls.Add(button);
            }
            var viewRow=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=1,Margin=Padding.Empty,Padding=new Padding(10,0,10,0),BackColor=RaidTheme.Surface};
            viewRow.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            RaidTheme.TableBand(viewRow,true,false);RaidTheme.TableBand(personalEdits,false,false);
            viewRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));viewRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));viewRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            review.BackColor=RaidTheme.Surface;review.AutoSize=true;review.Anchor=AnchorStyles.Left;review.Dock=DockStyle.None;
            viewRow.Controls.Add(review,0,0);viewRow.Controls.Add(BuildRosterSearch(),1,0);
            filter.Anchor=AnchorStyles.Right;filter.Width=104;filter.Margin=new Padding(6,0,0,0);viewRow.Controls.Add(filter,2,0);
            RaidTheme.DarkNative(filter);AddRow(home,viewRow,39);
            filter.Items[0]="All actions";filter.AccessibleName="Filter preview by action or report";
            keep.Text="Roster";
            selectionLabel.Dock=DockStyle.Left;selectionLabel.Width=109;selectionLabel.Font=new Font("Segoe UI",8,FontStyle.Bold);selectionLabel.ForeColor=RaidTheme.Soft;
            selectionLabel.AccessibleName="Selected apps";
            var ruleActions=Bar();ruleActions.Padding=new Padding(0,3,0,0);ruleActions.Controls.AddRange(new Control[]{keep,blockProcess,flexProcess,removeProcess});
            var manage=Bar();manage.AutoSize=true;manage.Dock=DockStyle.Right;
            manage.Padding=new Padding(0,3,0,0);manage.Controls.Add(manageRules);
            var options=new ContextMenuStrip();RaidTheme.Menu(options);
            options.Items.Add("Add executable...",null,(o,e)=>BrowseExecutables());
            options.Items.Add("Allow folder...",null,(o,e)=>AllowFolder());
            options.Items.Add(benchAside);
            if(Program.Raiders) {
                options.Items.Add(raidDefaults);
                raidDefaults.Click+=(o,e)=>{
                    var updated=settings.Copy();updated.UseRaidDefaults=!settings.UseRaidDefaults;
                    SavePolicy(updated.UseRaidDefaults?"Raid defaults enabled.":"Raid defaults disabled.",updated);
                };
            }
            options.Items.Add(new ToolStripSeparator());options.Items.Add(clearAll);
            benchAside.Click+=(o,e)=>{
                var updated=settings.Copy();updated.BenchAside=!settings.BenchAside;
                string note=updated.BenchAside?"Aside defaults to Benched.":"Aside default rule removed.";
                SavePolicy(note,updated,note);
            };
            manageRules.Click+=(o,e)=>options.Show(manageRules,new Point(0,manageRules.Height));
            manageRules.AccessibleDescription="Add an executable, allow a folder, set the Aside default, or clear all rules.";
            manageRules.Disposed+=(o,e)=>options.Dispose();
            personalEdits.Controls.Add(ruleActions);personalEdits.Controls.Add(selectionLabel);personalEdits.Controls.Add(manage);
            ((RaidButton)keep).Glyph="\uE73E";((RaidButton)blockProcess).Glyph="\uE738";((RaidButton)flexProcess).Glyph="\uE945";((RaidButton)removeProcess).Glyph="\uE7A7";
            AddRow(home,personalEdits,36);
            var descriptions=new[]{"Keep the selected apps open during a raid.","Close the selected apps during a raid when eligible.",
                "Clear the selected rules. Flex follows your raid settings."};
            var buttons=new[]{keep,blockProcess,flexProcess};
            for(int i=0;i<buttons.Length;i++){buttons[i].AccessibleDescription=descriptions[i];ruleTips.SetToolTip(buttons[i],descriptions[i]);}
            ruleTips.SetToolTip(removeProcess,descriptions[2]);
            ruleTips.SetToolTip(suggestions,"Roster all pending suggestions, including detected Battle.net, Archon and browser apps.");
            suggestions.AccessibleDescription=ruleTips.GetToolTip(suggestions);
            ruleTips.SetToolTip(manageRules,manageRules.AccessibleDescription);
            ruleTips.SetToolTip(selectionLabel,"Select apps to change their rules. Open Details on a view-only row to see why it is protected.");
            blockProcess.Click+=(o,e)=>EditPersonalProcesses(PersonalRule.Blacklist);
            flexProcess.Click+=(o,e)=>EditPersonalProcesses(PersonalRule.Clear);
            clearAll.Click+=(o,e)=>ClearAllRules();
            var menu=new ContextMenuStrip();RaidTheme.Menu(menu);
            var roster=menu.Items.Add("Set to Rostered",null,(o,e)=>keep.PerformClick());
            var bench=menu.Items.Add("Set to Benched",null,(o,e)=>blockProcess.PerformClick());
            var clear=menu.Items.Add("Set to Flex (clear rule)",null,(o,e)=>flexProcess.PerformClick());
            if(Program.Raiders) {
                menu.Items.Add(new ToolStripSeparator());menu.Items.Add(afterRaidMenu);
                var popup=afterRaidMenu.DropDown;
                popup.BackColor=menu.BackColor;
                popup.ForeColor=SystemInformation.HighContrast?menu.ForeColor:Color.White;
                popup.Renderer=menu.Renderer;
                foreach(AfterRaidMode value in Enum.GetValues(typeof(AfterRaidMode))) {
                    var choice=value;
                    var item=new ToolStripMenuItem(AppReopen.Label(choice)){Tag=choice};
                    item.Click+=(o,e)=>SaveReturnChoice(choice);
                    afterRaidMenu.DropDownItems.Add(item);
                }
                afterRaidMenu.DropDownOpening+=(o,e)=>{
                    var selected=SelectedPersonalPaths().Where(AppReopen.Eligible).Select(settings.AfterMode).Distinct().ToList();
                    foreach(ToolStripMenuItem item in afterRaidMenu.DropDownItems)
                        item.Checked=selected.Count==1 && selected[0]==(AfterRaidMode)item.Tag;
                };
                afterRaidMenu.ToolTipText="Used when you start a session with your per-app choices.";
            }
            menu.Opening+=(o,e)=>{
                roster.Enabled=keep.Enabled;
                bench.Enabled=blockProcess.Enabled;
                clear.Enabled=removeProcess.Enabled;
                e.Cancel=!roster.Enabled && !bench.Enabled && !clear.Enabled && !(Program.Raiders && afterRaidMenu.Enabled);
            };
            processes.ContextMenuStrip=menu;
            processes.Disposed+=(o,e)=>menu.Dispose();
        }
        void SaveReturnChoice(AfterRaidMode choice)
        {
            if(mode==WindowMode.ReadOnly || busy || session.Active || session.NeedsRecovery)return;
            var paths=SelectedPersonalPaths().Where(AppReopen.Eligible).ToList();
            if(paths.Count==0)return;
            try {
                var updated=settings.Copy();
                foreach(string path in paths)updated.SetAfterMode(path,choice);
                string note="Saved "+AppReopen.Label(choice)+" for "+paths.Count+(paths.Count==1?" app.":" apps.");
                SavePolicy(note,updated,note);
            } catch(Exception ex){Error(ex);}
        }
        void SelectPersonalView(PersonalView view)
        {
            personalView=view;
            if(filter.SelectedIndex>=3)filter.SelectedIndex=0;
            else FillPlan();
        }

        void ShowViewCounts(int[] counts)
        {
            for(int i=0;i<viewButtons.Count;i++) {
                bool active=(int)personalView==i && filter.SelectedIndex<3;
                var button=viewButtons[i];
                button.Text=(active?"\u2713 ":"")+ViewNames[i]+" ("+counts[i]+")";
                button.AccessibleName=ViewNames[i]+", "+counts[i]+(active?", selected":"");
                ruleTips.SetToolTip(button,"Show "+ViewNames[i]+". Total before search and action filters.");
                button.BackColor=active?RaidTheme.Violet:RaidTheme.Surface;
                button.ForeColor=active?RaidTheme.Accent:RaidTheme.Soft;
                button.FlatAppearance.BorderColor=active?RaidTheme.VioletEdge:RaidTheme.Surface;
            }
        }

        void BuildPersonalDetails()
        {
            AddRow(whitelist,LabelOf("Details",21,true),45);
            AddRow(whitelist,LabelOf("How suggestions work",13,true),34);
            AddRow(whitelist,LabelOf("Scan finds raid apps, your Windows default browser and other running browsers. Apply suggestions rosters the matches you have not already assigned. Your manual choices take priority.",10,false),63);
            AddRow(whitelist,LabelOf(String.Join(", ",RaidSuggestion.Products.Select(p=>p.Name)),10,false),55);
            AddRow(whitelist,LabelOf("Selected in Session",13,true),34);
            selectedDetails.BackColor=RaidTheme.Surface;selectedDetails.ForeColor=RaidTheme.Text;RaidTheme.DarkNative(selectedDetails);AddRow(whitelist,selectedDetails,-1);
            var options=Bar();options.Controls.Add(SystemRulesButton());AddRow(whitelist,options,42);
        }
        void BuildRowDetails(Panel results)
        {
            emptyRoster.Dock=DockStyle.None;emptyRoster.TextAlign=ContentAlignment.MiddleCenter;
            emptyRoster.ForeColor=RaidTheme.Soft;emptyRoster.BackColor=RaidTheme.Surface;
            emptyRoster.Visible=false;results.Controls.Add(emptyRoster);
            results.SizeChanged+=(o,e)=>{
                int inset=(int)(30*DeviceScaling);
                emptyRoster.SetBounds(inset,inset,Math.Max(0,results.ClientSize.Width-2*inset),Math.Max(0,results.ClientSize.Height-2*inset));
            };
            rowDetails=new Panel{Visible=false,BackColor=RaidTheme.Header,BorderStyle=BorderStyle.FixedSingle,TabStop=false};
            rowDetailsText=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,BackColor=RaidTheme.Header,ForeColor=RaidTheme.Text,BorderStyle=BorderStyle.None,AccessibleName="App details"};
            backToRow=Btn("Back",false);
            backToRow.Click+=(o,e)=>{CloseRowDetails();processes.Focus();};
            rowDetails.Controls.AddRange(new Control[]{backToRow,rowDetailsText});
            results.Controls.Add(rowDetails);
            processes.DetailsRequested+=OpenRowDetails;
            processes.ViewScrolled+=CloseRowDetails;
            processes.SelectedIndexChanged+=(o,e)=>CloseRowDetails();
            processes.ColumnClick+=(o,e)=>CloseRowDetails();
            processes.ColumnWidthChanged+=(o,e)=>CloseRowDetails();
            results.SizeChanged+=(o,e)=>CloseRowDetails();
        }
        void OpenRowDetails(ListViewItem row)
        {
            var cell=row.SubItems[GroupedProcessView.DetailsColumn].Bounds;
            var area=processes.ClientRectangle;
            int pad=Math.Max(5,Font.Height/2);
            int width=Math.Min(area.Width,(int)(445*DeviceScaling));
            int preferredHeight=(int)(185*DeviceScaling);
            if(width<=2*pad || area.Height<=backToRow.Height+3*pad)return;
            int left=Math.Max(0,Math.Min(cell.Left-pad,area.Right-width));
            int buttonHeight=backToRow.GetPreferredSize(Size.Empty).Height;
            int buttonTop=cell.Top+(cell.Height-buttonHeight)/2;
            int downTop=Math.Max(0,buttonTop-pad);
            int upBottom=Math.Min(area.Bottom,buttonTop+buttonHeight+pad);
            int roomBelow=area.Bottom-downTop;
            bool opensDown=roomBelow>=preferredHeight || roomBelow>=upBottom;
            int height=Math.Min(preferredHeight,opensDown?roomBelow:upBottom);
            int top=opensDown?downTop:upBottom-height;
            rowDetails.SetBounds(processes.Left+left,processes.Top+top,width,height);
            var inside=rowDetails.ClientSize;
            int backY=opensDown?pad:inside.Height-pad-buttonHeight;
            backToRow.Location=new Point(Math.Max(pad,Math.Min(cell.Left-left,inside.Width-backToRow.Width-pad)),backY);
            int textY=opensDown?backY+buttonHeight+pad:pad;
            int textBottom=opensDown?inside.Height-pad:backY-pad;
            rowDetailsText.SetBounds(pad,textY,inside.Width-2*pad,textBottom-textY);
            rowDetailsText.Text=DescribeSessionRow(row);
            rowDetailsText.Select(0,0);
            rowDetails.Show();rowDetails.BringToFront();backToRow.Focus();
        }
        void CloseRowDetails()
        {
            if(rowDetails!=null && rowDetails.Visible)rowDetails.Hide();
        }
        protected override bool ProcessCmdKey(ref Message msg,Keys keyData)
        {
            if(keyData==Keys.OemQuestion && !search.Focused && search.CanFocus){search.Focus();search.SelectAll();return true;}
            if(keyData==Keys.Escape && rowDetails!=null && rowDetails.Visible) {
                CloseRowDetails();processes.Focus();return true;
            }
            return base.ProcessCmdKey(ref msg,keyData);
        }
        void ShowSelectedDetails()
        {
            var rows=processes.SelectedItems.Cast<ListViewItem>().ToList();
            selectedDetails.Text=rows.Count==0?"Select one or more rows in Session to see their paths and scan details.":
                String.Join(Environment.NewLine+Environment.NewLine,rows.Select(DescribeSessionRow));
        }
        string DescribeSessionRow(ListViewItem row)
        {
            var offline=row.Tag as AppEntry;
            var process=row.Tag as ProcessRow;
            var group=row.Tag as ProcessRow[];
            if(offline==null && process==null && group==null)return row.ToolTipText;
            string title=offline!=null?offline.Name:process!=null?process.Name:group[0].Name+" ("+group.Length+" processes)";
            var lines=new List<string>{title,"Rule: "+row.SubItems[1].Text,"Action: "+row.SubItems[2].Text};
            string path=row.SubItems[6].Text;
            var app=catalog.FirstOrDefault(a=>Paths.Equal(a.Image,path));
            var owner=(app==null?null:app.Family)??AppFamily.Known(path);
            if(owner!=null)lines.Add("Application: "+owner.Name);
            if(offline!=null)lines.Add("Source: "+offline.Source);
            else {
                lines.Add(process!=null?"PID: "+process.Id:"PIDs: "+String.Join(", ",group.Select(p=>p.Id)));
                lines.Add("Window: "+row.SubItems[4].Text);
                lines.Add("Reason: "+row.SubItems[5].Text);
            }
            lines.Add("Path: "+path);
            if(Program.Raiders && AppReopen.Eligible(path))lines.Add("Per-app after-raid choice: "+AppReopen.Label(settings.AfterMode(path)));
            var rule=settings.Resolve(path);
            if(rule.Origin==RuleOrigin.Folder)lines.Add("Allowed by folder: "+rule.Anchor);
            if((rule.Origin==RuleOrigin.SavedRoster || rule.Origin==RuleOrigin.SavedBench) && !Paths.Equal(rule.Anchor,path))
                lines.Add((rule.Benched?"Benched":"Rostered")+" by the saved rule for "+rule.Anchor);
            if(rule.Origin==RuleOrigin.DefaultBench || rule.Origin==RuleOrigin.DefaultRoster)
                lines.Add("Raid defaults roster Discord and World of Warcraft and bench other apps.");
            if(settings.BenchedByAside(path))lines.Add("Aside default: Benched");
            if(settings.FolderExceptions.Contains(path,Paths.Comparer))lines.Add("Flex override for this executable");
            var product=app==null || app.Source=="Saved path"?null:RaidSuggestion.Products.FirstOrDefault(p=>p.Matches(app));
            if(product!=null)lines.Add(app.BrowserInUse?"Browser suggestion: your Windows default or a browser running during the scan.":
                "Suggestion match: "+Path.GetFileName(path)+" matches the built-in entry for "+product.Name+".");
            return String.Join(Environment.NewLine,lines);
        }

        bool InPersonalView(string path,string rule)
        {
            switch(personalView) {
                case PersonalView.Rostered:return rule==Rostered;
                case PersonalView.Benched:return rule==Benched;
                case PersonalView.Flex:return rule==Flex;
                case PersonalView.Suggested:return path!=null && sessionSuggestions.Contains(path);
                default:return true;
            }
        }

        void FillSessionApps(bool retainSelection)
        {
            string term=search.Text.Trim();
            var runningPaths=new HashSet<string>(Paths.Comparer);
            var known=catalog.ToDictionary(a=>a.Image,Paths.Comparer);
            var superseded=new HashSet<string>(Paths.Comparer);
            foreach(string image in known.Keys.Concat(processRows.Select(p=>p.Image)).Distinct(Paths.Comparer)) {
                var rule=settings.Resolve(image);
                if((rule.Origin==RuleOrigin.SavedBench || rule.Origin==RuleOrigin.SavedRoster) &&
                    !Paths.Equal(rule.Anchor,image) && !File.Exists(rule.Anchor))superseded.Add(rule.Anchor);
                string anchor=settings.AfterRaidAnchor(image);
                if(anchor!=null && !Paths.Equal(anchor,image) && !File.Exists(anchor))superseded.Add(anchor);
            }
            foreach(string anchor in superseded)known.Remove(anchor);
            foreach(string path in settings.Allow.Concat(settings.Block).Concat(settings.FolderExceptions).Concat(settings.AfterRaid.Keys)) {
                if(!superseded.Contains(path) && !known.ContainsKey(path))known.Add(path,SavedApp(path));
            }
            var owners=new Dictionary<string,AppFamily>(Paths.Comparer);
            foreach(var app in known.Values) {
                var owner=app.Family??AppFamily.Known(app.Image);
                if(owner!=null)owners.Add(app.Image,owner);
            }
            var visible=new List<ProcessRow>();
            var offline=new List<ListViewItem>();
            int[] counts=new int[ViewNames.Length];
            var counted=new HashSet<string>(Paths.Comparer);
            foreach(var p in processRows) {
                if(p.Image!=null && runningPaths.Add(p.Image) && !known.ContainsKey(p.Image)) {
                    var owner=AppFamily.Known(p.Image);
                    if(owner!=null)owners.Add(p.Image,owner);
                }
                if(p.IsWindowsComponent)continue;
                string rule=PersonalRuleLabel(p.Blacklisted,p.WhitelistRule);
                if(String.IsNullOrEmpty(p.Image) || counted.Add(p.Image))CountView(counts,rule,p.Image);
                if(filter.SelectedIndex>=3 || (filter.SelectedIndex!=0 && (filter.SelectedIndex==1)!=p.Close) || !InPersonalView(p.Image,rule))continue;
                AppEntry app;AppFamily family;
                if(Contains(p.Name,term) || Contains(p.Image,term) || (p.Image!=null &&
                    ((known.TryGetValue(p.Image,out app) && Contains(app.Name,term)) || (owners.TryGetValue(p.Image,out family) && family.MatchesSearch(p.Image,term)))))visible.Add(p);
            }
            foreach(var app in known.Values) {
                if(runningPaths.Contains(app.Image) || Policy.WindowsImage(Path.GetFileNameWithoutExtension(app.Image),app.Image))continue;
                var resolved=settings.Resolve(app.Image);
                string match=resolved.Roster;
                string rule=PersonalRuleLabel(resolved.Benched,match);
                CountView(counts,rule,app.Image);
                AppFamily family;
                if(filter.SelectedIndex!=0 || !InPersonalView(app.Image,rule) || (!Contains(app.Name,term) && !Contains(app.Image,term) &&
                    (!owners.TryGetValue(app.Image,out family) || !family.MatchesSearch(app.Image,term))))continue;
                bool isFolder=app.Image.EndsWith(@"\*");
                bool reviewed=plan!=null || processRows.Count>0;
                string action=isFolder?"Folder rule":reviewed?"Not running":"Awaiting scan";
                var row=new ListViewItem(new[]{app.Name,rule,action,"","",app.Source,app.Image}){Name=app.Image,Tag=app};
                row.ToolTipText=String.Join(Environment.NewLine,new[]{app.Name,rule,action,app.Source,app.Image});
                if(match!=null && !Paths.Equal(match,app.Image))row.ToolTipText+=Environment.NewLine+"Allowed by "+match;
                if(settings.FolderExceptions.Contains(app.Image,Paths.Comparer))row.ToolTipText+=Environment.NewLine+"Flex override for this executable";
                TintRule(row);GroupedProcessView.AddDetailsLink(row);offline.Add(row);
            }
            ShowViewCounts(counts);
            if(filter.SelectedIndex<3){
                processes.Display(visible,retainSelection,offline,owners,term);
                int showing=visible.Select(p=>p.Image??p.Id.ToString()).Distinct(Paths.Comparer).Count()+offline.Count;
                rosterCount.Text="Showing "+showing+" of "+counts[0]+(counts[0]==1?" roster entry":" roster entries");
            }
        }

        void CountView(int[] counts,string rule,string path)
        {
            counts[(int)PersonalView.All]++;
            counts[(int)(rule==Rostered?PersonalView.Rostered:rule==Benched?PersonalView.Benched:PersonalView.Flex)]++;
            if(path!=null && sessionSuggestions.Contains(path))counts[(int)PersonalView.Suggested]++;
        }

        void ShowEmptyRoster()
        {
            emptyRoster.Visible=processes.Items.Count==0 && processes.Visible;
            if(!emptyRoster.Visible)return;
            string text;
            if(phase=="Scanning")text="Scanning apps...";
            else if(filter.SelectedIndex>=3)text=plan==null?"Scan & preview to check this report.":filter.SelectedIndex==3?"No startup changes in this preview.":"No inventory notes in this preview.";
            else if(search.Text.Trim().Length>0)text="No matching apps. Change the search or choose another view.";
            else if(filter.SelectedIndex!=0)text="No apps match this action in this view. Choose All actions to see the full list.";
            else if(personalView==PersonalView.Suggested)text=catalogScanned?"No pending roster suggestions.":"Scan & preview to find raid apps and browsers.";
            else if(personalView==PersonalView.All)text="Scan & preview to find running and installed apps, or add an executable under Manage rules.";
            else text="No "+ViewNames[(int)personalView]+" apps. Choose All apps to change an app's rule.";
            emptyRoster.Text=text;emptyRoster.BringToFront();
        }

        static AppEntry SavedApp(string path)
        {
            if(path.EndsWith(@"\*"))return new AppEntry{Image=path,Name=Path.GetFileName(path.Substring(0,path.Length-2)),Source="Saved folder"};
            return new AppEntry{Image=path,Name=Path.GetFileNameWithoutExtension(path),Source="Saved path"};
        }

        void RememberClearedApps(Settings updated)
        {
            var known=new HashSet<string>(catalog.Select(a=>a.Image),Paths.Comparer);
            foreach(string path in settings.Allow.Concat(settings.Block).Concat(settings.FolderExceptions)) {
                if(path.EndsWith(@"\*") || updated.MatchingRule(path)!=null || updated.IsBlacklisted(path) || !known.Add(path))continue;
                catalog.Add(SavedApp(path));
            }
        }

        IEnumerable<string> SelectedPersonalPaths()
        {
            return processes.SelectedProcesses().Where(p=>p.CanEditWhitelist).Select(p=>p.Image)
                .Concat(processes.SelectedMembers().Select(i=>i.Tag).OfType<AppEntry>().Select(a=>a.Image)).Distinct(Paths.Comparer);
        }
        bool CanSetPersonalRule(string path,PersonalRule action)
        {
            if(path.EndsWith(@"\*"))return action==PersonalRule.Clear;
            var rule=settings.Resolve(path);
            if(action==PersonalRule.Clear)return rule.Benched || rule.Roster!=null;
            if(action==PersonalRule.Whitelist)return rule.Roster==null || rule.Origin==RuleOrigin.DefaultRoster || (Program.Raiders && rule.Origin==RuleOrigin.Folder);
            return (!rule.Benched || rule.Origin==RuleOrigin.DefaultBench) &&
                !Policy.SystemImage(Path.GetFileNameWithoutExtension(path),path) && !Paths.Equal(path,Application.ExecutablePath);
        }
        void SetPersonalEditButtons(bool editable)
        {
            var paths=SelectedPersonalPaths().ToList();
            selectionLabel.Text=paths.Count>0?paths.Count+" selected":processes.SelectedItems.Count>0?"View only":"Select apps to edit";
            keep.Enabled=editable && paths.Any(p=>CanSetPersonalRule(p,PersonalRule.Whitelist));
            blockProcess.Enabled=editable && paths.Any(p=>CanSetPersonalRule(p,PersonalRule.Blacklist));
            removeProcess.Enabled=editable && paths.Any(p=>CanSetPersonalRule(p,PersonalRule.Clear));
            flexProcess.Enabled=removeProcess.Enabled;
            manageRules.Enabled=editable;
            afterRaidMenu.Enabled=editable && paths.Any(AppReopen.Eligible);
            benchAside.Checked=settings.BenchAside;benchAside.Enabled=editable;
            raidDefaults.Checked=settings.UseRaidDefaults;raidDefaults.Enabled=editable;
            clearAll.Enabled=editable && (settings.UseRaidDefaults || settings.BenchAside || settings.Allow.Count+settings.Block.Count+settings.FolderExceptions.Count>0);
        }
        void EditPersonalProcesses(PersonalRule action)
        {
            if(mode==WindowMode.ReadOnly || busy || session.Active || session.NeedsRecovery)return;
            try {
                var paths=SelectedPersonalPaths().Where(p=>CanSetPersonalRule(p,action)).ToList();
                if(paths.Count==0)return;
                var updated=settings.Copy();
                foreach(string path in paths) {
                    if(action==PersonalRule.Whitelist) updated.AllowExecutable(path);
                    else if(action==PersonalRule.Blacklist) updated.BlockExecutable(path);
                    else if(path.EndsWith(@"\*")) updated.Allow.RemoveAll(p=>Paths.Equal(p,path));
                    else updated.RemoveExecutable(path);
                }
                string target=action==PersonalRule.Whitelist?Rostered:action==PersonalRule.Blacklist?Benched:Flex;
                string feedback=paths.Count+(paths.Count==1?" rule changed":" rules changed")+" to "+target+".";
                SavePolicy(feedback+"   "+String.Join(", ",paths),updated,feedback);
            } catch(Exception ex){Error(ex);FillApps();}
        }

        void ClearAllRules()
        {
            if(mode==WindowMode.ReadOnly || busy || session.Active || session.NeedsRecovery)return;
            string effect=settings.CloseUnlisted?"Eligible Flex apps may close when you start a raid.":"Your current raid settings keep Flex apps open.";
            if(MessageBox.Show(this,"Clear all Rostered and Benched rules, including app defaults, folder rules and exceptions? Apps return to Flex.\n\n"+effect,
                "Clear all rules?",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            var updated=settings.Copy();updated.Allow.Clear();updated.Block.Clear();updated.FolderExceptions.Clear();updated.BenchAside=false;updated.UseRaidDefaults=false;
            SavePolicy("Cleared all app rules.",updated);
        }

        void ShowPickedApps(string[] files)
        {
            var selected=new HashSet<string>(files,Paths.Comparer);
            foreach(string path in selected) {
                if(!catalog.Any(a=>Paths.Equal(a.Image,path)))
                    catalog.Add(new AppEntry{Name=Path.GetFileNameWithoutExtension(path),Image=path,Source="Browse",Family=AppFamily.Detect(path)});
            }
            search.Clear();filter.SelectedIndex=0;SelectPersonalView(PersonalView.All);FillApps();Render();
            processes.RevealPaths(selected);
            processes.SelectedItems.Clear();
            foreach(ListViewItem item in processes.Items) {
                var app=item.Tag as AppEntry;
                var process=item.Tag as ProcessRow;
                var group=item.Tag as ProcessRow[];
                string path=app!=null?app.Image:process!=null?process.Image:group!=null?group[0].Image:null;
                if(path!=null && selected.Contains(path))item.Selected=true;
            }
            if(processes.SelectedItems.Count>0)processes.SelectedItems[0].EnsureVisible();
            processes.Focus();
        }
    }
}
