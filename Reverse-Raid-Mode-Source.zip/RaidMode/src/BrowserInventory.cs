using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace RaidMode
{
    internal static class BrowserInventory
    {
        [DllImport("shlwapi.dll",CharSet=CharSet.Unicode)]
        static extern int AssocQueryString(uint flags,uint kind,string association,string verb,StringBuilder value,ref uint size);

        internal static string DefaultBrowser()
        {
            // ASSOCF_IS_PROTOCOL and ASSOCSTR_EXECUTABLE resolve the current user's HTTPS handler.
            uint size=0;
            AssocQueryString(0x1000,2,"https","open",null,ref size);
            if(size<2 || size>32768)return null;
            var value=new StringBuilder((int)size);
            return AssocQueryString(0x1000,2,"https","open",value,ref size)==0?value.ToString():null;
        }
        internal static void ReadClients(RegistryKey root,HashSet<string> browsers)
        {
            using(var clients=root.OpenSubKey(@"Software\Clients\StartMenuInternet")) {
                if(clients==null)return;
                foreach(string name in clients.GetSubKeyNames())
                    using(var command=clients.OpenSubKey(name+@"\shell\open\command")) {
                        string raw=command==null?null:command.GetValue("") as string;
                        if(String.IsNullOrWhiteSpace(raw))continue;
                        var match=Regex.Match(Environment.ExpandEnvironmentVariables(raw),@"^\s*""?([A-Za-z]:\\[^""]+?\.exe)(?:""|\s|$)",RegexOptions.IgnoreCase);
                        if(match.Success)browsers.Add(match.Groups[1].Value);
                    }
            }
        }
        static readonly HashSet<string> PortableNames=new HashSet<string>(new[]{"firefox.exe","brave.exe","vivaldi.exe","msedge.exe",
            "opera.exe","librewolf.exe","waterfox.exe","floorp.exe","zen.exe","Arc.exe","chromium.exe"},Paths.Comparer);
        internal static bool InUse(string path,bool running,string defaultPath,HashSet<string> registered)
        {
            if(Paths.Equal(path,defaultPath))return true;
            if(!running)return false;
            if(registered.Contains(path) || PortableNames.Contains(Path.GetFileName(path)))return true;
            if(!Paths.Equal(Path.GetFileName(path),"chrome.exe"))return false;
            foreach(string folder in Path.GetDirectoryName(path).Split('\\'))
                if(Paths.Equal(folder,"Chrome") || Paths.Equal(folder,"Chromium") || Paths.Equal(folder,"Chrome-bin"))return true;
            try {
                string product=System.Diagnostics.FileVersionInfo.GetVersionInfo(path).ProductName;
                return Paths.Equal(product,"Google Chrome") || Paths.Equal(product,"Chromium");
            } catch(IOException) {} catch(UnauthorizedAccessException) {} catch(System.ComponentModel.Win32Exception) {}
            return false;
        }
    }
}
