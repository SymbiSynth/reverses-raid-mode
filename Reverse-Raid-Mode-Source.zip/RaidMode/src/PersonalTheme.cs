using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace RaidMode
{
    internal static class RaidTheme
    {
        internal static readonly Color Page=Tone(17,18,25,SystemColors.Window), Bar=Tone(23,24,33,SystemColors.Control),
            Surface=Tone(25,27,37,SystemColors.Window), Header=Tone(32,35,46,SystemColors.Control),
            Edge=Tone(48,51,68,SystemColors.WindowFrame), Text=Tone(242,239,250,SystemColors.WindowText),
            Soft=Tone(192,194,214,SystemColors.WindowText), Dim=Tone(155,157,179,SystemColors.GrayText),
            Accent=Tone(195,180,255,SystemColors.Highlight), OnAccent=Tone(30,24,48,SystemColors.HighlightText),
            Violet=Tone(45,38,66,SystemColors.Control), VioletEdge=Tone(87,73,120,SystemColors.WindowFrame),
            Green=Tone(161,229,213,SystemColors.WindowText), GreenBg=Tone(34,59,57,SystemColors.Window),
            Rose=Tone(238,195,202,SystemColors.WindowText), BenchBg=Tone(48,43,54,SystemColors.Window),
            Blue=Tone(183,202,233,SystemColors.WindowText), FlexBg=Tone(36,45,62,SystemColors.Window);
        static Color Tone(int r,int g,int b,Color system){return SystemInformation.HighContrast?system:Color.FromArgb(r,g,b);}
        internal static void ButtonStyle(Button button,bool primary)
        {
            button.MinimumSize=new Size(44,29);button.Padding=new Padding(6,0,6,0);button.Margin=new Padding(0,2,5,2);
            button.BackColor=primary?Accent:Surface;button.ForeColor=primary?OnAccent:Text;
            button.FlatAppearance.BorderColor=primary?Accent:Edge;
        }
        internal static void Box(Graphics g,Rectangle rect,int radius,Color fill,Color stroke)
        {
            if(rect.Width<2 || rect.Height<2)return;
            var bounds=new Rectangle(rect.X,rect.Y,rect.Width-1,rect.Height-1);
            int d=Math.Min(Math.Min(bounds.Width,bounds.Height),radius*2);
            using(var brush=new SolidBrush(fill))
            using(var pen=new Pen(stroke))
            using(var path=new GraphicsPath()){
                if(d<2)path.AddRectangle(bounds);
                else {
                    path.AddArc(bounds.X,bounds.Y,d,d,180,90);path.AddArc(bounds.Right-d,bounds.Y,d,d,270,90);
                    path.AddArc(bounds.Right-d,bounds.Bottom-d,d,d,0,90);path.AddArc(bounds.X,bounds.Bottom-d,d,d,90,90);path.CloseFigure();
                }
                var old=g.SmoothingMode;g.SmoothingMode=SmoothingMode.AntiAlias;
                g.FillPath(brush,path);g.DrawPath(pen,path);g.SmoothingMode=old;
            }
        }
        internal static void Write(Graphics g,string text,Font font,Color color,Rectangle rect,TextFormatFlags align)
        {
            TextRenderer.DrawText(g,text,font,rect,color,TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding|
                TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|align);
        }
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr window,int attribute,ref int value,int size);
        [DllImport("uxtheme.dll",CharSet=CharSet.Unicode)] static extern int SetWindowTheme(IntPtr window,string subApp,string subId);
        internal static void DarkCaption(Form window)
        {
            if(SystemInformation.HighContrast)return;
            int on=1;DwmSetWindowAttribute(window.Handle,20,ref on,4);
        }
        internal static void DarkNative(Control control)
        {
            if(!SystemInformation.HighContrast)control.HandleCreated+=(o,e)=>SetWindowTheme(control.Handle,"DarkMode_Explorer",null);
        }
        internal static void Menu(ContextMenuStrip menu)
        {
            menu.BackColor=Surface;menu.ForeColor=Text;menu.Renderer=new ToolStripProfessionalRenderer(new MenuColors());
        }
        internal static void TableBand(Control band,bool top,bool bottom)
        {
            band.Paint+=(o,e)=>{
                var g=e.Graphics;int w=band.ClientSize.Width-1,h=band.ClientSize.Height-1;
                if(w<12 || h<8)return;
                using(var p=new Pen(Edge)){
                    g.DrawLine(p,0,top?6:0,0,bottom?h-6:h);g.DrawLine(p,w,top?6:0,w,bottom?h-6:h);
                    g.DrawLine(p,top?6:0,0,top?w-6:w,0);
                    if(top){g.DrawArc(p,0,0,12,12,180,90);g.DrawArc(p,w-12,0,12,12,270,90);}
                    if(bottom){g.DrawArc(p,0,h-12,12,12,90,90);g.DrawArc(p,w-12,h-12,12,12,0,90);g.DrawLine(p,6,h,w-6,h);}
                }
            };
        }
        sealed class MenuColors : ProfessionalColorTable
        {
            public override Color ToolStripDropDownBackground{get{return Surface;}}
            public override Color ImageMarginGradientBegin{get{return Surface;}}
            public override Color ImageMarginGradientMiddle{get{return Surface;}}
            public override Color ImageMarginGradientEnd{get{return Surface;}}
            public override Color MenuItemSelected{get{return Violet;}}
            public override Color MenuItemBorder{get{return VioletEdge;}}
            public override Color MenuBorder{get{return Edge;}}
        }
        internal static void LogGrid(ListView grid)
        {
            grid.OwnerDraw=true;DarkNative(grid);
            grid.DrawColumnHeader+=(o,e)=>{
                using(var brush=new SolidBrush(Header))e.Graphics.FillRectangle(brush,e.Bounds);
                Write(e.Graphics,e.Header.Text,grid.Font,Soft,Rectangle.Inflate(e.Bounds,-5,0),TextFormatFlags.Left);
            };
            grid.DrawSubItem+=(o,e)=>{
                using(var brush=new SolidBrush(e.Item.Selected?Violet:Surface))e.Graphics.FillRectangle(brush,e.Bounds);
                Write(e.Graphics,e.SubItem.Text,grid.Font,Text,Rectangle.Inflate(e.Bounds,-5,0),TextFormatFlags.Left);
            };
        }
    }

    internal sealed class RaidComboBox : ComboBox
    {
        internal RaidComboBox(){FlatStyle=FlatStyle.Flat;BackColor=RaidTheme.Surface;ForeColor=RaidTheme.Text;}
        void DrawClosed(Graphics g)
        {
            RaidTheme.Box(g,ClientRectangle,4,RaidTheme.Surface,Focused?RaidTheme.VioletEdge:RaidTheme.Edge);
            var body=Rectangle.Inflate(ClientRectangle,-7,0);body.Width=Math.Max(0,body.Width-Font.Height);
            RaidTheme.Write(g,Text,Font,Enabled?RaidTheme.Text:RaidTheme.Dim,body,TextFormatFlags.Left);
            int x=Width-Font.Height,y=Height/2;
            using(var pen=new Pen(RaidTheme.Soft))g.DrawLines(pen,new[]{new Point(x-3,y-2),new Point(x,y+1),new Point(x+3,y-2)});
        }
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if(m.Msg==0xf && IsHandleCreated){using(var g=Graphics.FromHwnd(Handle))DrawClosed(g);}
            else if((m.Msg==0x317 || m.Msg==0x318) && m.WParam!=IntPtr.Zero){using(var g=Graphics.FromHdc(m.WParam))DrawClosed(g);}
        }
    }

    internal sealed class RaidButton : Button
    {
        internal bool Navigation;
        internal string Glyph="";
        static readonly Font glyphFont=new Font("Segoe MDL2 Assets",8.5f);
        bool current,over;
        public override Size GetPreferredSize(Size proposedSize){
            var size=base.GetPreferredSize(proposedSize);
            if(!String.IsNullOrEmpty(Glyph))size.Width+=Font.Height+2;
            return size;
        }
        internal void SelectTab(bool selected){current=selected;Invalidate();}
        protected override void OnMouseEnter(EventArgs e){base.OnMouseEnter(e);over=true;Invalidate();}
        protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);over=false;Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {
            Color surface=Parent==null?RaidTheme.Surface:Parent.BackColor;
            e.Graphics.Clear(surface);
            Color fill=BackColor,ink=ForeColor,stroke=FlatAppearance.BorderColor;
            if(Navigation){fill=surface;stroke=surface;ink=current?RaidTheme.Accent:RaidTheme.Soft;}
            if(!Enabled){fill=surface;stroke=RaidTheme.Edge;ink=RaidTheme.Dim;}
            else if(over){fill=BackColor==RaidTheme.Accent?ControlPaint.Light(BackColor):RaidTheme.Violet;stroke=RaidTheme.VioletEdge;}
            RaidTheme.Box(e.Graphics,ClientRectangle,Math.Max(3,Font.Height/4),fill,stroke);
            string caption=Text.Replace("&&","&");
            if(Glyph.Length==0)RaidTheme.Write(e.Graphics,caption,Font,ink,ClientRectangle,TextFormatFlags.HorizontalCenter);
            else{
                int gap=Math.Max(4,Font.Height/3),icon=Font.Height;
                int words=TextRenderer.MeasureText(caption,Font,Size.Empty,TextFormatFlags.NoPadding).Width;
                int x=Math.Max(2,(Width-words-icon-gap)/2);
                RaidTheme.Write(e.Graphics,Glyph,glyphFont,ink,new Rectangle(x,0,icon,Height),TextFormatFlags.HorizontalCenter);
                RaidTheme.Write(e.Graphics,caption,Font,ink,new Rectangle(x+icon+gap,0,Math.Max(1,Width-x-icon-gap-2),Height),TextFormatFlags.Left);
            }
            if(Navigation && current)using(var pen=new Pen(RaidTheme.Accent,2))e.Graphics.DrawLine(pen,4,Height-2,Width-5,Height-2);
            if(Focused && ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,Rectangle.Inflate(ClientRectangle,-4,-4),ink,fill);
        }
    }

    internal sealed class RaidTile : Control
    {
        readonly bool brand;
        internal RaidTile(bool brandMark,int size){brand=brandMark;Size=new Size(size,size);DoubleBuffered=true;Margin=Padding.Empty;}
        protected override void OnPaint(PaintEventArgs e){
            e.Graphics.Clear(Parent.BackColor);DrawMark(e.Graphics,Width,Height,brand);
        }
        internal static void DrawMark(Graphics g,int width,int height,bool brand){
            var state=g.Save();
            RaidTheme.Box(g,new Rectangle(0,0,width,height),Math.Max(4,width/4),RaidTheme.Accent,RaidTheme.Accent);
            g.SmoothingMode=SmoothingMode.AntiAlias;
            if(brand){
                // Match the 96-unit artwork used for the Raiders/Personal executable icon.
                g.ScaleTransform(width/96f,height/96f);
                using(var mark=new GraphicsPath())
                using(var ink=new SolidBrush(RaidTheme.OnAccent)){
                    mark.AddLines(new[]{new PointF(33,17),new PointF(15,32),new PointF(33,47),new PointF(33,36.6f),
                        new PointF(41,36.6f),new PointF(41,79),new PointF(50.5f,79),new PointF(50.5f,36.6f),new PointF(57,36.6f)});
                    mark.AddBezier(57,36.6f,64,36.6f,68,40.1f,68,46);
                    mark.AddBezier(68,46,68,51.9f,64,55.3f,57,55.3f);
                    mark.AddLines(new[]{new PointF(57,55.3f),new PointF(53.3f,55.3f),new PointF(53.3f,62.6f),
                        new PointF(69.5f,79),new PointF(81,79),new PointF(64.7f,62.5f)});
                    mark.AddBezier(64.7f,62.5f,73.1f,60.1f,77.5f,54,77.5f,45.8f);
                    mark.AddBezier(77.5f,45.8f,77.5f,34,69,27.4f,57,27.4f);
                    mark.AddLine(57,27.4f,33,27.4f);mark.CloseFigure();
                    g.FillPath(ink,mark);
                }
            }else{
                g.ScaleTransform(width/32f,height/32f);
                using(var pen=new Pen(RaidTheme.OnAccent,1.8f)){
                    g.DrawEllipse(pen,8,9,15,15);g.DrawEllipse(pen,12,13,7,7);g.DrawLine(pen,15,17,24,8);
                    g.DrawLine(pen,21,9,24,8);g.DrawLine(pen,24,8,23,12);
                }
            }
            g.Restore(state);
        }
    }

    internal sealed class RaidSurface : Panel
    {
        internal Color Fill=RaidTheme.Surface,Stroke=RaidTheme.Edge;
        internal int Radius=8;
        internal RaidSurface(){DoubleBuffered=true;ResizeRedraw=true;Margin=Padding.Empty;Dock=DockStyle.Fill;}
        protected override void OnPaintBackground(PaintEventArgs e){
            e.Graphics.Clear(Parent==null?RaidTheme.Page:Parent.BackColor);
            RaidTheme.Box(e.Graphics,ClientRectangle,Radius,Fill,Stroke);
        }
    }

    internal sealed partial class MainWindow
    {
        readonly Label previewTitle=LabelOf("",10,true),rosterCount=LabelOf("",8,false);
        Label setupLabel;
        static Label SizedLabel(string text,int width,int height,float size,bool bold,Color fore)
        {
            var label=LabelOf(text,size,bold);label.Dock=DockStyle.None;label.Size=new Size(width,height);label.ForeColor=fore;
            label.TextAlign=ContentAlignment.MiddleCenter;return label;
        }
        void BuildPersonalHeader(TableLayoutPanel frame)
        {
            var bar=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty,Padding=new Padding(26,0,24,0),BackColor=RaidTheme.Bar};
            var strip=Bar();strip.Padding=new Padding(0,7,0,0);strip.BackColor=RaidTheme.Bar;
            var mark=new RaidTile(true,28);
            var brand=LabelOf("Reverse's Raid Mode",10,true);brand.Dock=DockStyle.None;brand.AutoSize=true;
            brand.ForeColor=RaidTheme.Text;brand.Margin=new Padding(8,6,6,0);
            var edition=SizedLabel(Program.EditionBadge,48,21,8,false,RaidTheme.Soft);edition.BackColor=RaidTheme.Header;edition.Margin=new Padding(0,5,18,0);
            strip.Controls.AddRange(new Control[]{mark,brand,edition});
            foreach(string name in new[]{"Session","Details","Activity"}){
                var b=(RaidButton)Btn(name,false);b.Navigation=true;b.Padding=new Padding(8,0,8,0);
                b.Glyph=new[]{"\uE8A1","\uE946","\uE9D9"}[tabs.Count];
                b.MinimumSize=new Size(63,35);b.Margin=new Padding(0,0,3,0);
                int page=tabs.Count;b.Click+=(o,e)=>ShowPage(page);tabs.Add(b);strip.Controls.Add(b);
            }
            badge.Dock=DockStyle.Fill;badge.ForeColor=RaidTheme.Soft;badge.TextAlign=ContentAlignment.MiddleCenter;badge.BackColor=Color.Transparent;
            badge.Font=new Font("Segoe UI",8,FontStyle.Bold);
            var pill=new RaidSurface{Dock=DockStyle.None,Anchor=AnchorStyles.Right,Fill=RaidTheme.Bar,Stroke=RaidTheme.Edge,Radius=12,Width=125,Height=23};
            pill.Controls.Add(badge);
            var right=new TableLayoutPanel{Dock=DockStyle.Right,ColumnCount=1,RowCount=1,Width=126,Margin=Padding.Empty,BackColor=RaidTheme.Bar};
            right.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));right.Controls.Add(pill,0,0);
            bar.Controls.Add(strip);bar.Controls.Add(right);frame.Controls.Add(bar,0,0);
            HandleCreated+=(o,e)=>RaidTheme.DarkCaption(this);
        }
        void BuildPersonalFooter(TableLayoutPanel frame)
        {
            var band=new Panel{Dock=DockStyle.Fill,BackColor=RaidTheme.Page,Margin=Padding.Empty,Padding=new Padding(26,0,26,0)};
            footer.BackColor=RaidTheme.Page;footer.ForeColor=RaidTheme.Soft;footer.Padding=Padding.Empty;
            var duration=LabelOf("Session limit   "+settings.Minutes+" min",8,true);duration.Width=144;duration.Dock=DockStyle.Right;
            duration.TextAlign=ContentAlignment.MiddleRight;duration.ForeColor=RaidTheme.Soft;
            band.Controls.Add(footer);band.Controls.Add(duration);frame.Controls.Add(band,0,3);
        }
        void BuildPreviewBanner(FlowLayoutPanel actions)
        {
            home.Padding=new Padding(26,11,26,0);
            setupLabel=LabelOf("SESSION SETUP",8,true);setupLabel.ForeColor=RaidTheme.Accent;
            AddRow(home,setupLabel,17);status.Font=new Font("Segoe UI",26,FontStyle.Bold);AddRow(home,status,43);AddRow(home,summary,28);
            var banner=new RaidSurface{Fill=RaidTheme.Violet,Stroke=RaidTheme.VioletEdge,BackColor=RaidTheme.Violet,
                Padding=new Padding(10,5,9,5),Margin=new Padding(0,0,0,10)};
            var icon=new RaidTile(false,33){Anchor=AnchorStyles.Left};
            var tile=new TableLayoutPanel{ColumnCount=1,RowCount=1,Dock=DockStyle.Left,Width=44,BackColor=RaidTheme.Violet};
            tile.Controls.Add(icon,0,0);
            var copy=new TableLayoutPanel{ColumnCount=1,RowCount=2,Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=RaidTheme.Violet};
            copy.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));copy.RowStyles.Add(new RowStyle(SizeType.Percent,50));copy.RowStyles.Add(new RowStyle(SizeType.Percent,50));
            previewTitle.TextAlign=ContentAlignment.BottomLeft;sub.TextAlign=ContentAlignment.TopLeft;sub.ForeColor=RaidTheme.Soft;
            sub.Font=new Font("Segoe UI",8.5f);copy.Controls.Add(previewTitle,0,0);copy.Controls.Add(sub,0,1);
            sub.SizeChanged+=(o,e)=>{if(plan!=null)SetPreviewCounts();};
            actions.Dock=DockStyle.None;actions.AutoSize=true;actions.AutoSizeMode=AutoSizeMode.GrowAndShrink;actions.BackColor=RaidTheme.Violet;
            var actionSlot=new TableLayoutPanel{Dock=DockStyle.Right,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=1,RowCount=1,Margin=Padding.Empty};
            actions.Anchor=AnchorStyles.Right;actionSlot.Controls.Add(actions,0,0);actionSlot.BackColor=RaidTheme.Violet;
            ((RaidButton)scan).Glyph="\uE7B3";((RaidButton)start).Glyph="\uE72E";((RaidButton)end).Glyph="\uE71A";
            banner.Controls.Add(copy);banner.Controls.Add(actionSlot);banner.Controls.Add(tile);AddRow(home,banner,63);
        }
        void BuildRosterCount()
        {
            rosterCount.BackColor=RaidTheme.Surface;rosterCount.ForeColor=RaidTheme.Soft;
            rosterCount.Padding=new Padding(12,0,0,0);AddRow(home,rosterCount,25);
            RaidTheme.TableBand(rosterCount,false,true);
        }
        Panel BuildRosterSearch()
        {
            var slot=new Panel{Dock=DockStyle.Fill,BackColor=RaidTheme.Surface,Margin=new Padding(5,4,1,4)};
            var box=new RaidSurface{Dock=DockStyle.Right,Width=180,Fill=RaidTheme.Page,BackColor=RaidTheme.Page,Radius=5,Padding=new Padding(5,1,4,1)};
            var glass=SizedLabel("\uE721",17,24,8,false,RaidTheme.Soft);glass.Dock=DockStyle.Left;glass.Font=new Font("Segoe MDL2 Assets",8);
            var key=SizedLabel("/",16,22,8,false,RaidTheme.Dim);key.Dock=DockStyle.Right;
            search.BorderStyle=BorderStyle.None;search.BackColor=RaidTheme.Page;search.ForeColor=RaidTheme.Text;
            search.AccessibleName="Search apps by name or path";search.Margin=Padding.Empty;search.Anchor=AnchorStyles.Left|AnchorStyles.Right;
            var input=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=1,Margin=Padding.Empty,BackColor=RaidTheme.Page};
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));input.RowStyles.Add(new RowStyle(SizeType.Percent,100));input.Controls.Add(search,0,0);
            var hint=LabelOf("Search apps",8.5f,false);hint.BackColor=RaidTheme.Page;hint.ForeColor=RaidTheme.Soft;
            var hostField=new Panel{Dock=DockStyle.Fill,BackColor=RaidTheme.Page,Margin=Padding.Empty};
            hostField.Controls.Add(input);hostField.Controls.Add(hint);hint.BringToFront();
            Action sync=()=>hint.Visible=search.Text.Length==0&&!search.Focused;
            search.GotFocus+=(o,e)=>sync();search.LostFocus+=(o,e)=>sync();search.TextChanged+=(o,e)=>{sync();FillPlan(true);};
            hint.Click+=(o,e)=>search.Focus();glass.Click+=(o,e)=>search.Focus();key.Click+=(o,e)=>search.Focus();
            box.Controls.Add(hostField);box.Controls.Add(key);box.Controls.Add(glass);slot.Controls.Add(box);
            slot.Layout+=(o,e)=>box.Width=Math.Min(slot.ClientSize.Width,(int)(185*DeviceScaling));
            return slot;
        }
        void RenderPersonalChrome(bool live,bool active)
        {
            badge.Text="\u25cb  "+(mode==WindowMode.Normal?phase:mode==WindowMode.ReadOnly?"Read-only preview":"First-launch preview");
            summary.ForeColor=RaidTheme.Soft;setupLabel.Text=live?"RAID SESSION":"SESSION SETUP";
            previewTitle.Text=live?"Session controls":session.NeedsRecovery?"Recover the previous session":plan!=null?"Preview ready":"Preview before starting";
            if(!live && plan==null && processRows.Count==0)sub.Text=busy?"Checking running apps and startup entries...":"Scan to see which apps would close. Scanning keeps them open.";
            if(plan!=null)SetPreviewCounts();
            start.BackColor=start.Enabled?RaidTheme.VioletEdge:RaidTheme.Violet;start.ForeColor=RaidTheme.Text;start.FlatAppearance.BorderColor=RaidTheme.VioletEdge;
            ((RaidButton)start).Glyph=start.Enabled?"\uE768":"\uE72E";
            if(!active)footer.Text="Rostered stay open     |     Benched close if eligible     |     "+(settings.CloseUnlisted?"Eligible Flex apps may close":"Flex stay open");
            home.RowStyles[7].Height=live?0:25*DeviceScaling;rosterCount.Visible=!live;
        }
        void SetPreviewCounts()
        {
            int close=0,keep=0;
            foreach(var row in plan.Rows)if(row.Close)close++;else if(!row.IsWindowsComponent)keep++;
            string counts=close+" close   /   "+keep+" kept   /   "+plan.Sources.Count+" startup   /   "+plan.Notes.Count+" notes";
            sub.Text=sub.Width>580*DeviceScaling?"Running processes   "+counts:counts;
            ruleTips.SetToolTip(sub,"Running processes: "+close+" to close and "+keep+" kept. Startup changes: "+plan.Sources.Count+". Inventory notes: "+plan.Notes.Count+".");
        }
    }
}
