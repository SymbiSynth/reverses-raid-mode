using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace RaidMode
{
    internal sealed class StartRaidDialog : Form
    {
        internal SessionReturn? Choice {get;private set;}

        internal StartRaidDialog(Plan plan,string scope,int minutes)
        {
            Text="Start raid session?";
            StartPosition=FormStartPosition.CenterParent;
            ShowInTaskbar=false;ShowIcon=false;MinimizeBox=false;MaximizeBox=false;
            AutoScaleMode=AutoScaleMode.Dpi;AutoScaleDimensions=new SizeF(96,96);
            Font=SystemFonts.MessageBoxFont;BackColor=RaidTheme.Page;ForeColor=RaidTheme.Text;
            ClientSize=new Size(580,535);MinimumSize=new Size(460,500);

            var layout=new TableLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(18),ColumnCount=1,RowCount=10};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            for(int row=0;row<layout.RowCount;row++)
                layout.RowStyles.Add(row==2?new RowStyle(SizeType.Percent,100):new RowStyle(SizeType.AutoSize));
            Controls.Add(layout);

            var targets=plan.Targets.GroupBy(p=>{
                var family=AppFamily.Known(p.Image);
                return family==null?p.Name:family.Name;
            },Paths.Comparer).OrderBy(g=>g.Key,Paths.Comparer).ToList();
            var title=Caption("Save your work before starting",true);
            layout.Controls.Add(title,0,0);
            string count=targets.Count==1?"1 app":targets.Count+" apps";
            layout.Controls.Add(Caption(count+" to close  /  "+plan.Sources.Count+" startup entries to pause  /  "+minutes+" min limit",false),0,1);
            var list=new ListBox{Name="closeList",AccessibleName="Apps in the close list",Dock=DockStyle.Fill,
                IntegralHeight=false,HorizontalScrollbar=true,BackColor=RaidTheme.Surface,ForeColor=RaidTheme.Text,BorderStyle=BorderStyle.FixedSingle};
            foreach(var app in targets)list.Items.Add(app.Key+(app.Count()>1?" ("+app.Count()+" processes)":""));
            if(targets.Count==0)list.Items.Add("No running apps are scheduled to close.");
            RaidTheme.DarkNative(list);layout.Controls.Add(list,0,2);
            layout.Controls.Add(Caption(scope,false),0,3);
            layout.Controls.Add(Caption("What should happen after this raid?",true),0,4);
            layout.Controls.Add(Caption("Resume and Leave closed apply to every app Raid Mode closes now. Resume brings back what each app saved. To set per-app choices, right-click an app in App Roster and choose After raid. In per-app mode, other apps stay closed.",false),0,5);

            var resume=MakeButton("resumeApps","Start session & resume my apps afterward",true);
            var manual=MakeButton("leaveClosed","Start session & leave my apps closed",false);
            var perApp=MakeButton("usePerApp","Start session & use my per-app choices",false);
            resume.AccessibleDescription="Reopen the apps after this raid and request their saved session.";
            manual.AccessibleDescription="Keep the apps closed after this raid. You can open them yourself.";
            perApp.AccessibleDescription="Follow the saved After raid choice for each app.";
            resume.Click+=(o,e)=>StartWith(SessionReturn.Resume);
            manual.Click+=(o,e)=>StartWith(SessionReturn.LeaveClosed);
            perApp.Click+=(o,e)=>StartWith(SessionReturn.PerApp);
            layout.Controls.Add(resume,0,6);layout.Controls.Add(manual,0,7);layout.Controls.Add(perApp,0,8);
            var cancel=MakeButton("cancel","Cancel",false);
            cancel.Dock=DockStyle.None;cancel.Anchor=AnchorStyles.Right;cancel.DialogResult=DialogResult.Cancel;
            layout.Controls.Add(cancel,0,9);
            CancelButton=cancel;
            resume.TabIndex=0;manual.TabIndex=1;perApp.TabIndex=2;cancel.TabIndex=3;list.TabIndex=4;
            ActiveControl=resume;
            Load+=(o,e)=>{
                var area=Screen.FromControl(Owner??this).WorkingArea.Size;
                MinimumSize=new Size(Math.Min(MinimumSize.Width,area.Width),Math.Min(MinimumSize.Height,area.Height));
                Size=new Size(Math.Min(Width,area.Width),Math.Min(Height,area.Height));
            };
            Shown+=(o,e)=>{RaidTheme.DarkCaption(this);resume.Focus();};
        }

        static Label Caption(string text,bool heading)
        {
            var label=new Label{Text=text,AutoSize=true,Dock=DockStyle.Fill,UseMnemonic=false,
                ForeColor=heading?RaidTheme.Text:RaidTheme.Soft,Margin=new Padding(0,5,0,6)};
            if(heading)label.Font=new Font(SystemFonts.MessageBoxFont.FontFamily,13,FontStyle.Bold);
            return label;
        }

        void StartWith(SessionReturn choice)
        {
            Choice=choice;
            DialogResult=DialogResult.OK;
        }

        static Button MakeButton(string name,string text,bool primary)
        {
            var button=new Button{Name=name,Text=text,UseMnemonic=false,AutoSize=true,Dock=DockStyle.Fill,
                FlatStyle=FlatStyle.Flat,UseVisualStyleBackColor=false};
            RaidTheme.ButtonStyle(button,primary);
            button.Padding=new Padding(10,5,10,5);button.Margin=new Padding(0,4,0,2);
            return button;
        }
    }
}
