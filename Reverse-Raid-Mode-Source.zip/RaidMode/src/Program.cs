using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle(RaidMode.Program.DisplayName)]
[assembly: AssemblyDescription("Local raid session controller for Windows")]
[assembly: AssemblyProduct(RaidMode.Program.DisplayName)]
[assembly: AssemblyVersion("0.15.0.0")]
[assembly: AssemblyFileVersion("0.15.0.1")]

namespace RaidMode
{
    static class Program
    {
#if RAIDERS
        internal static readonly bool Raiders = true;
        internal const string DisplayName = "Reverse's Raid Mode Raiders";
        internal const string EditionBadge = "Raiders";
        internal const string ProfileFolderName = "RaidModeRaiders";
#elif PERSONAL
        internal static readonly bool Raiders = false;
        internal const string DisplayName = "Reverse's Raid Mode Personal";
        internal const string EditionBadge = "Personal";
        internal const string ProfileFolderName = "RaidModePersonal";
#else
        internal static readonly bool Raiders = false;
        internal const string DisplayName = "Reverse's Raid Mode";
        internal const string EditionBadge = "";
        internal const string ProfileFolderName = "RaidModeDesktop";
#endif
#if PERSONAL
        internal static readonly bool Personal = true;
#else
        internal static readonly bool Personal = false;
#endif
        [DllImport("user32")] static extern bool SetProcessDPIAware();
        [STAThread] static void Main(string[] args)
        {
            SetProcessDPIAware();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try {
                if(Array.Exists(args,a=>String.Equals(a,"--first-launch-preview",StringComparison.OrdinalIgnoreCase))) {
                    using(var preview=MainWindow.CreateFirstLaunchPreview()) Application.Run(preview);
                    return;
                }
                string file=Path.Combine(Paths.Data,"whitelist.json");
                if(Array.Exists(args,a=>String.Equals(a,"--preview",StringComparison.OrdinalIgnoreCase))) {
                    using(var preview=new MainWindow(Settings.Open(file),Paths.Data,null,WindowMode.ReadOnly)) Application.Run(preview);
                    return;
                }
                Directory.CreateDirectory(Paths.Data);
                using (var appLock=new FileStream(Path.Combine(Paths.Data,"app.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)) {
                    bool firstRun=!File.Exists(file);
                    var s=Settings.Open(file,true);
                    if (firstRun) Store.Write(file,s);
                    bool suggestions=Array.Exists(args,a=>String.Equals(a,"--suggestions",StringComparison.OrdinalIgnoreCase));
                    using (var form=new MainWindow(s,Paths.Data,null,firstRun:firstRun,showSuggestions:suggestions)) Application.Run(form);
                }
            } catch(IOException ex) {MessageBox.Show("Could not open the local profile. If "+DisplayName+" is already open, use that window.\n\n"+ex.Message,DisplayName,MessageBoxButtons.OK,MessageBoxIcon.Information);}
            catch(Exception ex) {MessageBox.Show(ex.Message,DisplayName+" could not open",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
        }
    }
}
