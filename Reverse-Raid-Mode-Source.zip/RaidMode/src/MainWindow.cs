using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RaidMode
{
    internal enum WindowMode { Normal, ReadOnly, FirstLaunchPreview }

    internal sealed partial class MainWindow : Form
    {
        static readonly Color Paper=Color.FromArgb(247,248,246), Ink=Color.FromArgb(26,40,37), Pine=Color.FromArgb(18,83,69), Mint=Color.FromArgb(175,234,202), Muted=Color.FromArgb(80,96,89), Line=Color.FromArgb(216,224,219);
        static readonly Color RaidOrange=Color.FromArgb(158,62,23);
        readonly Settings settings;
        readonly WindowMode mode;
        readonly Session session;
        readonly string root;
        readonly Panel host=new Panel();
        readonly TableLayoutPanel home=Page(), whitelist=Page(), activity=Page();
        readonly Label badge=LabelOf("",10,true), status=LabelOf("",21,true), summary=LabelOf("",10,false);
        readonly Label sub=LabelOf("",10,false), footer=LabelOf("",9,false), policyInfo=LabelOf("",9,false);
        readonly GroupedProcessView processes=Grid<GroupedProcessView>();
        readonly ListView apps=Grid<SortableListView>(), events=Grid<SortableListView>(), sessionEvents=Grid<SortableListView>();
        readonly Queue<ListViewItem> eventHistory=new Queue<ListViewItem>(), sessionHistory=new Queue<ListViewItem>();
        readonly ComboBox filter=SelectBox("All processes","Will close","Kept","Startup changes","Inventory notes");
        const int SuggestedApps=3;
        readonly ComboBox libraryFilter=SelectBox("All software","Whitelist only","Discovered only","Suggested apps");
        readonly TextBox search=new TextBox();
        readonly CheckBox full=new CheckBox(), pause=new CheckBox();
        readonly Button scan=Btn("Scan && preview",true), start=Btn("Start raid...",true), end=Btn("End session",false), launch=Btn("Launch once...",false);
        readonly Button suggestions=Btn("Apply suggestions",false);
        readonly Button keep=Btn("Add to whitelist",false), removeProcess=Btn("Remove from whitelist",false);
        readonly Button find=Btn("Scan software",false), browse=Btn("Browse .exe...",false);
        readonly Button addApp=Btn("Add to whitelist",false), removeRule=Btn("Remove from whitelist",false);
        readonly Button applySuggestions=Btn("Apply suggestions",true);
        readonly HashSet<string> sessionSuggestions=new HashSet<string>(Paths.Comparer);
        readonly HashSet<string> visibleSuggestions=new HashSet<string>(Paths.Comparer);
        readonly Button running=Btn("All processes",false);
        readonly Button folder=Btn("Allow folder...",false);
        Button previewSetup;
        readonly FlowLayoutPanel review=Bar();
        readonly List<Button> tabs=new List<Button>();
        readonly System.Windows.Forms.Timer clock=new System.Windows.Forms.Timer {Interval=500};
        List<AppEntry> catalog=new List<AppEntry>();
        Plan plan;
        List<ProcessRow> processRows=new List<ProcessRow>();

        bool busy,guardBusy,closing,endRequested,loading,finishedClosing,catalogScanned,scanRequested;
        bool windowsShuttingDown;
        string phase="Inactive",message="Choose your raid apps in Whitelist, then scan the running processes.";
        DateTime nextGuard;
        string endReason;
        CancellationTokenSource cancellation=new CancellationTokenSource();

        internal static MainWindow CreateFirstLaunchPreview()
        {
            return new MainWindow(new Settings {CloseUnlisted=!Program.Personal},null,null,WindowMode.FirstLaunchPreview,firstRun:true);
        }
        internal MainWindow(Settings s,string directory,Func<Action<string>,Session> makeSession,WindowMode mode=WindowMode.Normal,bool firstRun=false,bool showSuggestions=false)
        {
            this.mode=mode;settings=s;root=directory;
            string journalDirectory=Program.Personal && Paths.Equal(directory,Paths.Data)?Paths.SharedSessions:directory;
            session=makeSession==null ? new Session(s,journalDirectory,Record) : makeSession(Record);
            Text=Program.DisplayName; Font=new Font("Segoe UI",Program.Personal?9:10); ForeColor=Program.Personal?RaidTheme.Text:Ink; BackColor=Program.Personal?RaidTheme.Page:Paper;
            AutoScaleMode=AutoScaleMode.Dpi; MinimumSize=new Size(810,580); Size=Program.Personal?new Size(1160,790):new Size(1080,730); StartPosition=FormStartPosition.CenterScreen;
            try { Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch(ArgumentException) {}
            var frame=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Margin=Padding.Empty,Padding=Padding.Empty};
            frame.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            frame.RowStyles.Add(new RowStyle(SizeType.Absolute,Program.Personal?45:76));frame.RowStyles.Add(new RowStyle(SizeType.Absolute,Program.Personal?0:49));
            frame.RowStyles.Add(new RowStyle(SizeType.Percent,100));frame.RowStyles.Add(new RowStyle(SizeType.Absolute,34));
            Controls.Add(frame);
            if(Program.Personal)BuildPersonalHeader(frame);
            else {
                var mast=new TableLayoutPanel{Dock=DockStyle.Fill,BackColor=Ink,ColumnCount=2,Padding=new Padding(24,0,24,0),Margin=Padding.Empty};
                mast.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));mast.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,220));
                var title=LabelOf(Program.DisplayName,25,true);title.ForeColor=Color.White;badge.ForeColor=Mint;badge.TextAlign=ContentAlignment.MiddleRight;
                mast.Controls.Add(title,0,0);mast.Controls.Add(badge,1,0);frame.Controls.Add(mast,0,0);
                var nav=Bar();nav.BackColor=Color.White;nav.Padding=new Padding(22,5,0,0);
                foreach(string name in new[]{"Session","Whitelist","Activity"}){
                    var b=Btn(name,false);int index=tabs.Count;b.Click+=(o,e)=>ShowPage(index);tabs.Add(b);nav.Controls.Add(b);
                }
                frame.Controls.Add(nav,0,1);
            }
            host.Dock=DockStyle.Fill;host.Margin=Padding.Empty;frame.Controls.Add(host,0,2);
            footer.Padding=new Padding(24,0,8,0);footer.ForeColor=Muted;footer.BackColor=Color.White;if(Program.Personal)BuildPersonalFooter(frame);else frame.Controls.Add(footer,0,3);
            BuildHome();
            if(Program.Personal) BuildPersonalDetails(); else BuildWhitelist(mode==WindowMode.Normal && !firstRun);
            ConfigureRuleControls();
            BuildActivity(journalDirectory);if(Program.Personal){RaidTheme.LogGrid(events);RaidTheme.LogGrid(sessionEvents);}
            if(Program.Personal) {
                message=settings.UseRaidDefaults?"Discord and WoW start Rostered. Other apps start Benched. Select an app to change its rule.":"Set app rules, then preview what will stay open and what can close.";
                FillApps();
            }
            ShowPage(0);
            if(session.NeedsRecovery){phase="Recovery required";message="The previous session was interrupted. Recover its saved startup changes before starting again.";}
            else if(mode==WindowMode.ReadOnly) message="Read-only preview. Scan software or review running processes. Open normally to edit your whitelist and start.";
            else if(mode==WindowMode.FirstLaunchPreview) message="Try the setup and scan a raid plan. Preview choices clear when you close this window.";
            else if(Native.Elevated) message="Preview is available. Reopen "+Program.DisplayName+" normally to activate a session.";
            Record(settings.Origin+" loaded. "+settings.Allow.Count+" editable rules.");
            FormClosing+=OnClosing;
            clock.Tick+=async(o,e)=>await Tick();
            AutoScaleDimensions=new SizeF(96,96);
            Shown+=async(o,e)=>{
                var area=Screen.FromControl(this).WorkingArea;
                MinimumSize=new Size(Math.Min(MinimumSize.Width,area.Width),Math.Min(MinimumSize.Height,area.Height));
                if(Width>area.Width || Height>area.Height) Bounds=new Rectangle(area.Left,area.Top,Math.Min(Width,area.Width),Math.Min(Height,area.Height));
                foreach(var list in new[]{processes,apps,events,sessionEvents}) if(!Program.Personal || list!=processes)foreach(ColumnHeader col in list.Columns)col.Width=(int)Math.Round(col.Width*DeviceScaling);
                clock.Start();Render();
                if((firstRun || showSuggestions) && !session.NeedsRecovery && mode!=WindowMode.ReadOnly) {
                    if(Program.Personal) {
                        if(showSuggestions) SelectPersonalView(PersonalView.Suggested);
                        await Scan();
                    } else {
                        ShowPage(1);
                        libraryFilter.SelectedIndex=SuggestedApps;
                    }
                }
            };
        }
        static TableLayoutPanel Page() {
            var page=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,Padding=new Padding(24,12,24,14),Margin=Padding.Empty};
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));return page;
        }
        static Label LabelOf(string text,float size,bool bold)
        {
            return new Label {Text=text,Dock=DockStyle.Fill,Font=new Font("Segoe UI",size,bold?FontStyle.Bold:FontStyle.Regular),
                TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true,Margin=Padding.Empty};
        }
        static Button Btn(string text,bool primary)
        {
            var b=Program.Personal?(Button)new RaidButton():new Button();
            b.Text=text;
            b.AutoSize=true;b.Height=34;b.MinimumSize=new Size(60,34);b.FlatStyle=FlatStyle.Flat;
            b.ForeColor=primary?Color.White:Ink;b.BackColor=primary?Pine:Color.White;b.Padding=new Padding(9,0,9,0);b.Margin=new Padding(0,2,7,2);b.UseVisualStyleBackColor=false;
            if(Program.Personal)b.AutoSizeMode=AutoSizeMode.GrowAndShrink;
            b.FlatAppearance.BorderColor=primary?Pine:Line;if(Program.Personal)RaidTheme.ButtonStyle(b,primary);return b;
        }
        static ComboBox SelectBox(params string[] choices)
        {
            var b=Program.Personal?(ComboBox)new RaidComboBox():new ComboBox();b.DropDownStyle=ComboBoxStyle.DropDownList;b.Width=152;b.Margin=new Padding(0,6,10,0);
            b.Items.AddRange(choices);b.SelectedIndex=0;return b;
        }
        static FlowLayoutPanel Bar() {return new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,Margin=Padding.Empty};}
        static T Grid<T>() where T : ListView, new()
        {
            return new T {Dock=DockStyle.Fill,View=View.Details,HeaderStyle=ColumnHeaderStyle.Clickable,FullRowSelect=true,HideSelection=false,MultiSelect=true,
                BorderStyle=Program.Personal?BorderStyle.None:BorderStyle.FixedSingle,BackColor=Program.Personal?RaidTheme.Surface:Color.White,ForeColor=Program.Personal?RaidTheme.Text:Ink,ShowItemToolTips=true,Margin=Padding.Empty};
        }
        static void AddRow(TableLayoutPanel page,Control c,float height)
        {
            int index=page.RowStyles.Count;page.RowCount=index+1;
            page.RowStyles.Add(height<0?new RowStyle(SizeType.Percent,100):new RowStyle(SizeType.Absolute,height));page.Controls.Add(c,0,index);
        }
        static void Columns(ListView list,params object[] pairs)
        {
            for(int i=0;i<pairs.Length;i+=2) list.Columns.Add((string)pairs[i],(int)pairs[i+1]);
        }
        static ListViewItem Item(ListView grid,object data,params string[] cells)
        {
            var row=new ListViewItem(cells){Tag=data,ToolTipText=String.Join(Environment.NewLine,cells.Where(c=>!String.IsNullOrEmpty(c)))};
            return grid.Items.Add(row);
        }
        void BuildHome()
        {
            var actions=Bar();actions.Controls.AddRange(new Control[]{scan,suggestions,start,launch,end});
            if(Program.Personal) {
                BuildPreviewBanner(actions);
                BuildSessionRules();
                Columns(processes,"Application",290,"Rule",140,"Action",145,"Details",85);
                processes.Columns[GroupedProcessView.DetailsColumn].DisplayIndex=1;
                processes.ConfigureRoster();
            } else {
                AddRow(home,status,45);AddRow(home,summary,47);AddRow(home,actions,44);AddRow(home,sub,35);
                review.Controls.AddRange(new Control[]{filter,keep,removeProcess});AddRow(home,review,42);
                Columns(processes,"Application",208,"Whitelist",115,"Action",74,"PID",83,"Window",113,"Reason",212,"Executable path",600);
            }
            Columns(sessionEvents,"Time",110,"Session activity",860);
            var results=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty};results.Controls.Add(processes);results.Controls.Add(sessionEvents);
            if(Program.Personal) {results.Padding=new Padding(1,0,1,0);results.BackColor=RaidTheme.Edge;BuildRowDetails(results);}
            AddRow(home,results,-1);if(Program.Personal)BuildRosterCount();
            scan.Click+=async(o,e)=>await Scan();start.Click+=async(o,e)=>await StartSession();
            suggestions.Click+=async(o,e)=>{
                int count=sessionSuggestions.Count;
                if(catalogScanned && ChangeRules(sessionSuggestions,true)) await Scan(count);
            };
            end.Click+=async(o,e)=>await RequestEnd();launch.Click+=(o,e)=>Launch();
            keep.Click+=(o,e)=>EditProcesses(true);
            removeProcess.Click+=(o,e)=>EditProcesses(false);
            filter.SelectedIndexChanged+=(o,e)=>FillPlan();
            processes.SelectedIndexChanged+=(o,e)=>SetEditButtons();
        }
        void BuildWhitelist(bool offerPreview)
        {
            var heading=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty};
            heading.Controls.Add(LabelOf("Whitelist",21,true));
            if(offerPreview) {
                previewSetup=Btn("Preview first launch",false);
                previewSetup.Dock=DockStyle.Right;
                previewSetup.Click+=(o,e)=>{using(var preview=CreateFirstLaunchPreview()) preview.ShowDialog(this);};
                heading.Controls.Add(previewSetup);
            }
            applySuggestions.Dock=DockStyle.Right;
            applySuggestions.AccessibleName="Apply suggestions";
            applySuggestions.Click+=(o,e)=>ChangeRules(visibleSuggestions,true);
            heading.Controls.Add(applySuggestions);
            AddRow(whitelist,heading,45);
            string saveHint=mode==WindowMode.FirstLaunchPreview?"Preview choices clear when you close this window.":"Changes save automatically for your Windows account.";
            AddRow(whitelist,LabelOf("Select the apps to keep and choose Add to whitelist. "+saveHint,10,false),37);
            var toolbar=Bar();toolbar.Controls.AddRange(new Control[]{running,find,browse,folder});
            toolbar.Controls.Add(SystemRulesButton());
            var filters=Bar();libraryFilter.Width=Math.Max(libraryFilter.Width,TextRenderer.MeasureText("Suggested apps",Font).Width+SystemInformation.VerticalScrollBarWidth+12);filters.Controls.Add(libraryFilter);
            var searchLabel=LabelOf("Search",9,false);searchLabel.AutoSize=true;searchLabel.Dock=DockStyle.None;searchLabel.Margin=new Padding(4,10,8,0);
            search.Width=170;search.Margin=new Padding(0,6,12,0);search.AccessibleName="Search software by name or path";search.TextChanged+=(o,e)=>FillApps();
            filters.Controls.Add(searchLabel);filters.Controls.Add(search);
            filters.Controls.AddRange(new Control[]{addApp,removeRule});
            AddRow(whitelist,toolbar,43);
            AddRow(whitelist,filters,40);
            Columns(apps,"Application",190,"Rule",155,"Source",145,"Executable or folder",570);
            AddRow(whitelist,apps,-1);
            AddRow(whitelist,policyInfo,32);
            find.Click+=async(o,e)=>await Discover();
            running.Click+=async(o,e)=>{
                filter.SelectedIndex=0;ShowPage(0);
                if(processRows.Count==0)await Scan();
            };
            addApp.Click+=(o,e)=>ChangeRules(SelectedApps().Where(a=>settings.MatchingRule(a.Image)==null).Select(a=>a.Image),true);
            removeRule.Click+=(o,e)=>{
                if(libraryFilter.SelectedIndex==SuggestedApps)
                    ChangeRules(SelectedApps().Where(a=>settings.MatchingRule(a.Image)!=null).Select(a=>a.Image),false,true);
                else ChangeRules(apps.SelectedItems.Cast<ListViewItem>().Select(i=>i.Tag).OfType<string>(),false);
            };
            apps.DoubleClick+=(o,e)=>{if(addApp.Enabled!=removeRule.Enabled)(addApp.Enabled?addApp:removeRule).PerformClick();};
            apps.SelectedIndexChanged+=(o,e)=>SetEditButtons();
            libraryFilter.SelectedIndexChanged+=async(o,e)=>{
                FillApps();
                if(libraryFilter.SelectedIndex==SuggestedApps && !catalogScanned && !session.NeedsRecovery) await Discover();
            };
        }
        Button SystemRulesButton()
        {
            var system=Btn("System rules...",false);
            system.Click+=(o,e)=>MessageBox.Show(this,"Windows, shell, audio, input, and critical processes are always kept. The guard also keeps other users, other sessions, and processes whose identity Windows cannot verify.\n\n"+
                "Required Windows components are hidden from the process list. Protected locations include "+Paths.Win+", Windows Defender, Microsoft GameInput, Bitdefender, Easy Anti-Cheat, BattlEye, and NVIDIA's driver container. The app and its launch ancestors are protected.\n\n"+
                "Window-close grace: "+settings.Grace+" seconds. Guard interval: "+settings.Interval+" seconds. Session limit: "+settings.Minutes+" minutes. Action limit: "+settings.Limit+" per pass and per minute of guarding.",
                "Built-in Windows protections",MessageBoxButtons.OK,MessageBoxIcon.Information);
            return system;
        }
        void ConfigureRuleControls()
        {
            browse.Click+=(o,e)=>BrowseExecutables();
            folder.Click+=(o,e)=>AllowFolder();
            full.Text=Program.Personal?"Also close eligible Flex apps during raids":"Guard newly launched unlisted apps";pause.Text="Pause matching startup entries during raid";
            full.Dock=DockStyle.Fill;pause.Dock=DockStyle.Fill;full.Margin=Padding.Empty;pause.Margin=Padding.Empty;
            loading=true;full.Checked=Program.Personal?settings.CloseUnlisted:settings.FullGuard;pause.ThreeState=true;pause.AutoCheck=false;
            pause.CheckState=settings.PauseRun&&settings.PauseFiles&&settings.PauseTasks?CheckState.Checked:
                settings.PauseRun||settings.PauseFiles||settings.PauseTasks?CheckState.Indeterminate:CheckState.Unchecked;loading=false;
            AddRow(whitelist,full,28);AddRow(whitelist,pause,28);
            full.CheckedChanged+=(o,e)=>{if(loading)return;var updated=settings.Copy();
                if(Program.Personal) updated.CloseUnlisted=full.Checked;else updated.FullGuard=full.Checked;
                SavePolicy("Guard scope updated.",updated);};
            pause.Click+=(o,e)=>{bool value=pause.CheckState!=CheckState.Checked;var updated=settings.Copy();
                updated.PauseRun=updated.PauseFiles=updated.PauseTasks=value;SavePolicy("Startup pause preference updated.",updated);};
        }
        void BrowseExecutables()
        {
            using(var dialog=Picker(true)) if(dialog.ShowDialog(this)==DialogResult.OK) {
                if(Program.Personal) ShowPickedApps(dialog.FileNames); else ChangeRules(dialog.FileNames,true);
            }
        }
        void BuildActivity(string journalDirectory)
        {
            AddRow(activity,LabelOf("Activity",21,true),48);
            AddRow(activity,LabelOf("Session actions, inventory gaps, and recovery details.",10,false),38);
            Columns(events,"Time",106,"Event",1000);AddRow(activity,events,-1);
            var location=LabelOf(journalDirectory==null?"Preview activity clears when you close this window.":"Session logs   "+Path.Combine(journalDirectory,"Sessions"),9,false);location.ForeColor=Program.Personal?RaidTheme.Soft:Muted;AddRow(activity,location,34);
        }
        void ShowPage(int index)
        {
            CloseRowDetails();
            host.SuspendLayout();host.Controls.Clear();host.Controls.Add(new Control[]{home,whitelist,activity}[index]);host.ResumeLayout();
            for(int i=0;i<tabs.Count;i++){if(Program.Personal)((RaidButton)tabs[i]).SelectTab(i==index);else {tabs[i].BackColor=i==index?Pine:Color.White;tabs[i].ForeColor=i==index?Color.White:Ink;}}
            if(index==1) {
                if(Program.Personal) ShowSelectedDetails();else FillApps();
            }
            Render();
        }
        void FillApps()
        {
            if(Program.Personal) {
                FillSuggestions("",false);FillPlan(true);return;
            }
            apps.BeginUpdate();
            try {
                apps.Items.Clear();
                string term=search.Text.Trim();
                bool showSuggestions=libraryFilter.SelectedIndex==SuggestedApps;
                FillSuggestions(term,showSuggestions);
                if(!showSuggestions) {
                    FillCatalog(term);
                }
            } finally {apps.EndUpdate();}
            applySuggestions.Visible=libraryFilter.SelectedIndex==SuggestedApps;
            applySuggestions.Text="Apply suggestions ("+visibleSuggestions.Count+")";
            string inventory=catalogScanned?catalog.Count+" software entries discovered":"Scan software to find installed and running apps";
            policyInfo.Text=phase=="Attention"?message:settings.Allow.Count+" whitelist rules   /   "+(phase=="Scanning software"?"Scanning software...":inventory);
            SetEditButtons();
        }
        void FillCatalog(string term)
        {
            foreach(var rule in settings.Allow) {
                if(libraryFilter.SelectedIndex==2 || !Contains(rule,term)) continue;
                string name=rule.EndsWith(@"\*")?Path.GetFileName(rule.Substring(0,rule.Length-2)):Path.GetFileNameWithoutExtension(rule);
                Item(apps,rule,name,"Allowed",rule.EndsWith(@"\*")?"Folder rule":"Executable",rule);
            }
            if(libraryFilter.SelectedIndex==0) foreach(var path in settings.FolderExceptions.Where(p=>Contains(p,term))) {
                var entry=new AppEntry {Name=Path.GetFileNameWithoutExtension(path),Image=path,Source="Folder exception"};
                Item(apps,entry,entry.Name,"Off whitelist",entry.Source,entry.Image);
            }
            foreach(var a in catalog) {
                if(libraryFilter.SelectedIndex==1 || settings.MatchingRule(a.Image)!=null || (!Contains(a.Name,term)&&!Contains(a.Image,term))) continue;
                if(libraryFilter.SelectedIndex==0 && settings.FolderExceptions.Contains(a.Image,Paths.Comparer))continue;
                Item(apps,a,a.Name,"Available",a.Source,a.Image);
            }
        }
        void FillSuggestions(string term,bool showRows)
        {
            sessionSuggestions.Clear();
            visibleSuggestions.Clear();
            foreach(var product in RaidSuggestion.Products) {
                var matches=catalog.Where(a=>a.Source!="Saved path" && product.Matches(a)).ToList();
                if(showRows && matches.Count==0 && Contains(product.Name,term)) {
                    string detection=catalogScanned?"Not detected":"Awaiting scan";
                    Item(apps,null,product.Name,detection,"","Start the app and scan again, or use Browse .exe.");
                }
                foreach(var app in matches) {
                    var match=settings.Resolve(app.Image);
                    bool eligible=match.Suggestible;
                    if(eligible) sessionSuggestions.Add(app.Image);
                    if(!showRows || (!Contains(product.Name,term) && !Contains(app.Image,term))) continue;
                    if(eligible) visibleSuggestions.Add(app.Image);
                    string state=eligible?"Suggested":match.Benched?"Blacklisted":match.Roster==null?"Excluded":match.Origin==RuleOrigin.Folder?"Listed folder":"Listed app";
                    Item(apps,app,product.Name,state,app.Source,app.Image);
                }
            }
        }
        static bool Contains(string value,string term) {return (value??"").IndexOf(term,StringComparison.OrdinalIgnoreCase)>=0;}
        void FillPlan(bool retainSelection=false)
        {
            CloseRowDetails();
            if(Program.Personal){
                search.Enabled=filter.SelectedIndex<3;
                FillSessionApps(retainSelection);
            }
            if(filter.SelectedIndex<3) {
                if(Program.Personal) {SetEditButtons();ShowEmptyRoster();return;}
                var visible=processRows.Where(p=>!p.IsWindowsComponent && (filter.SelectedIndex==0 || (filter.SelectedIndex==1)==p.Close));
                processes.Display(visible,retainSelection);
                SetEditButtons();
                return;
            }
            processes.BeginUpdate();
            try {
                processes.Items.Clear();
                if(filter.SelectedIndex==3) {
                    if(plan!=null)foreach(var s in plan.Sources) Item(processes,s,Program.Personal?s.Label:s.Kind,"","Pause","","",s.Label,s.Target);
                } else if(filter.SelectedIndex==4) {
                    if(plan!=null)foreach(var note in plan.Notes) Item(processes,null,Program.Personal?note:"Inventory","","Review","","",note,"");
                }
            } finally {processes.EndUpdate();SetEditButtons();if(Program.Personal){rosterCount.Text=processes.Items.Count+" report entries";ShowEmptyRoster();}}
        }
        IEnumerable<AppEntry> SelectedApps()
        {
            return apps.SelectedItems.Cast<ListViewItem>().Select(i=>i.Tag).OfType<AppEntry>();
        }
        void SetEditButtons()
        {
            bool editable=mode!=WindowMode.ReadOnly&&!busy&&!session.Active&&!session.NeedsRecovery;
            applySuggestions.Enabled=editable && catalogScanned && visibleSuggestions.Count>0;
            suggestions.Enabled=editable && catalogScanned && sessionSuggestions.Count>0;
            if(Program.Personal){SetPersonalEditButtons(editable);return;}
            keep.Enabled=editable&&processes.SelectedProcesses().Any(p=>p.CanEditWhitelist && p.WhitelistRule==null);
            removeProcess.Enabled=editable&&processes.SelectedProcesses().Any(p=>p.CanEditWhitelist && p.WhitelistRule!=null);
            addApp.Enabled=editable&&SelectedApps().Any(a=>settings.MatchingRule(a.Image)==null);
            removeRule.Enabled=editable&&(libraryFilter.SelectedIndex==SuggestedApps?SelectedApps().Any(a=>settings.MatchingRule(a.Image)!=null):apps.SelectedItems.Cast<ListViewItem>().Any(i=>i.Tag is string));
        }
        void EditProcesses(bool allow)
        {
            if(Program.Personal){EditPersonalProcesses(allow?PersonalRule.Whitelist:PersonalRule.Clear);return;}
            var paths=processes.SelectedProcesses().Where(p=>p.CanEditWhitelist && (p.WhitelistRule==null)==allow).Select(p=>p.Image);
            ChangeRules(paths,allow,true);
        }
        void AllowFolder()
        {
            if(mode==WindowMode.ReadOnly||busy||session.Active||session.NeedsRecovery)return;
            using(var dialog=new FolderBrowserDialog {Description="Choose the installation folder for one application.",ShowNewFolderButton=false}) {
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                try {
                    string rule=Paths.Rule(dialog.SelectedPath.TrimEnd('\\')+@"\*");
                    if(MessageBox.Show(this,"Allow every executable in this folder and its subfolders?\n\n"+dialog.SelectedPath,
                        "Allow application folder",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
                    var updated=settings.Copy();
                    if(!updated.Allow.Contains(rule,Paths.Comparer))updated.Allow.Add(rule);
                    SavePolicy("Allowed folder "+rule,updated);
                } catch(Exception ex){Error(ex);}
            }
        }
        bool ChangeRules(IEnumerable<string> paths,bool allow,bool processSelection=false)
        {
            if(mode==WindowMode.ReadOnly||busy||session.Active||session.NeedsRecovery)return false;
            try {
                var changes=paths.Distinct(Paths.Comparer).ToList();
                if(changes.Count==0)return false;
                var updated=settings.Copy();
                foreach(string path in changes) {
                    if(allow)updated.AllowExecutable(path);
                    else if(processSelection)updated.RemoveExecutable(path);
                    else updated.Allow.RemoveAll(r=>Paths.Equal(r,path));
                }
                return SavePolicy((allow?"Allowed ":"Removed ")+String.Join(", ",changes),updated);
            } catch(Exception ex){Error(ex);FillApps();return false;}
        }
        bool SavePolicy(string note,Settings updated,string feedback=null)
        {
            plan=null;session.Reviewed=null;
            bool saved=false;
            try {
                updated.Validate();
                if (mode==WindowMode.Normal) Store.Write(Path.Combine(root,"whitelist.json"),updated);
                if(Program.Personal) RememberClearedApps(updated);
                settings.Allow=updated.Allow;settings.FolderExceptions=updated.FolderExceptions;
                settings.Block=updated.Block;settings.BenchProducts=updated.BenchProducts;settings.RosterProducts=updated.RosterProducts;
                settings.AfterRaid=updated.AfterRaid;settings.AfterProducts=updated.AfterProducts;
                settings.UseRaidDefaults=updated.UseRaidDefaults;
                settings.CloseUnlisted=updated.CloseUnlisted;settings.BenchAside=updated.BenchAside;
                settings.FullGuard=updated.FullGuard;settings.PauseRun=updated.PauseRun;settings.PauseFiles=updated.PauseFiles;settings.PauseTasks=updated.PauseTasks;
                saved=true;phase="Inactive";message=mode==WindowMode.FirstLaunchPreview?"Preview choices updated.":
                    (feedback??"Changes saved.")+" Scan again before starting the raid.";Record(note);
            }
            catch(Exception ex){phase="Attention";message="Settings could not be saved. "+ex.Message;Record(message);}
            loading=true;full.Checked=Program.Personal?settings.CloseUnlisted:settings.FullGuard;
            pause.CheckState=settings.PauseRun&&settings.PauseFiles&&settings.PauseTasks?CheckState.Checked:
                settings.PauseRun||settings.PauseFiles||settings.PauseTasks?CheckState.Indeterminate:CheckState.Unchecked;loading=false;
            Policy.Classify(processRows,settings,new List<ProcessRow>());
            if(!Program.Personal) FillPlan(true);
            FillApps();Render();
            return saved;
        }
        static OpenFileDialog Picker(bool multiple)
        {
            return new OpenFileDialog {Title=multiple?"Choose executable files":"Launch one executable for this raid",Filter="Windows applications (*.exe)|*.exe",
                Multiselect=multiple,CheckFileExists=true,RestoreDirectory=true};
        }
        async Task Discover()
        {
            if(busy || session.Active || session.NeedsRecovery)return;busy=true;var old=phase;phase="Scanning software";FillApps();Render();
            try {
                var notes=new List<string>();catalog=await Task.Run(()=>Software.Find(Native.Snapshot(),notes));catalogScanned=true;
                foreach(var note in notes) Record(note);phase=old;Record("Software scan found "+catalog.Count+" executable paths.");
            } catch(Exception ex){Error(ex);}
            finally {busy=false;FillApps();Render();}
            await AfterWork();
        }
        internal async Task Scan(int appliedCount=0)
        {
            if(busy||session.Active||session.NeedsRecovery)return;
            busy=true;scanRequested=true;plan=null;processRows=new List<ProcessRow>();FillPlan();phase="Scanning";message="Checking running processes, suggested apps and startup entries.";Render();
            try {
                var reviewed=await Task.Run(()=>session.Scan());
                try {
                    var detected=await Task.Run(()=>Software.Find(reviewed.Rows,reviewed.Notes));
                    foreach(var app in detected.Where(a=>a.DesktopLauncher))reviewed.DesktopLaunchers.Add(app.Image);
                    var paths=new HashSet<string>(detected.Select(a=>a.Image),Paths.Comparer);
                    detected.AddRange(catalog.Where(a=>a.Source=="Browse" && !paths.Contains(a.Image) && File.Exists(a.Image)));
                    catalog=detected;catalogScanned=true;
                } catch(Exception ex){
                    catalogScanned=false;reviewed.Notes.Add("Could not refresh suggestions. Scan again to retry. "+ex.Message);
                }
                plan=reviewed;processRows=plan.Rows;phase=mode==WindowMode.Normal?"Awaiting approval":"Preview ready";
                processes.ForgetMissingPaths(processRows);
                if(mode==WindowMode.ReadOnly) message="Read-only scan. Open "+Program.DisplayName+" normally to edit your whitelist or start a session.";
                else if(mode==WindowMode.FirstLaunchPreview) message="This plan uses your preview choices. Raid activation is disabled in this window.";
                else if(settings.UseRaidDefaults) message="Discord and WoW start Rostered. Other apps start Benched. Review the Action column before starting.";
                else message=Program.Personal?"Review the Action column before starting. Use Ctrl or Shift to select several apps.":"Select processes to add or remove from your whitelist. Review the close list and startup changes before starting.";
                if(appliedCount>0) message="Applied "+appliedCount+(appliedCount==1?" suggestion. ":" suggestions. ")+message;
                foreach(var note in plan.Notes) Record(note);
                Record("Preview ready. "+plan.Targets.Count()+" processes to close and "+plan.Sources.Count+" startup changes.");if(!Program.Personal) FillPlan();FillApps();
            } catch(Exception ex){scanRequested=false;Error(ex);}
            finally {busy=false;Render();}
            await AfterWork();
        }
        async Task StartSession()
        {
            if(mode!=WindowMode.Normal||busy||plan==null||session.Active)return;
            var reviewed=plan;
            string scope=settings.FullGuard?"Newly launched unlisted apps will also be closed.":"Only executable paths in this close list will be guarded.";
            if(!settings.CloseUnlisted)scope="Only blacklisted executable paths will be closed during this raid.";
            if(Program.Personal)scope=!settings.CloseUnlisted?"Benched apps can close during this raid. Flex apps stay open.":
                settings.FullGuard?"Benched and eligible Flex apps can close, including new launches.":"Benched apps and eligible Flex apps in the reviewed close list can close.";
            var afterRaid=SessionReturn.LeaveClosed;
            if(Program.Raiders) {
                using(var dialog=new StartRaidDialog(reviewed,scope,settings.Minutes)) {
                    if(dialog.ShowDialog(this)!=DialogResult.OK || !dialog.Choice.HasValue)return;
                    afterRaid=dialog.Choice.Value;
                }
            } else if(MessageBox.Show(this,"Are you sure you want to start raid mode?\n\nProcesses to close: "+reviewed.Targets.Count()+"\nStartup entries to pause: "+reviewed.Sources.Count+"\n\n"+
                "Apps can be force-closed after "+settings.Grace+" seconds. Save open work first.\n\n"+scope+"\n\nPlan "+reviewed.Id.ToString("N").Substring(0,8)+"   /   "+settings.Minutes+" minute limit.",
                "Start raid session?",MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            scanRequested=false;endReason=null;sessionHistory.Clear();sessionEvents.Items.Clear();busy=true;phase="Starting";message="Rechecking the approved identities and preparing the session.";ResetCancellation();Render();
            try {
                await Task.Run(()=>session.Start(reviewed,reviewed.Id,cancellation.Token,afterRaid));phase="Active";
                message=Program.Raiders?Session.ReturnSummary(afterRaid)+" "+scope:scope;
                nextGuard=DateTime.UtcNow.AddSeconds(settings.Interval);
            } catch(OperationCanceledException){phase="Inactive";message="Startup cancelled. Check Activity for actions already completed.";}
            catch(Exception ex){Error(ex);}
            finally {busy=false;plan=null;processRows=new List<ProcessRow>();FillPlan();Render();}
            await AfterWork();
        }
        async Task Tick()
        {
            if(!session.Active||busy||guardBusy||endRequested||closing)return;
            if(session.Expired){endReason="Session time limit reached.";Record(endReason);await RequestEnd();return;}
            if(DateTime.UtcNow<nextGuard){Render();return;}
            guardBusy=true;Render();
            try {await Task.Run(()=>session.Guard(cancellation.Token));}
            catch(OperationCanceledException){}
            catch(Exception ex){endReason="Guard stopped: "+ex.Message;Record(endReason);endRequested=true;}
            finally {nextGuard=DateTime.UtcNow.AddSeconds(settings.Interval);guardBusy=false;Render();}
            await AfterWork();
        }
        void Launch()
        {
            if(!session.Active||busy||guardBusy||endRequested)return;
            // Serialize the modal picker and identity approval with guard passes.
            using(var d=Picker(false)) {
                if(d.ShowDialog(this)!=DialogResult.OK)return;
                if(guardBusy){message="A guard check is finishing. Select Launch once again.";Render();return;}
                try {session.Launch(d.FileName);} catch(Exception ex){Record(ex.Message);MessageBox.Show(this,ex.Message,"Launch once");}
            }
        }
        async Task RequestEnd()
        {
            if(mode!=WindowMode.Normal)return;
            endRequested=true;cancellation.Cancel();phase="Ending";message="Stopping the guard and restoring journaled startup changes.";Render();
            if(!busy&&!guardBusy)await Finish();
        }
        async Task Finish()
        {
            endRequested=false;busy=true;phase="Ending";Render();
            try {await Task.Run(()=>session.End(!windowsShuttingDown));phase="Inactive";message=(endReason==null?"":endReason+" ")+"Session ended. See Activity for results.";}
            catch(Exception ex){closing=false;Error(ex);}
            finally {busy=false;endRequested=false;plan=null;processRows=new List<ProcessRow>();FillPlan();ResetCancellation();Render();}
            if(closing){finishedClosing=true;Close();}
        }
        async Task AfterWork()
        {
            if(busy||guardBusy)return;
            if(endRequested){await Finish();return;}
            if(closing){if(session.Active) await RequestEnd(); else {finishedClosing=true;Close();}}
        }
        void OnClosing(object sender,FormClosingEventArgs e)
        {
            if(e.CloseReason==CloseReason.WindowsShutDown)windowsShuttingDown=true;
            if(finishedClosing)return;
            if(!session.Active&&!busy&&!guardBusy)return;
            e.Cancel=true;
            if(closing || endRequested)return;
            if((session.Active||phase=="Starting") && e.CloseReason!=CloseReason.WindowsShutDown &&
                MessageBox.Show(this,"End the raid session and restore startup changes before closing?","Close "+Program.DisplayName,MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            closing=true;
            if(session.Active||phase=="Starting") BeginInvoke(new Action(async()=>await RequestEnd()));
        }
        void ResetCancellation(){cancellation.Dispose();cancellation=new CancellationTokenSource();}
        void Error(Exception ex){phase=session.NeedsRecovery?"Recovery required":"Attention";message=ex.Message;Record(message);Render();}
        internal static void AddEvent(ListView list,Queue<ListViewItem> history,int limit,DateTime time,string text)
        {
            if(history.Count==limit)history.Dequeue().Remove();
            var row=new ListViewItem(new[]{time.ToLocalTime().ToString("T"),text}){ToolTipText=text,Tag=time};
            list.Items.Insert(0,row);
            history.Enqueue(row);
        }
        void Record(string text)
        {
            if(IsDisposed)return;
            if(InvokeRequired){BeginInvoke(new Action<string>(Record),text);return;}
            var time=DateTime.UtcNow;
            AddEvent(events,eventHistory,500,time,text);
            if(phase=="Starting"||phase=="Active"||phase=="Ending")
                AddEvent(sessionEvents,sessionHistory,150,time,text);
            if(session!=null && session.Active && (text.StartsWith("Skipped")||text.StartsWith("Could not")||text.StartsWith("Close requested"))) {message=text;Render();}
        }
        void Render()
        {
            bool active=session.Active, recovery=session.NeedsRecovery&&!active&&!busy;
            badge.Text=mode==WindowMode.ReadOnly?"READ-ONLY PREVIEW":mode==WindowMode.FirstLaunchPreview?"FIRST-LAUNCH PREVIEW":phase.ToUpperInvariant();
            bool live=active||phase=="Starting"||phase=="Ending";
            if(live) CloseRowDetails();
            review.Visible=!live;home.RowStyles[4].Height=live?0:(Program.Personal?39:42)*DeviceScaling;
            if(Program.Personal) {
                personalEdits.Visible=!live;home.RowStyles[5].Height=live?0:36*DeviceScaling;
                removeProcess.Visible=!live&&!recovery;
                filter.Visible=!live;
            }
            processes.Visible=!live;sessionEvents.Visible=live;
            status.Text=active&&phase=="Active"?"Raid in progress":phase=="Inactive"?"Prepare your raid":phase;
            if(Program.Personal && (phase=="Inactive" || phase=="Awaiting approval" || phase=="Preview ready"))status.Text="App Roster";
            summary.Text=message;summary.ForeColor=Muted;
            sub.Text=plan!=null?String.Format("{0} to close    /    {1} kept    /    {2} startup changes    /    {3} inventory notes",plan.Targets.Count(),plan.Rows.Count(p=>!p.Close&&!p.IsWindowsComponent),plan.Sources.Count,plan.Notes.Count):
                active?"Guard checks every "+settings.Interval+" seconds. "+(session.Notices>0?session.Notices+" skipped or unconfirmed actions. See Activity.":""):
                processRows.Count>0?"Last scan   /   "+processRows.Count(p=>!p.IsWindowsComponent)+" processes   /   Scan again to refresh the close plan":Program.Personal?"Scan to preview raid actions":"Process preview";
            if(Program.Personal && plan!=null)sub.Text="Running processes   "+sub.Text;
            scan.Enabled=!busy&&!active&&!recovery;start.Visible=!active&&!recovery&&phase!="Ending";start.Enabled=mode==WindowMode.Normal&&!busy&&plan!=null&&!Native.Elevated;
            suggestions.Visible=scanRequested&&!live&&!recovery;
            suggestions.Text=!catalogScanned || (busy && phase=="Scanning")?"Apply suggestions (\u2026)":"Apply suggestions ("+sessionSuggestions.Count+")";
            start.BackColor=start.Enabled?RaidOrange:Line;start.FlatAppearance.BorderColor=start.BackColor;
            end.Visible=active||recovery||phase=="Starting"||phase=="Ending";end.Enabled=!endRequested&&(!busy||phase=="Starting");end.Text=recovery?"Recover session":"End session";
            launch.Visible=active;launch.Enabled=active&&!busy&&!guardBusy&&!endRequested;
            end.Enabled=end.Enabled&&mode==WindowMode.Normal;
            if(previewSetup!=null) previewSetup.Enabled=!active&&!busy;
            running.Enabled=find.Enabled=!active&&!busy&&!recovery;folder.Enabled=browse.Enabled=full.Enabled=pause.Enabled=find.Enabled&&mode!=WindowMode.ReadOnly;
            footer.Text=active?"Guard "+(guardBusy?"checking":"running")+"    /    Elapsed "+session.Elapsed.ToString(@"hh\:mm\:ss")+"    /    Limit "+settings.Minutes+" min":
                "Windows protections always on    /    "+(!settings.CloseUnlisted?"Blacklisted apps only":settings.FullGuard?"All unlisted apps":"Reviewed paths only")+"    /    "+settings.Minutes+" min limit";
            if(Program.Personal && !active)footer.Text="Rostered stay open   /   Benched close if eligible   /   "+
                (settings.CloseUnlisted?"Eligible Flex apps may close":"Flex stay open")+"   /   "+settings.Minutes+" min limit";
            if(Program.Personal){ShowEmptyRoster();RenderPersonalChrome(live,active);}
            SetEditButtons();
        }
        float DeviceScaling {get {return CurrentAutoScaleDimensions.Width/96f;}}
        protected override void Dispose(bool disposing)
        {
            if(disposing){ruleTips.Dispose();clock.Dispose();cancellation.Dispose();session.Dispose();foreach(var p in new[]{home,whitelist,activity}) if(p.Parent==null)p.Dispose();}
            base.Dispose(disposing);
        }
    }
}
