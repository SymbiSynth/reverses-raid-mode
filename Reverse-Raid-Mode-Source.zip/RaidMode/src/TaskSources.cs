using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Xml;

namespace RaidMode
{
    internal static class TaskSources
    {
        internal static string Fingerprint(string definition)
        {
            var xml=new XmlDocument { XmlResolver=null };
            xml.LoadXml(definition);
            var enabled=xml.SelectSingleNode("/*[local-name()='Task']/*[local-name()='Settings']/*[local-name()='Enabled']");
            if (enabled!=null) enabled.ParentNode.RemoveChild(enabled);
            using (var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(xml.OuterXml)));
        }
        internal static bool Owned(string principal)
        {
            if (String.IsNullOrWhiteSpace(principal)) return false;
            if (principal==Native.User) return true;
            try { return ((SecurityIdentifier)new NTAccount(principal).Translate(typeof(SecurityIdentifier))).Value==Native.User; }
            catch (IdentityNotMappedException) { return false; }
        }
        static object Connect()
        {
            object service=Activator.CreateInstance(Type.GetTypeFromProgID("Schedule.Service",true));
            try {Com.Call(service,"Connect"); return service;} catch {Software.Release(service); throw;}
        }
        internal static void Inspect(HashSet<string> paths, List<SourceItem> list, List<string> notes)
        {
            object service=null;
            int unavailable=0;
            try {
                service=Connect();
                var pending=new Stack<string>(); pending.Push(@"\");
                while(pending.Count>0) {
                    object folder=null, children=null, tasks=null;
                    try {
                        folder=Com.Call(service,"GetFolder",pending.Pop()); children=Com.Call(folder,"GetFolders",0);
                        int folders=(int)Com.Get(children,"Count");
                        for (int i=1;i<=folders;i++) {
                            object sub=Com.Get(children,"Item",i);
                            try {pending.Push((string)Com.Get(sub,"Path"));} finally {Software.Release(sub);}
                        }
                        tasks=Com.Call(folder,"GetTasks",1);
                        int taskCount=(int)Com.Get(tasks,"Count");
                        for (int i=1;i<=taskCount;i++) {
                            object task=null;
                            try {
                                task=Com.Get(tasks,"Item",i);
                                if (!(bool)Com.Get(task,"Enabled")) continue;
                                string xml=(string)Com.Get(task,"Xml");
                                var doc=new XmlDocument {XmlResolver=null}; doc.LoadXml(xml);
                                var actions=doc.SelectNodes("/*[local-name()='Task']/*[local-name()='Actions']/*");
                                string match=null;
                                foreach (XmlNode action in actions) {
                                    var cmd=action.SelectSingleNode("./*[local-name()='Command']");
                                    if (cmd!=null) match=Sources.Match(cmd.InnerText,paths) ?? match;
                                }
                                if (match==null) continue;
                                var users=doc.SelectNodes("/*[local-name()='Task']/*[local-name()='Principals']/*[local-name()='Principal']/*[local-name()='UserId']");
                                if (actions.Count!=1 || users.Count!=1 || !Owned(users[0].InnerText)) {
                                    notes.Add("Task left enabled (multiple actions or unclear ownership): " + (string)Com.Get(task,"Path")); continue;
                                }
                                list.Add(new SourceItem {Kind="Scheduled task",Location=(string)Com.Get(task,"Path"),Target=match,Fingerprint=Fingerprint(xml)});
                            } catch (Exception) {unavailable++;} finally {Software.Release(task);}
                        }
                    } catch(Exception) {unavailable++;}
                    finally {Software.Release(tasks);Software.Release(children);Software.Release(folder);}
                }
            } catch(Exception ex) {notes.Add("Task inventory unavailable: " + ex.Message);}
            finally {Software.Release(service);}
            if(unavailable>0) notes.Add(unavailable + " task inventory items or folders could not be read.");
        }
        internal static bool Set(SourceItem item, bool enabled)
        {
            object service=null,folder=null,task=null;
            try {
                service=Connect();
                int slash=item.Location.LastIndexOf('\\');
                folder=Com.Call(service,"GetFolder",slash==0 ? @"\" : item.Location.Substring(0,slash));
                task=Com.Call(folder,"GetTask",item.Location.Substring(slash+1));
                string xml=(string)Com.Get(task,"Xml");
                var doc=new XmlDocument {XmlResolver=null}; doc.LoadXml(xml);
                var user=doc.SelectSingleNode("/*[local-name()='Task']/*[local-name()='Principals']/*[local-name()='Principal']/*[local-name()='UserId']");
                if (user==null || !Owned(user.InnerText) || Fingerprint(xml)!=item.Fingerprint) return false;
                if ((bool)Com.Get(task,"Enabled")==enabled) return enabled;
                Com.Set(task,"Enabled",enabled);
                if ((bool)Com.Get(task,"Enabled")!=enabled) throw new InvalidOperationException("Task Scheduler did not confirm the requested state.");
                return true;
            } finally {Software.Release(task);Software.Release(folder);Software.Release(service);}
        }
    }
}
