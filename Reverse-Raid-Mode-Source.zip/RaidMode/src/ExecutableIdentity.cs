using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;

namespace RaidMode
{
    internal static class ExecutableIdentity
    {
        const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant;
        // Keep the root, app/channel name, architecture, publisher and relative executable path.
        static readonly Regex VersionFolder = new Regex(
            @"(?<=\\)(?<prefix>(?:app|version|v)[-_.]?|[a-z][a-z0-9_-]*(?:\.[a-z][a-z0-9_-]*)*[.-](?=\d))?(?<version>\d+(?:\.\d+)*)(?<channel>[-+](?:alpha|beta|rc|preview))?(?:[.-]?\d+)?(?=\\)", Options);
        static readonly Regex StorePackage = new Regex(
            @"(\\WindowsApps\\[^\\_]+_)\d+\.\d+\.\d+\.\d+(_(?:x64|x86|arm64|arm|neutral)_[^\\]*_[a-z0-9]{13}\\)", Options);
        static readonly Regex GenericName = new Regex(
            @"^(?:agent|helper|update[r]?|setup|install(?:er)?|uninstall(?:er)?|launcher|service|host|electron|node|python[w\d.]*|javaw?|dotnet|crashpad_handler)$", Options);
        static readonly Regex CommonPrefix=new Regex(@"^(?:app|version|v)[-_.]?$",Options);
        static readonly Regex NameSeparators=new Regex(@"[\s_.-]+");

        internal static string VersionKey(string path)
        {
            string key=StorePackage.Replace(path,"$1?$2");
            key=VersionFolder.Replace(key,delegate(Match m) {
                string prefix=m.Groups["prefix"].Value, version=m.Groups["version"].Value;
                if(prefix.Length==0 && version.IndexOf('.')<0)return m.Value;
                string parent=key.Substring(0,m.Index-1);
                try { Paths.Rule(parent+@"\*"); } catch(InvalidDataException) {
                    // A portable app can also have its own directory immediately under a drive root.
                    if(parent.Length<4 || !Paths.Equal(Path.GetDirectoryName(parent),Path.GetPathRoot(parent)) ||
                       !Paths.Equal(Path.GetFileName(parent),Path.GetFileNameWithoutExtension(path)))return m.Value;
                }
                if(prefix.Length>0 && !CommonPrefix.IsMatch(prefix) &&
                   !Paths.Equal(prefix.TrimEnd('.','-'),Path.GetFileName(parent)) &&
                   !Paths.Equal(prefix.TrimEnd('.','-'),Path.GetFileNameWithoutExtension(path)))return m.Value;
                return prefix+"?"+m.Groups["channel"].Value;
            });
            return Paths.Equal(key,path)?null:key;
        }

        sealed class Entry
        {
            internal DateTime Modified;
            internal long Length;
            internal string Product;
        }
        static readonly Dictionary<string,Entry> products=new Dictionary<string,Entry>(Paths.Comparer);

        // File version resources can be read for unsigned apps too. Only app-specific names
        // can follow a move outside the original installation tree.
        internal static string ProductKey(string path)
        {
            try {
                var file=new FileInfo(path);
                if(!file.Exists)return null;
                lock(products) {
                    Entry entry;
                    if(products.TryGetValue(path,out entry) && entry.Modified==file.LastWriteTimeUtc && entry.Length==file.Length)return entry.Product;
                    var info=FileVersionInfo.GetVersionInfo(path);
                    string product=null;
                    string stem=Path.GetFileNameWithoutExtension(file.Name);
                    if(!String.IsNullOrWhiteSpace(info.CompanyName) && !String.IsNullOrWhiteSpace(info.ProductName) &&
                       !GenericName.IsMatch(stem) && (Paths.Equal(file.Name,info.OriginalFilename) ||
                       Paths.Equal(NameSeparators.Replace(info.ProductName,""),NameSeparators.Replace(stem,""))))
                        product=info.CompanyName.Trim()+"\n"+info.ProductName.Trim()+"\n"+file.Name;
                    if(products.Count>=512)products.Clear();
                    products[path]=new Entry{Modified=file.LastWriteTimeUtc,Length=file.Length,Product=product};
                    return product;
                }
            } catch(IOException) {} catch(UnauthorizedAccessException) {} catch(System.ComponentModel.Win32Exception) {}
            return null;
        }
    }
}
