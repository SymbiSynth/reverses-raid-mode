using System;
using System.Diagnostics;
using System.IO;

namespace RaidMode
{
    internal static class AsideInstall
    {
        static readonly string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        static readonly string[] roots={
            Path.Combine(Paths.PF,"Aside"),Path.Combine(Paths.X86,"Aside"),Path.Combine(local,@"Programs\Aside"),
            Path.Combine(local,@"Aside\Application"),Path.Combine(local,@"Aside\CLI"),
            Path.Combine(local,@"Aside\User Data\AsideAgentManager"),Path.Combine(local,@"Aside\User Data\AsideDaemon"),
            Path.Combine(local,@"Aside\User Data\AsidePasswordManager"),
            Path.Combine(Paths.Profile,@".aside\runtime"),Path.Combine(Paths.Profile,@".aside\runtime-computer-use"),
            Path.Combine(Paths.Profile,@".aside\memory-runtimes"),Path.Combine(Paths.Profile,@".aside\password-manager")
        };
        internal static bool Owns(string path)
        {
            if(String.IsNullOrEmpty(path) || !path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))return false;
            foreach(string root in roots)
                if(path.Length>root.Length && path[root.Length]=='\\' && path.StartsWith(root,StringComparison.OrdinalIgnoreCase))return true;
            return false;
        }
    }

    // Row grouping is independent of the rules used to recognize an updated executable.
    internal sealed class AppFamily
    {
        internal readonly string Name, Key;
        internal readonly bool ShowOwnerWhenAlone;
        AppFamily(string name,string key,bool showOwnerWhenAlone)
        {
            Name=name;Key="family:"+key;ShowOwnerWhenAlone=showOwnerWhenAlone;
        }

        internal static AppFamily Known(string path)
        {
            if(String.IsNullOrEmpty(path) || !path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))return null;
            string file=Path.GetFileName(path);
            if(AsideInstall.Owns(path))return new AppFamily("Aside","Aside",!Paths.Equal(file,"Aside.exe"));
            if(Paths.Equal(file,"Battle.net.exe") || Paths.Equal(file,"Battle.net Launcher.exe"))
                return new AppFamily("Battle.net","Battle.net",!Paths.Equal(file,"Battle.net.exe"));
            if((Paths.Equal(file,"Agent.exe") || Paths.Equal(file,"AgentHelper.exe")) &&
                path.IndexOf(@"\Battle.net\Agent\",StringComparison.OrdinalIgnoreCase)>=0)
                return new AppFamily("Battle.net","Battle.net",true);
            if((Paths.Equal(file,"Battle.net Helper.exe") || Paths.Equal(file,"BlizzardBrowser.exe")) &&
                path.IndexOf(@"\Battle.net\",StringComparison.OrdinalIgnoreCase)>=0)
                return new AppFamily("Battle.net","Battle.net",true);
            return null;
        }

        internal static bool SameInstallation(string parent,string child)
        {
            var owner=Known(parent);
            var helper=Known(child);
            if(owner!=null && helper!=null && Paths.Equal(owner.Key,helper.Key))return true;
            string folder=Path.GetDirectoryName(parent);
            string appName=Path.GetFileNameWithoutExtension(parent);
            while(!String.IsNullOrEmpty(folder)) {
                if(Paths.Equal(Path.GetFileName(folder),appName) && child.StartsWith(folder+"\\",StringComparison.OrdinalIgnoreCase)) {
                    try {Paths.Rule(folder+@"\*");return true;} catch(InvalidDataException) {return false;}
                }
                folder=Path.GetDirectoryName(folder);
            }
            return false;
        }

        internal static AppFamily FromProduct(string path,string product,string company)
        {
            if(String.IsNullOrWhiteSpace(product) || String.IsNullOrWhiteSpace(company))return null;
            product=product.Trim();
            // Require a product-specific directory as well as matching embedded product and publisher.
            // Shared runtimes and vendor names alone do not identify the application that owns a helper.
            for(string dir=Path.GetDirectoryName(path);!String.IsNullOrEmpty(dir);dir=Path.GetDirectoryName(dir)) {
                if(!Paths.Equal(Path.GetFileName(dir),product))continue;
                string file=Path.GetFileNameWithoutExtension(path);
                return new AppFamily(product,dir+"|"+company.Trim()+"|"+product,!Paths.Equal(file,product));
            }
            return null;
        }

        internal string ExecutableLabel(string path)
        {
            string file=Path.GetFileName(path);
            if(Key=="family:Battle.net" && Paths.Equal(file,"Agent.exe"))return "Update Agent \u00b7 "+file;
            if(Key=="family:Battle.net" && Paths.Equal(file,"AgentHelper.exe"))return "Update Agent Helper \u00b7 "+file;
            return file;
        }
        internal bool MatchesSearch(string path,string term)
        {
            return (Name+" "+ExecutableLabel(path)).IndexOf(term,StringComparison.OrdinalIgnoreCase)>=0;
        }

        internal static AppFamily Detect(string path)
        {
            var known=Known(path);
            if(known!=null)return known;
            try {
                var version=FileVersionInfo.GetVersionInfo(path);
                return FromProduct(path,version.ProductName,version.CompanyName);
            } catch(IOException) {} catch(UnauthorizedAccessException) {} catch(System.ComponentModel.Win32Exception) {}
            return null;
        }
    }
}
