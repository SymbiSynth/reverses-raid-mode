using System;
using System.Collections;
using System.Windows.Forms;

namespace RaidMode
{
    internal class SortableListView : ListView, IComparer
    {
        int column = -1;
        string title;
        bool descending;
        protected int SortColumn { get { return column; } }
        protected int InSortDirection(int result) { return descending ? -Math.Sign(result) : result; }

        protected override void OnColumnClick(ColumnClickEventArgs e)
        {
            if (column >= 0) Columns[column].Text = title;
            descending = e.Column == column && !descending;
            column = e.Column;
            title = Columns[column].Text;
            Columns[column].Text = title + (descending ? " \u2193" : " \u2191");
            if (ListViewItemSorter == null) ListViewItemSorter = this;
            else Sort();
            base.OnColumnClick(e);
        }

        int IComparer.Compare(object left, object right)
        {
            return CompareRows((ListViewItem)left, (ListViewItem)right);
        }

        protected virtual int CompareRows(ListViewItem a, ListViewItem b)
        {
            int result;
            if (column == 0 && a.Tag is DateTime && b.Tag is DateTime)
                result = DateTime.Compare((DateTime)a.Tag, (DateTime)b.Tag);
            else
                result = StringComparer.OrdinalIgnoreCase.Compare(a.SubItems[column].Text, b.SubItems[column].Text);

            if (result != 0) return InSortDirection(result);
            // Keep apps alphabetized within each category, including in descending category order.
            result = StringComparer.OrdinalIgnoreCase.Compare(a.Text, b.Text);
            if (result == 0)
                result = StringComparer.OrdinalIgnoreCase.Compare(a.SubItems[a.SubItems.Count-1].Text, b.SubItems[b.SubItems.Count-1].Text);
            return result;
        }
    }
}
