using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace RaidMode
{
    internal sealed partial class GroupedProcessView
    {
        bool rosterStyled,pressedCheck,selectingVisible,fitQueued,fitting;
        readonly HeaderChecks headerChecks=new HeaderChecks();
        Font rowTitle;
        ImageList rowHeight;
        int Px(int value){return (int)Math.Round(value*Font.Height/15.0);}
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr handle,int message,IntPtr w,IntPtr l);
        [DllImport("user32.dll")] static extern bool InvalidateRect(IntPtr handle,IntPtr rect,bool erase);

        internal void ConfigureRoster()
        {
            rosterStyled=true;OwnerDraw=true;DoubleBuffered=true;RaidTheme.DarkNative(this);
            HeaderStyle=ColumnHeaderStyle.Clickable;AccessibleName="App Roster";
            AccessibleDescription="Select apps with their checkboxes, Ctrl-click, or Shift-click. Ctrl+A selects the visible rows.";
            rowHeight=new ImageList();SmallImageList=rowHeight;
            DrawColumnHeader+=DrawRosterHeader;DrawSubItem+=DrawRosterCell;
            HandleCreated+=(o,e)=>{
                rowHeight.ImageSize=new Size(1,Math.Max(20,Px(28)));RefreshRosterFont();
                headerChecks.Connect(this,SendMessage(Handle,0x101f,IntPtr.Zero,IntPtr.Zero));FitRoster();
            };
            FontChanged+=(o,e)=>{if(IsHandleCreated){rowHeight.ImageSize=new Size(1,Math.Max(20,Px(28)));RefreshRosterFont();FitRoster();}};
            SizeChanged+=(o,e)=>{
                FitRoster();
                if(fitQueued || !IsHandleCreated)return;
                fitQueued=true;
                BeginInvoke(new Action(()=>{fitQueued=false;if(!IsDisposed)FitRoster();}));
            };
            SelectedIndexChanged+=(o,e)=>{if(headerChecks.Handle!=IntPtr.Zero)InvalidateRect(headerChecks.Handle,IntPtr.Zero,false);};
            Disposed+=(o,e)=>{if(rowTitle!=null)rowTitle.Dispose();rowHeight.Dispose();};
        }
        void RefreshRosterFont()
        {
            if(rowTitle!=null)rowTitle.Dispose();
            rowTitle=new Font(Font,FontStyle.Bold);
        }
        void FitRoster()
        {
            if(fitting || !IsHandleCreated || Columns.Count!=4 || ClientSize.Width<100)return;
            int width=ClientSize.Width;
            int app=width*39/100,details=width*19/100,rule=width*20/100;
            int action=Math.Max(1,width-app-details-rule-1);
            if(Columns[0].Width==app && Columns[1].Width==rule && Columns[2].Width==action && Columns[3].Width==details)return;
            fitting=true;BeginUpdate();
            try {Columns[0].Width=app;Columns[DetailsColumn].Width=details;Columns[1].Width=rule;Columns[2].Width=action;}
            finally {EndUpdate();fitting=false;}
        }
        Rectangle CheckRect(Rectangle cell)
        {
            int size=Px(13);
            return new Rectangle(cell.Left+Px(12),cell.Top+(cell.Height-size)/2,size,size);
        }
        internal Rectangle DisclosureRect(ListViewItem row)
        {
            var rect=GetItemRect(row.Index,ItemBoundsPortion.Label);
            return new Rectangle(rect.Left+Px(62),rect.Top,Px(16),rect.Height);
        }
        void DrawCheck(Graphics g,Rectangle box,bool tick,bool partial)
        {
            RaidTheme.Box(g,box,Px(3),tick||partial?RaidTheme.Accent:RaidTheme.Page,tick||partial?RaidTheme.Accent:RaidTheme.Dim);
            if(tick||partial)using(var pen=new Pen(RaidTheme.OnAccent,Math.Max(1,Px(2)))){
                int y=box.Top+box.Height/2;
                if(partial)g.DrawLine(pen,box.Left+3,y,box.Right-3,y);
                else g.DrawLines(pen,new[]{new Point(box.Left+box.Width/5,y),new Point(box.Left+box.Width*2/5,box.Bottom-box.Height/4),new Point(box.Right-box.Width/5,box.Top+box.Height/4)});
            }
        }
        void DrawRosterHeader(object sender,DrawListViewColumnHeaderEventArgs e)
        {
            var rect=e.Bounds;using(var brush=new SolidBrush(RaidTheme.Header))e.Graphics.FillRectangle(brush,rect);
            using(var pen=new Pen(RaidTheme.Edge))e.Graphics.DrawLine(pen,rect.Left,rect.Bottom-1,rect.Right,rect.Bottom-1);
            if(e.ColumnIndex==0){DrawCheck(e.Graphics,CheckRect(rect),Items.Count>0 && SelectedItems.Count==Items.Count,SelectedItems.Count>0 && SelectedItems.Count<Items.Count);}
            int pad=Px(e.ColumnIndex==0?78:12);
            var text=new Rectangle(rect.Left+pad,rect.Top,Math.Max(0,rect.Width-pad-Px(12)),rect.Height);
            RaidTheme.Write(e.Graphics,e.Header.Text,rowTitle??Font,RaidTheme.Soft,text,e.ColumnIndex==2?TextFormatFlags.Right:TextFormatFlags.Left);
        }
        void DrawRosterCell(object sender,DrawListViewSubItemEventArgs e)
        {
            Rectangle rect=e.Bounds;
            if(e.ColumnIndex==0)rect.Width=Columns[0].Width;
            Color fill=e.Item.Selected?RaidTheme.Violet:RaidTheme.Surface;
            using(var brush=new SolidBrush(fill))e.Graphics.FillRectangle(brush,rect);
            using(var pen=new Pen(RaidTheme.Edge))e.Graphics.DrawLine(pen,rect.Left,rect.Bottom-1,rect.Right,rect.Bottom-1);
            var inner=Rectangle.Inflate(rect,-Px(12),0);
            string value=e.SubItem.Text;
            if(e.ColumnIndex==0){
                DrawCheck(e.Graphics,CheckRect(rect),e.Item.Selected,false);
                bool group=value.StartsWith("\u25b8") || value.StartsWith("\u25be");
                int size=Px(20);
                var icon=new Rectangle(rect.Left+Px(42),rect.Top+(rect.Height-size)/2,size,size);
                RaidTheme.Box(e.Graphics,icon,Px(4),RaidTheme.Header,RaidTheme.Edge);
                using(var pen=new Pen(RaidTheme.Soft,Math.Max(1,Px(1)))){
                    int x=icon.X+size/4,y=icon.Y+size/3,w=size/2,h=size/3;
                    if(group){e.Graphics.DrawLine(pen,x,y-1,x+w/2,y-1);e.Graphics.DrawRectangle(pen,x,y+1,w,h);}
                    else{e.Graphics.DrawRectangle(pen,x,y,w,h);e.Graphics.DrawLine(pen,x,y+2,x+w,y+2);}
                }
                if(group){var arrow=DisclosureRect(e.Item);RaidTheme.Write(e.Graphics,value.Substring(0,1),Font,RaidTheme.Soft,arrow,TextFormatFlags.HorizontalCenter);value=value.Substring(1).TrimStart();}
                int start=Px(group?80:value.StartsWith("\u2003")?87:70);
                var name=new Rectangle(rect.Left+start,rect.Top,Math.Max(0,rect.Width-start-4),rect.Height);
                RaidTheme.Write(e.Graphics,value.TrimStart(),rowTitle??Font,RaidTheme.Text,name,TextFormatFlags.Left);
                if(Focused && e.Item.Focused && ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,Rectangle.Inflate(rect,-2,-2),RaidTheme.Accent,fill);
            } else if(e.ColumnIndex==DetailsColumn){
                RaidTheme.Write(e.Graphics,value=="Details"?"Details  \u2192":value,Font,RaidTheme.Accent,inner,TextFormatFlags.Left);
            } else if(e.ColumnIndex==1 && value.Length>0){
                bool roster=value=="Rostered",bench=value=="Benched";
                string caption=(roster?"\u2713  ":bench?"\u2212  ":"\u00b7  ")+value;
                int height=Math.Min(rect.Height-3,Font.Height+Px(5));
                int width=TextRenderer.MeasureText(caption,rowTitle??Font,Size.Empty,TextFormatFlags.NoPadding).Width+Px(12);
                var chip=new Rectangle(inner.X,rect.Y+(rect.Height-height)/2,Math.Min(width,Math.Max(1,inner.Width)),height);
                var bg=roster?RaidTheme.GreenBg:bench?RaidTheme.BenchBg:RaidTheme.FlexBg;
                RaidTheme.Box(e.Graphics,chip,Px(4),bg,bg);
                RaidTheme.Write(e.Graphics,caption,rowTitle??Font,roster?RaidTheme.Green:bench?RaidTheme.Rose:RaidTheme.Blue,chip,TextFormatFlags.HorizontalCenter);
            } else {
                RaidTheme.Write(e.Graphics,(e.ColumnIndex==2?"\u25cb  ":"")+value,Font,value=="Close"?RaidTheme.Rose:RaidTheme.Soft,inner,TextFormatFlags.Right);
            }
        }
        bool HandleRosterCheckbox(ref Message m)
        {
            if(!rosterStyled)return false;
            if(m.Msg==0x202 && pressedCheck){pressedCheck=false;return true;}
            if(m.Msg!=0x201 && m.Msg!=0x203)return false;
            var pt=new Point(unchecked((int)m.LParam.ToInt64()));
            var row=GetItemAt(pt.X,pt.Y);
            if(row==null || !Rectangle.Inflate(CheckRect(row.GetBounds(ItemBoundsPortion.Label)),Px(4),Px(4)).Contains(pt))return false;
            Focus();row.Focused=true;if(m.Msg==0x201)row.Selected=!row.Selected;pressedCheck=true;return true;
        }
        void SelectVisible(bool select)
        {
            selectingVisible=true;BeginUpdate();
            try { foreach(ListViewItem row in Items)if(row.Selected!=select)row.Selected=select; }
            finally {selectingVisible=false;EndUpdate();OnSelectedIndexChanged(EventArgs.Empty);}
        }
        protected override void OnSelectedIndexChanged(EventArgs e){if(!selectingVisible)base.OnSelectedIndexChanged(e);}
        sealed class HeaderChecks : NativeWindow
        {
            GroupedProcessView grid;
            bool pressed;
            internal void Connect(GroupedProcessView owner,IntPtr handle){
                if(Handle!=IntPtr.Zero)ReleaseHandle();grid=owner;if(handle!=IntPtr.Zero)AssignHandle(handle);
            }
            protected override void WndProc(ref Message m){
                if(m.Msg==0x202 && pressed){pressed=false;return;}
                if(m.Msg==0x201){
                    var pt=new Point(unchecked((int)m.LParam.ToInt64()));
                    // Header and list share the same horizontally scrolled column origin.
                    int left=grid.Items.Count>0?grid.GetItemRect(0,ItemBoundsPortion.Label).Left:0;
                    if(pt.X>=left+grid.Px(8) && pt.X<=left+grid.Px(29)){
                        grid.SelectVisible(grid.SelectedItems.Count<grid.Items.Count);pressed=true;return;
                    }
                }
                base.WndProc(ref m);
            }
        }
    }
}
