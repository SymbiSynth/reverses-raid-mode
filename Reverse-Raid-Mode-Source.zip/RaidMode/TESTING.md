# Windows verification

## Personal build handoff

Carlos launches each new version himself to test the raider experience. Run automated checks with the fixture suites, close older app windows, then replace `outputs/Personal/Reverse's Raid Mode Personal.exe` with the tested build. Verify its version and file hash on disk. Leave the app closed and provide the usual executable link for Carlos to click. Launch the packaged app or its preview only when he explicitly asks.

## Personal edition 0.12.0

The dark Personal theme was rendered with disposable roster data at default and minimum window sizes at 150% scaling. A new Windows fixture checks row checkboxes, the header checkbox in a filtered view, bulk rule edits, the search shortcut, and the filtered roster count. The existing fixtures cover header sorting, native Shift/Ctrl selection, grouped processes, Details links, and session confirmation. The release executable stays closed during the handoff.

## Personal edition 0.11.2

The Personal fixtures move the mouse across the Details cell, the area beyond the last column, empty space, and a report row with missing subitems. They also exercise reordered columns. The Aside fixture verifies initial classification, enforcement on new versioned paths, unrelated lookalike paths, and persistent Rostered and Flex overrides. It also covers toggling and clearing the default. The guard uses a synthetic process list for these checks.

## Personal edition 0.11.1

The Personal fixtures exercise the Battle.net launcher, two running instances of its update agent, an offline helper, and an unrelated executable named Agent.exe. They check expansion, sorting, inline details, search by product and helper name, exact-path persistence, bulk edits in filtered views, and revealing a manually picked helper. Separate ownership checks cover matching product metadata across directories and publishers. A read-only check of Carlos's running Battle.net launcher and Agent.exe identified both as Battle.net.

## Personal edition 0.11.0

The 34 Personal and 44 shared Raiders checks cover the grouped roster, bulk edits, settings persistence, guard and recovery flows. The new roster fixture checks whole-list counts across search and action filters, returning from reports, adding an executable under an active filter, and both Flex policies. Minimum-width checks compare controls with the form's client area.

Three reviewers assessed visual design, interaction, and the combined experience. An offscreen fixture rendered sample apps at 150% scaling at the default and minimum sizes. Review fixes included fitting the search field and navigation at minimum width, keeping added executables visible, and labeling running-process totals. The fixture used synthetic rows and the shipping executable stayed closed.

## Personal edition 0.9

On November 10, 2026, the Personal build passed 29 checks and the shared raider regression build passed 44. The personal UI test saved whitelist, blacklist, close scope and startup preferences, reopened the window from disk, moved an executable between lists and cleared a rule from the process view. Disposable fixtures verified exact-path blacklist enforcement, protected identities and the guard for a newly launched blacklisted path.

The delivered Personal executable opened on the development PC with both lists empty and 162 software entries discovered. Its separate settings file used blacklist-only defaults. The existing raider profile retained its SHA-256 hash and modification time. Raid activation was exercised with fixtures.

## Raiders edition 0.8

Tested on November 8, 2026, on the Windows x64 development PC.

| Check | Result |
| --- | --- |
| .NET Framework x64 Release compile | Passed with compiler warnings treated as errors |
| Desktop application suite, version 0.8 | 43 passed, 0 failed |
| Original Hermes core suite | 25 passed, 0 failed |
| Original Hermes strict suite | 16 passed, 0 failed |
| Original Hermes integration suite | 7 passed, 0 failed |
| Packaged executable opened and scanned in read-only mode | Passed |
| Packaged first-launch preview | Started empty, applied detected suggestions in one click, and preserved the saved profile's SHA-256 hash and modification time |
| Whitelist and live software catalog | 11 whitelist rules loaded and 157 executable paths discovered |

The original suites ran against a separate copy of the source in the handoff ZIP. The 19 source files in that snapshot matched the installed original by SHA-256. Two original registry fixtures required a normal Windows user context outside the sandbox. The full integration suite passed there.

The desktop suite exercised the Windows guard against disposable foreground and background programs, PID reuse and creation-time changes, exact and folder rules, manual launch, short-lived launchers, and both guard scopes. It also exercised plan cancellation and invalidation, user/session boundaries, controller locks, timeout, a rolling action limit, write-ahead journaling, interruption between mutation and acknowledgment, reverse-order recovery, conflicting registry/file changes, and retry. UI checks used the actual message loop and confirmation dialog with fixture process inventories. The test output is in `tests/desktop-test-results.txt`.

Version 0.2 GUI checks exercised the All processes entry point, mixed selections, duplicate process instances, helper and locked rows, repeated adding and removal without rescanning, saved folder exceptions and their reversal, and a failed profile write. The packaged executable displayed both whitelist buttons in the read-only preview.

Version 0.3 GUI tests clicked native column headers and verified whitelist grouping, reverse direction, numeric PID order, retained process identity and selection, and sorting after edits, filters, rescans, searches, and navigation. Activity tests verified time ordering across midnight and chronological retention when sorted by event text. The packaged executable was opened in read-only mode and its Whitelist header was clicked. The captured window showed the ascending arrow and listed apps at the top.

Version 0.4 verified the Reverse's Raid Mode window title and the process display filter. Fixtures checked that known Windows components, critical processes and Windows identities with unreadable paths stay hidden in All processes and Kept, including after edits and sorting. The activation plan retained the full process tree, including protected Windows ancestors of allowed helpers. Separate third-party driver and security rows remained visible and locked. The renamed executable opened in read-only mode and displayed its new name in the title bar and main heading.

Version 0.5 grouped ten fixture processes into one row and checked mouse hit testing, keyboard expansion and collapse, numeric PID sorting, filter-specific counts, mixed decisions and expansion after a rescan. The tests exercised whitelist edits from group and child rows, separate installations with the same filename, unreadable image paths and the per-process close plan.

Version 0.6 tests exercised a fresh account with an empty whitelist, matching and missing suggestions, explicit add and remove, saving an empty profile, reopening with the selected executable, and opening a second independent profile. Upgrade fixtures retained existing folder rules, exceptions and preferences. The packaged executable opened the existing local profile in read-only mode. It was 107,008 bytes and used 40.8 MiB at opening and 77.5 MiB after both inventory scans with UI Automation attached. These are single-run measurements.

Version 0.7 exercised the in-app preview button and command-line entry point. The desktop test opened a preview from an existing profile, edited a suggestion, reviewed a scan, closed the preview and checked the owner's settings and profile file. The next preview started empty. An engine test verified that the preview could scan and rejected activation before any process action.

Version 0.8 tested applying multiple detected paths in one click, limiting the batch by search, preserving existing rules and folder exclusions, and disabling the button after all visible suggestions are listed.

Version 0.9.2 passed all 31 Personal tests and all 44 Raiders tests. The Personal toolbar fixture checked button order, immediate visibility of Suggestions during scanning, detection of a fixture WoW executable, and a distinct Start raid color. The confirmation tests verified the question and default No button. Declining retained the reviewed plan. Accepting started the fixture session with the reviewed close target.

Version 0.9.3 passed all 31 Personal tests and all 44 Raiders tests. The Session fixture applied the full detected suggestion count despite a hidden App rules search, checked the saved profile, and verified that the refreshed preview required confirmation. App rules fixtures checked the three roster labels, including blocked suggestions and folder exclusions. The packaged Personal build was scanned on the desktop and showed one pending suggestion between Scan & preview and Start raid.

Version 0.10.0 passed 31 Personal and 44 Raiders tests. Session fixtures checked grouped running apps, offline apps, saved folder rules, roster colors, the minimum window width, and multi-select clearing across both lists. Clearing an app inside an allowed folder produced a Free agent. Bulk clearing was tested with no selection, cancellation, persistence after relaunch, and preservation of raid settings. A disposable first-launch check verified the packaged Session controls and secondary navigation, closed the window, and checked the saved profile hash.

Version 0.10.1 passed 32 Personal and 44 Raiders tests. Row details were opened for a group, a child PID, FanControl, and an offline WoW client. Back and Escape preserved selection, scroll position, and group expansion. Both editions checked the narrowed suggestion list and the path restriction on Battle.net agents. The packaged Personal preview showed the four-column table and new product list, then closed with the saved profile hash intact.

Version 0.10.2 passed 33 Personal and 44 Raiders tests. A Windows fixture sent native Shift-click, Ctrl-click and right-click input across All apps, Whitelist, Blacklist and Free agents. It verified the saved paths after each menu action, including a right-click outside an existing selection. The packaged Personal preview exposed all three status commands in the row menu and was closed after verification.

The delivered app has been tested with read-only inventory on the real machine. Process termination, registry writes, file moves, and interrupted recovery were exercised on disposable fixtures. Scheduled-task ownership and definition checks were exercised, while mutation of a real installed task and an actual live raid cleanup remain untested. The original utility, its live state, and the user's startup configuration were preserved. The executable is an unsigned development build.
